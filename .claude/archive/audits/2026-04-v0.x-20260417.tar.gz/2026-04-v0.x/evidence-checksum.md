---
feature: checksums (all algorithms, split, disable, ids, extra_files, templated_extra_files)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Checksum stage

## Status: ✅ tested

Covers: `checksum.name_template`, `checksum.algorithm`, `checksum.split` (per-artifact sidecar), `checksum.disable`, `checksum.ids`, `checksum.extra_files`, `checksum.templated_extra_files` (Pro). Algorithms: sha256 (default), sha512, sha1, sha224, sha384, sha3-256/512/224/384, blake2s, blake2b, blake3, crc32, md5.

## Evidence

- **Unit tests**: `crates/stage-checksum/src/lib.rs` — algorithm dispatch, name_template rendering, split-file sidecar, extra_files globbing, templated_extra_files render.
- **Integration test**: `crates/cli/tests/integration.rs::test_check_global_checksum_disable_valid` (L1702), `test_check_per_crate_checksum_disable_valid` (L1641), `test_e2e_skip_archive_and_checksum` (L2310).
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs` — `test_parse_checksum_algorithm_strings` (L1196), `test_parse_checksum_name_template` (L1216), `test_parse_checksum_extra_files` (L1235), `test_parse_checksum_ids` (L1254).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag**: v0.2.5 ships `anodize-0.2.5-checksums.txt` (sha256 default) plus `anodize-0.2.5-checksums.txt.sig` (GPG-signed sidecar).
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:146` sets `algorithm: sha256` + `name_template: "{{ ProjectName }}-{{ Version }}-checksums.txt"`; release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success).

## Caveats / known gaps

None — all ecosystem-relevant algorithms wired; `templated_extra_files` Pro field implemented.
