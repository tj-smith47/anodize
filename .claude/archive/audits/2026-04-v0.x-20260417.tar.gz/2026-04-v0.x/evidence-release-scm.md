---
feature: release SCM (github/gitlab/gitea + draft/prerelease/make_latest/mode/header/footer/skip_upload/extra_files/milestones)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Release (SCM) stage

## Status: ✅ tested

Covers: `release.github`, `release.gitlab`, `release.gitea`, `draft`, `replace_existing_draft`, `use_existing_draft`, `replace_existing_artifacts`, `target_commitish`, `tag` (template, Pro), `discussion_category_name`, `prerelease` (auto/bool), `make_latest`, `mode` (keep-existing/append/prepend/replace), `header`/`footer` (string), `name_template`, `disable`, `skip_upload`, `extra_files`, `templated_extra_files` (Pro), `include_meta`, enterprise URL overrides (github_urls / gitlab_urls / gitea_urls), `milestone pipe`.

## Evidence

- **Unit tests**: `crates/stage-release/src/lib.rs`, `crates/stage-release/src/gitlab.rs`, `crates/stage-release/src/gitea.rs` — multi-provider clients, draft/replace/upload semantics, enterprise URL override, TLS skip.
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_snapshot_release_produces_artifacts` (L632), `test_e2e_snapshot_version_in_artifacts` (L2587), `test_e2e_changelog_header_footer` (L3091).
- **Milestones**: `crates/cli/src/commands/release/milestones.rs` has inline unit tests (split from `release/mod.rs` on 2026-04-16).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag (live publish proof)**: anodize v0.2.5 live at https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 — release body contains full changelog with header/footer template rendered ("Released with anodize"), `draft: false`, `prerelease: auto` behavior. 30+ assets uploaded. 7 releases shipped (v0.1.1–v0.2.5).
- **Live proof of `include_meta`**: `metadata.json` + `artifacts.json` are release assets on v0.2.5 (`metadata.json` asset id RA_kwDORxhcIs4Xp2mB).
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:158` sets `release.github.owner=tj-smith47`, `draft: false`, `prerelease: auto`, `make_latest: auto`, `footer` template, `include_meta: true`. Releases at https://github.com/tj-smith47/cfgd/releases/tag/v0.3.5 + operator-v0.3.5 + csi-v0.3.5 + core-v0.3.5 all published 2026-04-15 (success). 4 tag patterns (`v*`, `core-v*`, `operator-v*`, `csi-v*`) exercised simultaneously.

## Caveats / known gaps

- `release.header.from_url`/`from_file` and `release.footer.from_url`/`from_file` are ⚠ partial: `ContentSource::FromUrl` is a naked `String` with no headers/auth/template-render. Tracked in `.claude/known-bugs.md` A1-rev line 34.
- GitLab + Gitea clients have unit-test coverage but no live release proof in anodize or cfgd (both projects use GitHub). Would need a cfgd-style project on GitLab/Gitea for end-to-end dogfood.
