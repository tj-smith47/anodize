---
feature: missing niche rows (man pages, --soft, continue_on_error)
status: untested
ecosystem_relevance: niche
tier: OSS+Pro
---

# Missing niche features

## Status: ❌ untested (not implemented)

Covers: `goreleaser man` (man page generation via `clap_mangen`), `--soft` flag on `check` (Pro, non-fatal validation), `continue_on_error` per-stage (GoReleaser log-and-continue behavior).

## Evidence

- **Tests**: none — features are not implemented.
- **CI workflow**: none.
- **Release tag**: none.
- **Source state**:
  - `anodize man` subcommand absent from `crates/cli/src/commands/` (no `man.rs` module).
  - `--soft` flag absent from `commands/check.rs`.
  - `continue_on_error` absent from stage orchestration (`crates/core/src/pipeline.rs`).

## Caveats / known gaps

All three are classified as `niche` per inventory §5. `continue_on_error` is at odds with anodize's fail-fast philosophy by design. `man` would be straightforward via `clap_mangen` but would require a new CLI command + documentation. `--soft` requires adding a non-fatal mode to `check`.

If promoted to tested, each would need:
- **man**: a CI job that runs `anodize man > anodize.1` and a release asset of the generated man page.
- **--soft**: integration tests validating non-fatal exit on soft-fail conditions.
- **continue_on_error**: a release where one non-critical stage fails and the pipeline continues with skip-memento logging.
