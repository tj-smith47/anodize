---
feature: changelog (use, filters, groups, sort, format, ai, paths, title, divider, subgroups)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Changelog stage

## Status: ✅ tested

Covers: `disable`, `use` (git/github/gitlab/gitea/github-native), `format` template, `sort` (asc/desc), `abbrev`, `paths` (monorepo filter, Pro), `title` (Pro v2.12+), `divider` (Pro), `filters.include`/`exclude`, `groups[].title/regexp/order`, `groups[].groups[]` (subgroups, Pro), `ai.use/model/prompt` (anthropic/openai/ollama, Pro).

## Evidence

- **Unit tests**: `crates/stage-changelog/src/` — commit-range discovery, template rendering, group ordering, filter regex, AI backend selection.
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_changelog_with_groups` (L1964), `test_e2e_changelog_header_footer` (L3091), `test_e2e_changelog_exclude_filters` (L3188), `test_check_changelog_disabled_valid` (L1734).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag (live proof)**: anodize v0.2.5 release body at https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 shows rendered changelog with **### Features / ### Bug Fixes / ### Others** groups, `sort: asc`, `exclude: "^docs:"/"^ci:"/"^chore:"/"^style:"` filters applied (no matching commits in output body).
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:427` uses `sort: asc`, 4 groups (Features/Bug Fixes/Performance/Others), filters.exclude `^docs:/^ci:/^chore:/^style:`. cfgd release bodies at https://github.com/tj-smith47/cfgd/releases show the rendered changelog.

## Caveats / known gaps

- `changelog.ai.*` (Pro) is implemented in code (`stage-changelog` anthropic/openai/ollama backends) but **not exercised** in any CI or release dogfood — no anodize/cfgd release uses `ai.use`. Would need a release with `use: ai` configured to produce proof.
