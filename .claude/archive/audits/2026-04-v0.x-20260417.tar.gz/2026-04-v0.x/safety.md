# Rust safety audit — anodize — 2026-04-16

Scope: `/opt/repos/anodize/crates/` (all crates). Focus on panic paths reachable
from lib code, `unsafe` justification, concurrency correctness, Drop safety,
and module boundaries. Complements `rust-convention-auditor` (unwrap/expect,
stdout/stderr routing) — this audit covers the deeper surface.

## Blockers

- `crates/stage-build/src/lib.rs:2133` — reachable `panic!` inside `Stage::run`
  parallel build path. Triggers if `job.cmd` is `None` after Phase 1. Comment
  documents "programmer bug" but the invariant is encoded as `Option<Command>`
  rather than made type-safe. Suggested fix: split the job struct into
  `UnprepaedJob { … }` / `PreparedJob { cmd: Command, … }` and make the parallel
  loop consume `Vec<PreparedJob>` so the panic becomes unrepresentable. If that
  refactor is too large, at minimum bail! with the job crate name rather than
  panic.

## Warn

- `crates/stage-sign/src/lib.rs:827` — `h.join().unwrap_or_else(|_| panic!("sign thread panicked"))`.
  A panicked sign worker takes down the parent. Prefer `core::parallel::run_parallel_chunks`
  which converts the panic to `anyhow::Error` with stage attribution (compare
  `crates/core/src/parallel.rs:158` test that documents this intent).
- `crates/stage-docker/src/lib.rs:2329` — same pattern: docker build worker panic
  becomes `panic!("docker build thread panicked")` in the parent. Same fix.
- `crates/stage-publish/src/winget.rs:20-21` — `validate_package_identifier`
  compiles the regex on every call. Correctness is fine (panic on bad literal
  is a programmer bug), but for a validator that can be called per artifact
  this is wasteful. Move to `static RE: LazyLock<Regex> = LazyLock::new(|| static_regex(…))`
  per the convention already used in `crates/core/src/template_preprocess.rs`
  and `crates/core/src/util.rs`.
- `crates/cli/src/timeout.rs:34-36` — `total_secs += n * 3600`, `n * 60` with
  user input `n`. Overflow is practically impossible (u64 / 3600 is 5×10^15
  years), but debug builds will panic on malicious input like
  `--timeout 99999999999999999999h`. Use `checked_mul` / `checked_add` and
  convert to `anyhow::bail!("duration overflow")`.

## Suggest

- `crates/cli/src/timeout.rs:98-108` — the watchdog thread is detached via
  `let _watchdog = std::thread::spawn(…)`. This is intentional (the comment
  even says so), and correct on Unix where `std::process::exit(124)` kills
  the process. No change required, but consider documenting that on
  platforms where the closure panics the watchdog continues to sleep — only
  process exit cleans it up. Not a bug, just an audit note.
- `crates/stage-build/src/lib.rs:3422-3437, 3483-3488`, plus every `unsafe {
  std::env::set_var(…) }` in tests (60+ sites across `stage-announce`,
  `stage-release`, `stage-build`, `core`, `cli`) — all have `// SAFETY:`
  comments citing `serial_test::serial`. Compliant. No action. Noted for
  future reviewers: this is the project's documented pattern and is correct
  provided tests remain serial.
- `crates/cli/src/commands/helpers.rs:21-24` (`set_env_var_single_threaded`)
  — the documented contract is clear. The pipeline invokes this only during
  `setup_env` before worker threads spawn. Verified at call sites 351, 363,
  381, 414. Compliant.
- `crates/core/src/pipe_skip.rs:54-84` — `SkipMemento` uses `Arc<Mutex<Vec>>`
  and correctly recovers from poisoning via `PoisonError::into_inner`.
  Compliant.
- `crates/stage-docker/src/lib.rs:2289-2296` — `SemaphoreGuard<'a>` returns
  its token via `Drop` so a panic doesn't permanently consume a slot.
  Correct pattern.
- `crates/cli/src/commands/tag.rs:146-154` — `unsafe { std::env::set_var(…) }`
  for `ANODIZE_CURRENT_TAG` / `ANODIZE_PREVIOUS_TAG`. SAFETY comment asserts
  single-threaded; `tag` subcommand is indeed single-threaded. Compliant.

## Unsafe inventory

Total `unsafe` blocks in non-test code: **3 sites across 2 files.**

| File:Line | Purpose | SAFETY comment | Verdict |
|---|---|---|---|
| `crates/cli/src/commands/helpers.rs:23` | Set env var during pipeline setup | Yes (detailed multi-paragraph contract at lines 13-20) | OK |
| `crates/cli/src/commands/helpers.rs:415-424` | Remove non-forced token env vars | Yes (short, references helper) | OK |
| `crates/cli/src/commands/tag.rs:149-154` | Set `ANODIZE_CURRENT_TAG` env | Yes (single-threaded tag subcommand) | OK |

All other `unsafe` blocks are in `#[cfg(test)]` or test modules (env mutation
for `serial_test`-serialized tests). Every one carries a `// SAFETY:` comment.

No `unsafe impl Send for X` / `unsafe impl Sync for X`, no `static mut`, no
`std::mem::forget`. Clean.

## Concurrency inventory

- `std::sync::Mutex` usage: `crates/core/src/pipe_skip.rs`,
  `crates/core/src/github_client.rs` (mock-only), `crates/cli/src/commands/publisher.rs`,
  `crates/core/src/template_preprocess.rs`, `crates/cli/src/commands/helpers.rs`
  (test-only `ENV_MUTEX`). All recover from poisoning via `into_inner`. No `.lock()`
  is awaited across `.await` points (project is sync on the hot path; `tokio` is
  not used for the signed-release core).
- No `tokio::sync::Mutex` or async locks observed — no async deadlock vectors.
- No `RefCell` in multi-threaded paths. No `static mut`. No `unsafe impl Send/Sync`.
- Thread scopes: `std::thread::scope` is used in `stage-build`, `stage-sign`,
  `stage-docker`, `cli::commands::publisher`. See Warn section for worker-panic
  handling delta vs `core::parallel::run_parallel_chunks`.

## Drop / resource safety

- Only one explicit `Drop` impl in non-test code:
  `crates/stage-docker/src/lib.rs:2292` (`SemaphoreGuard`) — correct panic-safe
  semaphore return.
- `tempfile::TempDir` usage: only in tests. Production code relies on the
  project's own dist directory layout; no `TempDir` lifetimes cross a pipeline
  boundary.
- No raw `File` / `TcpStream` / `Child` handles held in long-lived structs.
  `std::process::Command` is used per-call and the `Output` / `ExitStatus` is
  consumed immediately.
- `std::mem::forget` / `Box::leak`: not used.

## Clippy delta (not covered by rust-convention-auditor)

Ran `cargo clippy --all-targets --all-features -- -W clippy::correctness -W clippy::suspicious -W clippy::perf -D warnings`.

Result: **0 warnings.** The repo is clean on correctness, suspicious, and perf
lints at the `-W` level. No delta to report.

## Module boundary notes

- `std::process::Command` appears in 32 files. Per the project's Hard Rules
  (enforced by `rust-convention-auditor`) each usage should be in an
  allow-listed module. Every file in the grep result is either a stage crate
  (expected to invoke external tools — tar, zip, cosign, docker, rpmbuild,
  git, etc.) or `core/src/{git,hooks,test_helpers}.rs`. No drift observed
  in new files relative to the documented allow-list.
- `tokio::process::Command`: not used anywhere. Confirmed clean.
- Filesystem mutation (`fs::write`, `fs::remove_*`, `OpenOptions::new().write(true)`):
  428 total occurrences. These are concentrated in stage crates (stage-archive,
  stage-checksum, stage-docker, etc.) which is by design — those stages
  produce artifacts. No filesystem mutation observed in `anodize-core` hot
  paths outside of `git`, `test_helpers`, `templated_files`, and
  `config` (token file reading, not mutation).

## Summary

**1 blocker · 4 warns · ~6 suggests across 4 files.**

The hard work from the recent "unwrap/expect → ?/context (142 → 0 non-test lib
sites)" refactor (commit 441b326) has paid off — panic surface in lib code is
close to eliminated. The remaining hot spots are: worker-thread panic handling
(unify around `core::parallel::run_parallel_chunks`), one `Option` invariant
that could be made type-safe (`stage-build:2133`), and one
compile-per-call regex (`winget.rs:20`). All three are tractable without
architectural change.

## Part 2 — OSS bloat countersign

Status: **BLOCKED — `bloat.md` does not exist yet.** Parity auditors (tasks
#2-#5 in the wave) populate `bloat.md` with `tier=OSS` candidates that this
audit must countersign. None of those tasks have produced output yet
(wave-status.md shows A2-A5 as pending; inventory refresh A1 is still
in_progress).

When `bloat.md` arrives, the countersign pass will:
1. Independently `grep -r /opt/repos/anodize/crates` for each feature's code
   footprint.
2. Check `Cargo.toml` feature-flag gating.
3. Verify removal cannot break other code paths or public API.
4. Append `countersigned_by: rust-safety-scanner — <reason>` or
   `countersign_rejected: rust-safety-scanner — <reason>` to each OSS-tier
   entry (Pro entries belong to `pro-features-skeptic`).
5. Bias toward rejection when in doubt (prefer `hide` / `repurpose` over
   `remove`).

Team lead should re-enqueue or ping once `bloat.md` is populated.
