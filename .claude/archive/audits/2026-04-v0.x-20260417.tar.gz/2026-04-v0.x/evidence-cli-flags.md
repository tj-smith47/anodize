---
feature: CLI flags (--auto-snapshot/--clean/--config/--draft/--fail-fast/--id/--nightly/--parallelism/--prepare/--release-notes/--skip/--snapshot/--split/--timeout/--single-target/--soft)
status: partial
ecosystem_relevance: required/strongly-suggested/niche
tier: OSS+Pro
---

# CLI flags

## Status: 🟡 partial (most flags tested; `--prepare` and `--soft` missing)

Covers: `--auto-snapshot`, `--clean`, `--config`, `--draft`, `--fail-fast`, `--id` / `--crate`, `--nightly`, `--parallelism`, `--prepare` ❌, `--release-notes` / `--release-notes-tmpl`, `--skip` (with `--skip=unknown` parse-time error), `--snapshot`, `--split`, `--timeout`, `--single-target`, `--soft` ❌, `--strict`, `--workspace`.

## Evidence

- **Integration tests**: `crates/cli/tests/integration.rs::test_release_help_shows_timeout_flag` (L208), `test_build_help_shows_timeout_flag` (L224), `test_timeout_kills_long_running_release` (L240), `test_release_help_shows_new_flags` (L386), `test_build_help_shows_new_flags` (L417), `test_release_invalid_timeout_value` (L438), `test_skip_flag_skips_specified_stages` (L1413), `test_e2e_dry_run_no_side_effects` (L716), `test_e2e_auto_snapshot_dirty_repo` (L3322).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Live release flag usage**: anodize release.yml uses `--split --clean`, `--merge`, cfgd release.yml uses `--verbose --debug --strict --split --clean --crate <workspace>` and `--merge --crate <workspace>`. Both run live at https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success).
- **Snapshot flag proof**: anodize CI snapshot job at ci.yml L88 runs `anodize release --snapshot --single-target --clean --dry-run` on every master push; passed at https://github.com/tj-smith47/anodize/actions/runs/24441674093.

## Caveats / known gaps

- `--prepare` flag ❌ **missing** — known-bugs.md A1-rev line 51.
- `--soft` (Pro check) ❌ **missing** — niche per spec §5.
- `--draft` wired but not exercised in production (all releases ship non-draft).
- `--nightly` wired (`NightlyConfig`) but no live nightly release produced. Would require scheduled CI trigger.
