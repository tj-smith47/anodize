---
feature: publishers (custom), blobs (s3/gs/azblob), artifactory, uploads, fury, cloudsmith, crates.io, binstall
status: partial
ecosystem_relevance: strongly-suggested/niche/required
tier: OSS+Pro+Rust-additive
---

# Custom publishers / Blob / Artifactory / Uploads / Fury / CloudSmith / crates.io / binstall

## Status: 🟡 partial (unit-tested + cfgd crates.io proof; blob/artifactory/fury/cloudsmith have no live-release dogfood)

Covers: `publishers[]` (cmd/dir/ids/if/checksum/meta/signature/env/disable/extra_files/templated_extra_files/output), `artifactory` (target/mode/username/password/client_x509_cert/client_x509_key/trusted_certificates/ids/exts/matrix Pro/custom_artifact_name/custom_headers/checksum/meta/signature/skip/extra_files/extra_files_only/templated_extra_files), `uploads[]` (generic HTTP), `fury` (Pro), `cloudsmith` (Pro, `CloudSmithConfig`), `blob` (s3/gs/azblob, provider/bucket/endpoint/region/disable_ssl/ids/if/disable/directory/s3_force_path_style/acl/cache_control/content_disposition/include_meta/extra_files/templated_extra_files), `crates.io publish` (Rust-additive), `binstall` metadata (Rust-additive).

## Evidence

- **Unit tests**: `crates/stage-publish/src/artifactory.rs` (30), `crates/stage-publish/src/cloudsmith.rs` (24), `crates/stage-publish/src/crates_io.rs` (7), `crates/stage-publish/src/upload.rs` (2), `crates/stage-publish/src/util.rs` (30), `crates/stage-blob/src/` (object_store SDK integration). `crates/cli/src/commands/publisher.rs` has inline tests.
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_custom_publishers_dry_run` (L2387).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs all publisher unit tests.
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:424` `blobs`; `:552` `artifactories`; `:559` `cloudsmiths`.
- **Dogfood — crates.io (live publish proof)**: cfgd v0.3.5 config `/opt/repos/cfgd/.anodize.yaml:118/170/361/424` publishes `cfgd-core`, `cfgd`, `cfgd-operator`, `cfgd-csi` to crates.io with `CARGO_REGISTRY_TOKEN`. Release runs 2026-04-15:
  - core-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442229349 (success)
  - v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success)
  - operator-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442230834 (success)
  - csi-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442232044 (success)
- **Dogfood — binstall**: cfgd config at `/opt/repos/cfgd/.anodize.yaml:153` uses `binstall.enabled: true` + `pkg_url`/`pkg_fmt` — enables `cargo binstall cfgd`. Released via cfgd v0.3.5.

## Caveats / known gaps

- **blob (s3/gs/azblob)** — unit-tested via `object_store` SDK, but **no live release** in anodize or cfgd pushes to a cloud bucket. No AWS/GCP/Azure credentials configured in any workflow. `CI workflow: none exercising cloud blob push.`
- **artifactory/fury/cloudsmith** — unit-tested only; no dogfood release uses them (anodize/cfgd only use GitHub releases + crates.io + Docker + package managers). `CI workflow: none exercising artifactory/fury/cloudsmith.`
- **uploads[]** generic HTTP — unit-tested, not dogfooded live.
