---
feature: snapcrafts[] + flatpaks[] + makeselfs[]
status: tested
ecosystem_relevance: niche
tier: OSS
---

# Snapcraft + Flatpak + Makeself

## Status: ✅ tested

Covers: `snapcrafts[]` (grade/confinement/base/plugs/slots/layout/apps/assumes/hooks/extra_files), `flatpaks[]` (app_id/runtime/sdk/command/finish_args), `makeselfs[]` (Linux self-extracting).

## Evidence

- **Unit tests**: `crates/stage-snapcraft/src/lib.rs`, `crates/stage-flatpak/src/` (via `crates/stage-publish` integration), `crates/stage-makeself/src/lib.rs`. Snapcraft YAML validator tests, flatpak manifest shape, makeself shell-script wrapper.
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag (live snap + makeself proof)**: anodize v0.2.5 ships:
  - `anodize_0.2.5_amd64.snap` + `anodize_0.2.5_arm64.snap` (snapcraft, ~9MB/6MB)
  - `anodize-0.2.5-linux-amd64-installer.run`, `anodize-0.2.5-linux-arm64-installer.run`, `anodize-0.2.5-darwin-amd64-installer.run`, `anodize-0.2.5-darwin-arm64-installer.run` (makeself self-extracting installers)
- **anodize config**: `/opt/repos/anodize/.anodize.yaml:380` snapcrafts, `:398` flatpaks, `:575` makeselfs.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:281` configures snapcraft with `grade: stable`, `confinement: strict`, `plugs: [home,network,network-bind]`. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success) with `SNAPCRAFT_STORE_CREDENTIALS` — published live to Snap store.

## Caveats / known gaps

- **Flatpak** implemented in code but **not live-released** — neither anodize nor cfgd ships a flatpak bundle. Would need flatpak runtime + flathub config.
