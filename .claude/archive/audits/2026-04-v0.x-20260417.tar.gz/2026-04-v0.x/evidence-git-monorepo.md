---
feature: git.tag_sort / git.prerelease_suffix / git.ignore_tags / monorepo.* / workspaces / includes
status: tested
ecosystem_relevance: required/strongly-suggested
tier: OSS+Pro
---

# Git config + Monorepo workspaces + Includes

## Status: ✅ tested

Covers: `git.tag_sort` (`-version:refname` / semver / smartsemver Pro), `git.prerelease_suffix`, `git.ignore_tags` / `ignore_tag_prefixes` (Pro), `monorepo.tag_prefix`/`dir`, `includes[].from_file`/`from_url` (Pro), `workspaces[]` (Rust-additive, tag→crate resolution), `--crate` filter.

## Evidence

- **Unit tests**: `crates/core/src/git.rs` (tag discovery, ignore_tags, prerelease detection), `crates/cli/src/commands/resolve_tag.rs` (tag→crate mapping — inline tests).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_workspace_all_force_detects_crates` (L978), `test_e2e_workspace_snapshot_produces_artifacts` (L1046), `test_e2e_init_workspace_generates_depends_on` (L1119), `test_e2e_check_workspace_invalid_depends_on` (L1184), `test_e2e_workspace_change_detection_without_force` (L1235), `test_e2e_workspace_dependency_ordering` (L2250), `test_e2e_multiple_crates_release` (L2894).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release proof — tag filter**: anodize recent commit `128e003` "krew default upstream + per-crate previous_tag prefix filter" explicitly uses per-crate tag prefix filtering; shipped in v0.2.5.
- **anodize config**: `/opt/repos/anodize/.anodize.yaml:24` `git.tag_sort`, `:28` `tag:` block.
- **Dogfood (cfgd v0.3.5 — live monorepo proof)**: cfgd uses 4-workspace monorepo `/opt/repos/cfgd/.anodize.yaml:106`:
  - `cfgd-core` with `tag_template: "core-v{{ Version }}"` → core-v0.3.5 release (run `24442229349`, success)
  - `cfgd` with `tag_template: "v{{ Version }}"` → v0.3.5 release (run `24442230191`, success)
  - `cfgd-operator` with `tag_template: "operator-v{{ Version }}"` → operator-v0.3.5 (run `24442230834`, success)
  - `cfgd-csi` with `tag_template: "csi-v{{ Version }}"` → csi-v0.3.5 (run `24442232044`, success)
  All 4 ran in parallel on 2026-04-15 — `anodize resolve-tag` correctly mapped each tag to its crate. cfgd release.yml at L24 uses `anodize resolve-tag` action input.
- **`depends_on` wiring**: cfgd `/opt/repos/cfgd/.anodize.yaml:129/307/370` declares `depends_on: [cfgd-core]` — releases ordered core → others.

## Caveats / known gaps

- `includes[].from_url` — struct/enum implemented, unit-tested, but not exercised in any live anodize/cfgd release. Both configs are single-file.
