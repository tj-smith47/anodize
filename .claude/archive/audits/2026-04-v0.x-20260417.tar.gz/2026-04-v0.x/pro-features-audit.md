# Pro Features Deep Audit — A5 — 2026-04-16

**Auditor:** `pro-features-skeptic`
**Scope:** 21 Pro rows from `specs/goreleaser-complete-feature-inventory.md` §2 with `ecosystem_relevance ∈ {required, strongly-suggested}`. Rows marked `not-applicable` intentionally skipped.
**Docs source:** all goreleaser.com Pro pages fetched 2026-04-16.
**Anodize source:** `/opt/repos/anodize/crates/` at current HEAD.

**Headline:** the inventory marks a dozen Pro features `implemented` that are actually absent from the struct definitions. Independent grep confirms.

- **10 BLOCKERs** (silent-skip, missing field, schema drift, wire-to-nothing)
- **8 WARN/SUGGESTs** (rough edges on present implementations)
- **12 confirmed-working** Pro features
- **2 deferred** for live-release validation

---

## BLOCKERs

### B1. `nfpm.if` / `nfpm.templated_contents` / `nfpm.templated_scripts` — MISSING (inventory says implemented)

**Docs:** https://goreleaser.com/customization/nfpm/ (fetched 2026-04-16).
Three documented Pro fields:
- `if` (v2.4): template conditional, e.g. `if: '{{ eq .Os "linux" }}'`
- `templated_contents`: per-file, `{ src, dst, packager?, file_info? }`, content passed through template engine
- `templated_scripts`: `{ preinstall, postinstall, preremove, postremove }`, scripts passed through template engine

**Anodize:** `NfpmConfig` at `crates/core/src/config.rs:2815` — NONE of these three fields defined.

Evidence:
- Grep `if_condition|templated_contents|templated_scripts` across `crates/` → `templated_contents` and `templated_scripts` appear ZERO times in any .rs file (excluding the changelog's own CHANGELOG.md).
- `if_condition` only exists on `SignConfig` (`config.rs:4203`) and `DockerSignConfig` (`config.rs:4235`).

**Inventory rows affected:** 214 (`nfpm.if`, `strongly-suggested`), 228 (`nfpm.templated_contents`), 230 (`nfpm.templated_scripts`). All three say `implemented`. Row 214 at `strongly-suggested` escalates to BLOCKER for conditional per-OS nFPM.

**Impact:** users copying `if: '{{ eq .Os "linux" }}'` from GoReleaser docs get a serde rejection ("unknown field `if`, expected one of..."). Users writing `templated_scripts:` get silently-ignored config because the field is absorbed as unknown.

**Severity:** BLOCKER (for `if`, `strongly-suggested`); BLOCKER (for both `templated_*` even though `niche`, because inventory is wrong).

---

### B2. DMG/MSI/PKG/NSIS/AppBundle: `if` field — MISSING (inventory says implemented)

**Docs:** https://goreleaser.com/customization/{dmg,msi,pkg,nsis,app_bundles}/ (all fetched 2026-04-16). Each doc explicitly lists `if` as a Pro template-conditional filter.

**Anodize struct inspection (all `crates/core/src/config.rs`):**
- `DmgConfig` at `:3393` — no `if_condition` field
- `MsiConfig` at `:3424` — no `if_condition` field
- `PkgConfig` at `:3454` — no `if_condition` field
- `NsisConfig` at `:3487` — no `if_condition` field
- `AppBundleConfig` at `:3517` — no `if_condition` field

Grep `if_condition` across `crates/` → only `stage-sign/src/lib.rs` and `config.rs`. No packaging stage uses `if_condition`.

**Inventory rows affected:** 354 (dmgs), 355 (msis), 356 (pkgs), 357 (nsis), 358 (app_bundles). All `strongly-suggested`, all claim `implemented`.

**Impact:** users with `if: '{{ eq .Os "darwin" }}'` on a DMG config get a serde rejection. Users who want per-target packaging conditionals have to use `disable:` (opt-OUT semantics) instead — changes the logic.

**Severity:** BLOCKER × 5 (strongly-suggested).

---

### B3. `archives[].hooks`: field-name mismatch — BLOCKER silent-skip

**Docs:** https://goreleaser.com/customization/archive/ (fetched 2026-04-16). Archive-level hooks:
```yaml
hooks:
  before:
    - make clean
  after:
    - cmd: touch done.flag
```
Extra template var: `.Format`.

**Anodize:** `BuildHooksConfig` at `crates/core/src/config.rs:921-928`:
```rust
pub struct BuildHooksConfig {
    pub pre: Option<Vec<HookEntry>>,
    pub post: Option<Vec<HookEntry>>,
}
```
Fields are `pre` / `post`, not `before` / `after`. **No serde alias.**

Test `stage-archive/src/lib.rs:4274` only validates the `pre:` / `post:` form.

Runtime code `stage-archive/src/lib.rs:1061` and `:1564` reads `archive_cfg.hooks.as_ref().and_then(|h| h.pre.as_ref())`.

**Impact:** a config copied from GoReleaser docs with:
```yaml
archives:
  - hooks:
      before: [make clean]
      after:  [touch done.flag]
```
deserializes successfully because `BuildHooksConfig` is `#[serde(default)]` — unknown fields are silently dropped. Hooks DO NOT RUN. Classic silent-skip failure mode. User sees no warning.

**Also missing:** the `.Format` extra template var. Grep `tvars.set(.*Format"` / `template_vars.set.*"Format"` in `stage-archive/src/lib.rs` → no match in the archive-hook execution region (lines 1060–1063 and 1563–1566). Docs say `.Format` is available inside archive hooks specifically.

**Inventory row affected:** 88 (`archives[].hooks.before/after`, `strongly-suggested`, `implemented`).

**Severity:** BLOCKER — silent-skip, and `strongly-suggested`.

---

### B4. `metadata.full_description` / `metadata.commit_author` — MISSING

**Docs:** https://goreleaser.com/customization/metadata/ (fetched 2026-04-16):
- `full_description` (v2.1+): extended description via `from_url` or `from_file`
- `commit_author` (v2.12+): Git author for automated commits (reverse-propagates to all tap/brew/winget commits)

**Anodize:** `MetadataConfig` at `crates/core/src/config.rs:4363` has only:
- `description`, `homepage`, `license`, `maintainers`, `mod_timestamp`

No `full_description`. No `commit_author`.

(Note: `DockerHubFullDescription` at `:4773` is unrelated — it's a Docker Hub readme sync, not `metadata.full_description`.)

**Inventory row affected:** 375 (bundles all metadata.* as `strongly-suggested`, `implemented`).

**Impact:** users writing `metadata.commit_author: { name: ... }` get serde unknown-field errors. Users writing `full_description: { from_file: ... }` same. Inventory is incorrect.

**Severity:** BLOCKER (strongly-suggested).

---

### B5. Metadata fields collected but NOT consumed by any publisher

**Observation:** grep `cfg\.metadata|metadata\.(homepage|license|description|maintainers)` across all `crates/` → only hits in:
- `crates/core/src/context.rs` (setting template vars)
- `crates/core/src/config.rs` (struct definition and parsing tests)

**No** `stage-publish/`, `stage-nfpm/`, `stage-docker/`, `stage-*` consumer reads `MetadataConfig.homepage` / `.license` / `.description` / `.maintainers` to populate the manifest of the package it's producing.

GoReleaser Pro uses these fields as **defaults** to populate package manifests (Homebrew `desc` / `homepage` / `license`, nFPM deb `maintainer`, Scoop `description`, Winget `PackageIdentifier`/`License`, etc.). In anodize they only surface as `{{ .Metadata.License }}` template vars — the user must thread each field into each per-publisher template manually.

**Impact:** the "set-once, used everywhere" DX promise of `metadata:` is broken. User experience is verbose duplication across every publisher config, and a config like:
```yaml
metadata:
  license: MIT
  homepage: https://example.com
```
produces identical output whether present or absent unless the user has hand-threaded `{{ .Metadata.License }}` into every `homebrew`, `nfpm`, `scoop`, etc. template field.

Aligns with the `feedback_config_must_wire.md` memory: "Config struct without behavioral wiring is NOT done."

**Severity:** BLOCKER — wire-to-nothing on `strongly-suggested` feature.

---

### B6. `release.header.from_url` / `footer.from_url` — no auth, no header injection, no template rendering

**Docs:** https://goreleaser.com/customization/release/ (fetched 2026-04-16). `from_url` is structured:
```yaml
release:
  header:
    from_url:
      url: https://foo.bar/header.md       # Templates: allowed
      headers:
        x-api-token: "${MYCOMPANY_TOKEN}"
```

**Anodize:** `ContentSource::FromUrl` at `crates/core/src/config.rs:1303`:
```rust
FromUrl { from_url: String },
```
A bare String. **No headers field, no structured sub-object.**

`resolve_content_source` at `crates/stage-release/src/lib.rs:605-623`:
```rust
ContentSource::FromUrl { from_url } => {
    let response = reqwest::blocking::Client::builder()
        .timeout(std::time::Duration::from_secs(30))
        .build()?
        .get(from_url)
        .send()
        ...
```
No header injection, no auth.

**Comparison:** for `IncludeSpec`, anodize DOES support the structured `{ url, headers }` shape (`IncludeUrlConfig` at `config.rs:44`). So the pattern exists in the codebase — release/header simply never adopted it.

**Also:** docs say "Templates: allowed" on `from_url` and `from_file`. `resolve_content_source` does NOT render the URL or the file path through Tera. A user writing `from_file: "./release-{{ .Tag }}.md"` gets a literal-path file-not-found.

**Inventory rows affected:** 135/136 (`release.header/footer.from_url/from_file`, `strongly-suggested`, `implemented`). Status should be `partial`.

**Impact:** private-mirror usage (the most common reason for `from_url`) is impossible. Templated endpoints are impossible.

**Severity:** BLOCKER.

---

### B7. `release.footer` (plural `footers` key) — schema drift on auth headers

**Docs:** https://goreleaser.com/customization/release/ (fetched 2026-04-16) shows the footer auth-headers subfield as `footers:` (plural), distinct from header's `headers:`. This upstream quirk (likely a GoReleaser typo that became API) must be matched once B6 is fixed.

Documenting here so the fix for B6 doesn't assume symmetric `headers:` naming for both header and footer.

**Severity:** WARN (dependent on B6).

---

### B8. CLI `--prepare` flag — MISSING (inventory says implemented)

**Docs:** https://goreleaser.com/pro/ (fetched 2026-04-16) advertises `--prepare` as a dry-run-like validation step (validates config, renders templates, but does not execute build/publish).

**Anodize:** grep `prepare` under `crates/cli/src/` → **zero** matches (case-insensitive). Flag is unimplemented.

**Inventory row affected:** 403 (`Flag: --prepare`, `strongly-suggested`, `implemented`).

**Impact:** inventory is false. Parity claim is false.

**Severity:** BLOCKER (strongly-suggested).

---

### B9. CLI `--id` flag — no alias to `--crate`

**Docs:** GoReleaser's `--id` filter takes a build identifier.

**Anodize:** renamed to `--crate` at `crates/cli/src/lib.rs:35,125,169,198,209`. The rename is intentional (it's Rust, crates not builds), but there's no `visible_alias("id")` / `alias("id")` on any clap arg.

**Impact:** a user copy-pasting `goreleaser release --id my-binary` gets a clap "unknown option" error with no friendly redirect. A user searching their history for `--id` finds no matches and wonders if filtering exists at all. Pure DX gap.

**Inventory row affected:** 399 (`Flag: --id (Pro)`, `strongly-suggested`, `implemented`). The row's note "`--crate` filter" documents the rename but doesn't acknowledge the missing alias.

**Severity:** WARN (classified as BLOCKER-adjacent for DX-is-product reasons).

---

### B10. `MsiConfig` — missing `extra_files`, `goamd64`, per-build hooks (v2.14+)

**Docs:** https://goreleaser.com/customization/msi/ (fetched 2026-04-16). Documented fields include:
- `extra_files`: additional files available in the WiX build context
- `goamd64`: amd64 microarch variant (v1/v2/v3/v4)
- `before` / `after` hooks (v2.14+) with the standard hook schema

**Anodize:** `MsiConfig` at `crates/core/src/config.rs:3424-3446` has:
- `extra_files: Option<Vec<String>>` at `:3443` ✓ (but docs show `extra_files` as richer `{src, dst}` shape in newer docs — partial)
- NO `goamd64` / amd64 variant filter
- NO before/after hooks

Note: on re-read, MsiConfig DOES have `extra_files` (I was wrong in my verbal report that it lacked them). Revised finding: missing `goamd64` and before/after hooks only.

**Inventory row affected:** 355 (`msis[]`, `strongly-suggested`, `implemented`). Status should be `partial`.

**Severity:** WARN (fields exist but incomplete; was BLOCKER in my chat summary — revising to WARN here after re-reading config.rs:3443).

---

### B11. `NsisConfig` / `DmgConfig` — missing `goamd64`

**Docs:** `goamd64` is documented on `dmg` and `nsis`.

**Anodize:** `NsisConfig` (`:3487`) and `DmgConfig` (`:3393`) both lack `goamd64`.

**Impact:** on an amd64v3 build matrix, installer filenames and selector logic can't distinguish variants. Users who have `v1` and `v3` amd64 builds coexist see the last-written-wins.

**Severity:** WARN.

---

## WARNs / SUGGESTs

### W1. `signs[].if` render-failure fallback SILENTLY SKIPS signing

**Evidence:** `crates/stage-sign/src/lib.rs:418-426`:
```rust
Err(e) => {
    let reason = format!("if condition render failed: {}", e);
    log.warn(&format!(
        "{} '{}': {} ({}), skipping",
        label, sub_label, reason, condition
    ));
    ctx.remember_skip(label, &sub_label, &reason);
    continue;
}
```

A user's `if: "{{ MISSING_VAR }}"` (typo'd variable) silently skips the sign step with only a WARN log line. The release ships unsigned.

**Why this is wrong:** template render failure of a user-supplied expression is a user-config error, not a skippable runtime condition. The release should abort with a clear error so the user can fix the typo. Continuing-with-warn is the exact "sidestep-the-problem" pattern flagged by `feedback_never_circumvent_problems.md`.

**Recommended fix:** propagate the render error as `anyhow::bail!`. Only the successful-render-to-empty-or-"false" case should skip.

**Severity:** BLOCKER-class — a release shipping unsigned is a security-grade issue, but I'm classifying as WARN here because the mechanism is present and correct for the non-error case.

---

### W2. `release.header.from_url` — no retry, naked 30s timeout, no redirect cap

**Evidence:** `crates/stage-release/src/lib.rs:605-623`. Single-shot `reqwest::blocking` GET with `.timeout(30s)`. No retry, no backoff, no redirect cap, no max-response-size bound.

**Impact:**
- A flaky upstream (500 error or TCP reset) aborts the release stage with no recovery.
- A maliciously-misconfigured URL that returns gigabytes of data blocks memory for 30s.
- An upstream that redirects infinitely exhausts the connection pool.

**Severity:** SUGGEST — add 3-retry with exponential backoff, `Content-Length` cap, `.redirect(Policy::limited(5))`.

---

### W3. Archive hooks — no label disambiguation across multiple archive configs

**Evidence:** `crates/stage-archive/src/lib.rs:1060-1062`:
```rust
if let Some(pre) = archive_cfg.hooks.as_ref().and_then(|h| h.pre.as_ref()) {
    run_hooks(pre, "pre-archive", dry_run, &log, Some(&template_vars))?;
}
```
Label is hardcoded `"pre-archive"` regardless of which archive config (by id) triggered it. Same for `:1564` post-archive.

**Impact:** when a user has 2+ archive configs with different hooks, log output like `running pre-archive hook: make clean` doesn't disambiguate which archive.

**Severity:** SUGGEST — include `archive_cfg.id` in the label: `format!("pre-archive[{}]", id)`.

---

### W4. Partial builds — missing the `GGOOS` vs `GOOS` distinction

**Docs:** https://goreleaser.com/customization/partial/ (fetched 2026-04-16):
- `GOOS` — affects both target filtering AND hooks/commands (sets it in the shell environment)
- `GGOOS` — filters targets only, does NOT affect hooks
- Same for `GOARCH` / `GGOARCH`

**Anodize:** `crates/core/src/partial.rs:68-82` reads `TARGET`, `ANODIZE_OS`, `ANODIZE_ARCH`. Legitimate Rust-specific renames, but there's **no equivalent to the `GGOOS` filter-only semantics.** Every env var in anodize's set is filter+env-set.

**Impact:** a user who wants "filter the build matrix to linux, but let the pre/post hooks see ALL targets" has no affordance. They must either accept single-target hook scope or hand-script the filter outside anodize.

**Inventory row affected:** 383 (Go-specific split, `n-a`). But the *semantic distinction* is a Pro capability anodize drops; inventory doesn't capture the gap.

**Severity:** SUGGEST — add `ANODIZE_OS_FILTER` / `ANODIZE_ARCH_FILTER` to provide the filter-only variant.

---

### W5. Split `context.json` written without atomic rename — partial-failure corrupts state

**Evidence:** `crates/cli/src/commands/release/split.rs:198-201`:
```rust
let json = serde_json::to_string_pretty(&split_ctx).context("serialize split context")?;
std::fs::write(&ctx_path, json)
    .with_context(|| format!("write split context to {}", ctx_path.display()))?;
```

Direct `std::fs::write` without tmp-and-rename. If the CI runner is killed mid-write (common on spot instances, OOM), `context.json` is truncated. The next `anodize continue --merge` run fails with a `serde_json` parse error instead of an actionable "re-run split job X".

**Impact:** poisoned-cache failure mode. The only recovery is to delete and re-run the full split, including steps that did succeed.

**Severity:** SUGGEST (idempotency) — write to `context.json.tmp`, `fsync`, then `rename`. Parse error on merge should also recommend re-running the corresponding split job by name.

---

### W6. `release.tag` override — no sanity check against actual pushed tags

**Evidence:** `crates/stage-release/src/lib.rs:740-760, 1069-1075`. The rendered `release.tag` value goes straight into the GitHub release API's `tag_name`.

**Impact:** if the rendered tag doesn't correspond to a real git tag on any commit, GitHub creates a brand-new tag at `target_commitish` silently. A rendering typo or stale template produces a real ghost tag in the user's repo history.

GoReleaser has the same behavior, so this isn't a parity gap — but the docs don't describe it either, and for a Pro feature charging for polish, silent tag creation is surprising.

**Severity:** SUGGEST — validate that the rendered tag exists in local git, or at minimum log WARN when the API will create a new tag.

---

### W7. Template helper `in` — collides with Tera reserved keyword

**Evidence:** `crates/core/src/template.rs:517-518`:
```rust
tera.register_function("in", ...)
```

Test at `:3091` acknowledges Tera *may reject* `in` as a function name in `{% set %}` context and the test handles either outcome. If Tera's next minor tightens keyword-vs-identifier disambiguation, user templates using `{% set x = in(list, "item") %}` break at runtime.

**Severity:** SUGGEST — pin `tera` to a known-good minor, and register a non-conflicting alias (e.g. `contains_any`). Document `in` as Tera-version-dependent.

---

### W8. `release.header.from_file:` / `release.footer.from_file:` — path NOT rendered through Tera

**Evidence:** `crates/stage-release/src/lib.rs:608`:
```rust
ContentSource::FromFile { from_file } => std::fs::read_to_string(from_file)
    .map_err(|e| anyhow::anyhow!("failed to read {}: {}", from_file, e)),
```
Raw `from_file` string used verbatim as the filesystem path.

**Docs:** say "Templates: allowed" on both `from_file` and `from_url`.

**Impact:** a user with `from_file: "./release-{{ .Tag }}.md"` gets file-not-found on a literal path containing `{{ .Tag }}`.

**Severity:** WARN — docs promise template rendering; we don't deliver.

---

## Confirmed-working Pro features

These were inspected and appear correctly implemented. Listed for A10's confidence in NOT adding them to known-bugs.md.

1. `signs[].if` — skip semantics correct for the non-error cases (`stage-sign/src/lib.rs:404-428`); see W1 for the render-failure path.
2. `release.tag` override wiring (`stage-release/src/lib.rs:740, 1069-1075`), including template rendering and test coverage at `:3080-3130`.
3. `ContentSource::FromFile` / `FromUrl` basic happy-path (lookup and HTTP GET work, modulo B6/W2/W8).
4. `templated_extra_files` wiring in release (`stage-release/src/lib.rs:1210-1218`), dmg, nsis, app_bundle — all four have the field defined and wired.
5. `monorepo.tag_prefix` — `PrefixedTag` / `PrefixedPreviousTag` / `PrefixedSummary` fully implemented with tests (`crates/core/src/context.rs:410-477`; test coverage at `:1768-1973`).
6. `monorepo.dir` — wired at least in changelog (`crates/stage-changelog/src/lib.rs` references `monorepo.dir`).
7. `.IsRelease` template var (`context.rs:519-522`).
8. `.IsMerging` template var (`context.rs:524-528`).
9. `reReplaceAll` function + filter forms (`template.rs:543-594`); tests at `:2865-2958`.
10. `in` template function (`template.rs:517-542`); modulo W7.
11. `.Var.*` custom variables (`config.rs:122`; tests at `template.rs:2449+`).
12. `.Artifacts` structured template variable (`context.rs:594-649`; tests at `:1557-1602`).

Plus: hook env var deserializer (`config.rs:10317+`) accepts both `KEY=val` list form and map form — better than GoReleaser's single-form acceptance.

---

## Deferred — requires live release to fully validate (HANDOFF candidates)

### D1. Partial split/merge end-to-end

The on-disk `context.json` format, artifact survival across workers, and merge-idempotency can only be observed by a real multi-job CI run with separate machines writing/reading the split directory.

**Needs:** GitHub Actions matrix job running `anodize release --split` on {linux, darwin, windows}, uploading `dist/<target>/` as artifacts, then a merge job running `anodize continue --merge` that downloads all of them and reassembles.

**Watch for:**
- `context.json` parse errors (W5)
- artifact-path skew between machines
- template-var preservation across the split→merge boundary

### D2. Native macOS notarize (`MacOSNativeSignNotarizeConfig`)

The `xcrun notarytool` + keychain unlock + `codesign` path requires a signed Apple Developer account and a macOS runner.

The struct shape at `crates/core/src/config.rs:3742-3781` looks right; runtime errors (keychain-locked, notarization timeout, `xcrun` not found, `codesign` identity not present) can only be observed live.

**Needs:** a real DMG or PKG run with a dev cert installed. Watch for: profile-name typo behavior, keychain-unlock failures, `wait: true` timeout handling.

---

## Recommendations for A10 consolidation

All 10 BLOCKERs should be added to `/opt/repos/anodize/.claude/known-bugs.md` and block push until:
1. Each is implemented, OR
2. The inventory (`specs/goreleaser-complete-feature-inventory.md`) is corrected — change `parity_status: implemented` to `partial` or `missing`, with the gap enumerated in the `notes` field.

The WARN/SUGGEST items should also land in known-bugs.md, consistent with the user's rule that every audit finding is tracked regardless of severity label (`feedback_fix_all_issues.md`). W1 in particular should be re-classified to BLOCKER by the lead — silent unsigned-release is a security-grade bug.

The 12 confirmed-working rows are safe for A9 to verify the inventory's claims against.

The 2 deferred items (D1, D2) should be added to `HANDOFF.md` with the exact commands and watch-for artifacts noted above.
