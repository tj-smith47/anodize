---
feature: archives (all formats, name_template, files, format_overrides, wrap_in_directory, templated_files)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Archive stage

## Status: ✅ tested

Covers: `archives[].id/ids`, `format` (singular + `formats` plural), `name_template`, `wrap_in_directory`, `strip_binary_directory`, `allow_different_binary_count`, `files` (string + object shape), `builds_info`, `format_overrides`, `templated_files`, `meta`. Formats: `tar.gz`, `tgz`, `tar.xz`, `txz`, `tar.zst`, `tzst`, `tar`, `gz`, `zip`, `binary`, `none`.

## Evidence

- **Unit tests (30+)**: `crates/stage-archive/src/lib.rs` — `test_create_tar_gz` (L1603), `test_create_zip` (L1616), `test_create_tar_xz` (L1653), `test_create_tar_zst` (L1680), `test_resolve_glob_patterns` (L1745), `test_wrap_in_directory_*` (L1795, L1829, L1846, L1873), `test_archive_stage_zip_for_windows` (L2040), `test_format_for_target_multiple_overrides` (L2561), `test_archive_stage_multiple_binaries_per_archive` (L2593), `test_integration_tar_gz_realistic_file_tree` (L2284), `test_integration_zip_realistic_file_tree` (L2339), `test_integration_tar_xz_realistic_file_tree` (L2382), `test_integration_tar_zst_realistic_file_tree` (L2468).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_multi_format_archive` (L1770), `test_e2e_cross_platform_format_overrides_check` (L2538).
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs` — `test_parse_archive_*` (40+ tests, L812–L1196).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs the 30+ archive unit tests + `test_e2e_multi_format_archive`.
- **Release tag**: v0.2.5 ships `anodize-0.2.5-linux-amd64.tar.gz`, `anodize-0.2.5-darwin-arm64.tar.gz`, `anodize-0.2.5-windows-amd64.zip`, `anodize-0.2.5-windows-arm64.zip`, `anodize-0.2.5-source.tar.gz` — exercises `format_overrides` (windows=zip) and multi-platform tar.gz.
- **Dogfood (cfgd v0.3.5)**: cfgd config at `/opt/repos/cfgd/.anodize.yaml:137` uses `format: tar.gz` + `format_overrides` windows=zip; cfgd release https://github.com/tj-smith47/cfgd/actions/runs/24442230191 ran the full archive pipeline.

## Caveats / known gaps

- `archives[].hooks.before/after` (Pro) is ⚠ partial — anodize uses `hooks.pre`/`post`, docs use `before`/`after`; silent skip. Tracked in `.claude/known-bugs.md` A1-rev entry line 32.
- `meta: true` archive with zero matching files silently emits an empty archive (BLOCKER, known-bugs.md line 58).
