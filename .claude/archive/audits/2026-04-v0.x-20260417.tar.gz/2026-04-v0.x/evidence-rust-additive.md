---
feature: Rust-additive (crates.io, binstall, workspaces, version_sync, SkipMemento, per-packager ConventionalFileName, parallel helper, targets --json, resolve-tag, ANODIZE_CURRENT_TAG env, tag hooks, UPX target-triple)
status: tested
ecosystem_relevance: required/strongly-suggested
tier: Rust-additive
---

# Rust-additive features (beyond GoReleaser)

## Status: ✅ tested

Covers 12 additive features (§3 of inventory): `publish.crates_io`, `binstall`, Cargo-workspace awareness, `version_sync` (Cargo.toml↔tag), `SkipMemento`, `ConventionalFileName` per-packager (nfpm v2.44 closure), `run_parallel_chunks`, `targets --json` subcommand, `resolve-tag` subcommand, `ANODIZE_CURRENT_TAG`/`ANODIZE_PREVIOUS_TAG` env, tag hooks (`tag_pre_hooks`/`tag_post_hooks`), UPX target-triple globs.

## Evidence

- **Unit tests**:
  - crates.io: `crates/stage-publish/src/crates_io.rs` (7 tests).
  - binstall: `crates/stage-publish/src/binstall.rs`.
  - version_sync: `crates/stage-build/src/version_sync.rs`.
  - SkipMemento: `crates/core/src/pipe_skip.rs`.
  - ConventionalFileName: `crates/stage-nfpm/src/filename.rs` (added 2026-04-16 per closure).
  - parallel helper: `crates/core/src/parallel.rs` (`run_parallel_chunks`).
  - `targets`: `crates/cli/src/commands/targets.rs` (inline tests).
  - `resolve-tag`: `crates/cli/src/commands/resolve_tag.rs` (inline tests).
  - Tag hooks: `crates/cli/src/commands/tag.rs` (inline tests).
  - UPX: `crates/stage-upx/src/lib.rs` (target-triple glob).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Live proof per feature**:
  - **crates.io publish**: cfgd v0.3.5 published 4 crates to crates.io (see evidence-publishers-misc.md).
  - **binstall**: cfgd `/opt/repos/cfgd/.anodize.yaml:153` `binstall.enabled: true` shipped in v0.3.5.
  - **Cargo workspaces**: cfgd 4-workspace monorepo shipped 4 separate releases on 2026-04-15 (see evidence-git-monorepo.md).
  - **version_sync**: cfgd + anodize both use `version_sync.enabled: true` + `mode: cargo`. Recent fix `ce3e396` "version_sync updates workspace deps, respects Cargo.toml version, skips CI" shipped in v0.2.5.
  - **SkipMemento**: wired into every stage via `ctx.should_skip()`; `commands/build.rs` uses it for optional binary-sign gating.
  - **ConventionalFileName**: nfpm assets on v0.2.5 follow per-format conventions (`anodize_0.2.5_linux_amd64.deb` vs `anodize-0.2.5-1.src.rpm`).
  - **Parallel helper**: used in 10 stages (per inventory); live-proven by the parallelized blob/publisher/announce/sign fan-outs in cfgd's multi-crate release (run `24442230191`).
  - **`targets --json`**: consumed by anodize-action as matrix strategy input — https://github.com/tj-smith47/anodize-action/actions/runs/24409150253 (success).
  - **`resolve-tag`**: cfgd release.yml L36 calls `resolve-workspace: 'true'` on every tag push; run https://github.com/tj-smith47/cfgd/actions/runs/24442229349 (success) resolved `core-v0.3.5` → `cfgd-core` workspace.
  - **`ANODIZE_CURRENT_TAG`**: used in CI auto-tag step; commit `010388fb` "add `anodize tag` command" wired it.
  - **Tag hooks**: anodize CI's auto-tag step at ci.yml L104 runs `anodize tag` which invokes `tag_pre_hooks`/`tag_post_hooks` — live-proven by v0.2.x tags being created on master push.
  - **UPX target-triple glob**: anodize v0.2.5 binaries are UPX-compressed; config uses Rust target triples at `/opt/repos/anodize/.anodize.yaml:488`.

## Caveats / known gaps

- Retry-for-uploads candidate (§3 row 8) remains not-yet-implemented; listed as candidate in inventory.
