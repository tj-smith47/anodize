---
feature: project_name/dist/metadata/env/env_files/variables/template_files/includes/snapshot/nightly
status: partial
ecosystem_relevance: required/strongly-suggested/niche
tier: OSS+Pro
---

# Project metadata / global env / template files / includes / snapshot / nightly

## Status: 🟡 partial (project_name/dist/env/snapshot tested; metadata Pro fields partial; nightly lightly tested)

Covers: `project_name`, `dist`, `metadata.*` (mod_timestamp/maintainers/license/homepage/description — Pro), `env` global list, `env_files` (github_token/gitlab_token/gitea_token), `variables` (custom), `template_files[]` (Pro), `includes[].from_file/from_url` (Pro), `snapshot.name_template`, `nightly` (Pro).

## Evidence

- **Unit tests**: `crates/core/src/config.rs` (struct + default), `crates/stage-templatefiles/src/lib.rs` (template rendering), `crates/core/src/git.rs` (ANODIZE_CURRENT_TAG / ANODIZE_PREVIOUS_TAG handling).
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs::test_parse_project_name_*` (L17–L52), `test_parse_dist_*` (L62–L99).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_auto_snapshot_dirty_repo` (L3322), `test_e2e_init_generates_parseable_yaml` (L887), `test_e2e_snapshot_version_in_artifacts` (L2587).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release proof**: anodize v0.2.5 ships `metadata.json` (128 bytes) + `artifacts.json` (11652 bytes) as release assets — confirms metadata + artifact manifest emit.
- **anodize config**: `/opt/repos/anodize/.anodize.yaml:37` `metadata:` block; `:502` `nightly:`; `:506` `snapshot:`.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:16` `variables:` block; `:12` `env:`; `:521` `template_files` with `install-script` template rendered into `install.sh` (lives in release assets). `/opt/repos/cfgd/.anodize.yaml:44` `metadata:` block.

## Caveats / known gaps

- `metadata.full_description.from_url`/`from_file` + `metadata.commit_author` Pro fields ❌ **missing** — known-bugs.md A1-rev line 37.
- `metadata.{homepage,license,description,maintainers}` collected but not consumed — known-bugs.md A1-rev line 39 (config-without-wiring).
- `nightly` Pro feature has `NightlyConfig` wiring + `--nightly` CLI flag, but **no live nightly release exists** — release tag list shows only `v*` semver tags, no nightly date-stamped releases. Would need a scheduled workflow to produce live proof.
