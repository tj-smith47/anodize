---
feature: announcers (discord/slack/telegram/teams/mattermost/webhook/smtp/reddit/twitter/mastodon/bluesky/linkedin/opencollective/discourse)
status: partial
ecosystem_relevance: strongly-suggested/niche
tier: OSS
---

# Announce providers (13 channels)

## Status: 🟡 partial (all 13 unit-tested; only webhook + smtp dogfooded live)

Covers: discord, slack (channel/blocks/attachments), telegram (parse_mode MarkdownV2/HTML + message_thread_id), teams (AdaptiveCard), mattermost, webhook (custom HTTP broadcast), smtp (email), reddit, twitter, mastodon (form-encoded POST), bluesky (AT Proto), linkedin, opencollective, discourse.

## Evidence

- **Unit tests (118 across 13 files)**: `crates/stage-announce/src/` — discord (4), slack (3), telegram (5), teams (6, AdaptiveCard), mattermost (7), webhook (6), email (6), reddit, twitter (8), mastodon, bluesky (2), linkedin (1), opencollective (1), discourse (2), lib.rs aggregate (67).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs all announcer unit tests.
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:581` `announce:` block.
- **Dogfood — webhook + smtp (live announce proof)**: cfgd v0.3.5 at `/opt/repos/cfgd/.anodize.yaml:530` configures `webhook` (to `https://tj.jarvispro.io/webhooks/anodize`) and `email` (smtp.gmail.com:587). Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success, 2026-04-15) with `SMTP_PASSWORD` secret — webhook POST + email send executed end-to-end.

## Caveats / known gaps

- **11 of 13 channels unexercised live**: discord, slack, telegram, teams, mattermost, reddit, twitter, mastodon, bluesky, linkedin, opencollective, discourse — **no release has posted to any of these**. Status: tests pass, but no workflow run URL shows a real announce. Would need a dogfood release with each channel enabled + secrets configured.
- **smtp default port warning**: BLOCKER in `.claude/known-bugs.md` line 109 — `smtp_port.unwrap_or(587)` silently defaults; GoReleaser requires explicit port. Surface caveat on announce dogfood.
