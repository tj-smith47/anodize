---
feature: build (cargo/cross/zigbuild, targets, hooks, upx, universal_binaries, prebuilt, reportsizes, partial builds, overrides)
status: tested
ecosystem_relevance: required
tier: OSS
---

# Build stage

## Status: ✅ tested

Covers: `builder: rust`, `builder: prebuilt`, `build.id`, `build.binary`, `build.dir`, `build.command`, `build.flags`, `build.env`, `build.tool`, `build.targets`, `build.mod_timestamp`, `build.overrides`, `build.hooks.pre/post`, `build.skip`, `build.no_unique_dist_dir`, `universal_binaries`, `upx`, `--single-target`, `prebuild pipe`, `reportsizes`.

## Evidence

- **Tests (integration, 60+)**: `crates/cli/tests/integration.rs` — `test_e2e_snapshot_release_produces_artifacts` (L632), `test_e2e_build_command_matches_goreleaser_pipeline_outputs` (L3617), `test_e2e_workspace_snapshot_produces_artifacts` (L1046), `test_e2e_report_sizes` (L3546), `test_e2e_before_hooks_execute` (L3368).
- **Unit tests (stage-build, stage-upx)**: `crates/stage-build/src/` and `crates/stage-upx/src/lib.rs` — architecture detection, target-triple handling, `mod_timestamp`, `universal_binaries` via `lipo`.
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15, commit `128e003`). Builds on ubuntu/macos/windows; uploads `anodize-linux` artifact consumed by release split jobs.
- **Release workflow — split builds on 3 OS**: https://github.com/tj-smith47/anodize/actions/runs/24441952862 — the `Build (ubuntu-latest)`, `Build (macos-latest)`, `Build (windows-latest)` jobs completed successfully for v0.2.5, each running `anodize release --split --clean` with `zig,cargo-zigbuild,upx` installed. Exercises cross-compilation, zigbuild tool resolution, and UPX.
- **Release tags**: v0.1.x (v0.1.1–v0.1.4, 2026-04-12) and v0.2.x (v0.2.0–v0.2.5, 2026-04-15) — Linux/macOS/Windows amd64+arm64 binaries shipped; 6 target triples × 7 releases verified.
- **Artifact proof (anodize v0.2.5)**: https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 ships `anodize-0.2.5-{linux,darwin,windows}-{amd64,arm64}.{tar.gz,zip}` (6 archives).
- **Dogfood (cfgd v0.3.5)**: https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (2026-04-15, success) ran `anodize release --split --crate cfgd` on all 3 OS matrices producing cross-OS builds for cfgd's 4-crate workspace.

## Caveats / known gaps

None for the build stage itself. Binary-sign + notarize-during-build added 2026-04-16 via `BinarySignStage` in `crates/stage-sign` (known-bugs.md resolved at line 244).
