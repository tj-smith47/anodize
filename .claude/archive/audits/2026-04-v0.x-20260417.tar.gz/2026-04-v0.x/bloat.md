# Bloat candidates — anodize v0.x audit wave (2026-04)

Rows flagged by parity auditors where `parity_status=implemented AND ecosystem_relevance=not-applicable`, requiring second-reviewer countersign before `disposition=remove` lands in the inventory.

Per Wave A shared format:

```
- name: <row name from inventory>
  category: <category from inventory>
  auditor: <auditor name>
  reason: <why flagged — one sentence>
  countersigned_by: <reviewer + date>   # OR
  countersign_rejected: <reason + date>
```

---

## Publishers slice (A3, parity-auditor-publishers)

**No bloat candidates.** Every audited publisher row in sections 2.4 / 2.7 / 2.8 / 2.9 / 2.10 / 2.11 / 2.12 + blob traces to a live config surface consumed by at least one packager / SCM / broadcaster path. `not-applicable` rows (e.g., `ko` — Go-source-to-container) are correctly categorized and have no anodize implementation to remove.
