---
feature: Tera templating + all template helpers (string/path/filter/version/env/hash/file/data/encoding/misc/Pro)
status: tested
ecosystem_relevance: required
tier: OSS+Pro+Rust-native
---

# Template helpers (Tera-backed)

## Status: ✅ tested

Covers: Tera engine (Rust-native replacement for Go text/template + pre-processor bridge), string/path/filter/version/env helpers, hash functions (blake2b/2s/3, crc32, md5, sha1/224/256/384/512, sha3_*), file I/O (`readFile`/`mustReadFile`), data structures (list/map/indexOrDefault), encoding (mdv2escape/urlPathEscape), misc (time/englishJoin), Pro helpers (`in`/`reReplaceAll`), `.Now.Format` preprocessor, full variable set (`.ProjectName`/`.Version`/`.Tag`/`.Major`/`.Minor`/`.Patch`/...), Pro variables (`.PrefixedTag`/`.Artifacts`/`.Metadata`/`.Var`/`.IsMerging`/`.IsRelease`), custom `.Var.*`.

## Evidence

- **Unit tests**: `crates/core/src/template.rs` — all helper functions, Tera integration, variable population, pre-processor rewrite of `.Now.Format`.
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_config_validation_round_trip` (L2133), `test_e2e_snapshot_version_in_artifacts` (L2587) (exercises `{{ Version }}` + `{{ Tag }}` in name_template).
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs::test_parse_crate_tag_template_tera_syntax` (L490), `test_parse_crate_tag_template_go_style` (L506), `test_parse_crate_tag_template_with_prefix` (L545).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Live proof (all templates rendered)**: every release asset name on anodize v0.2.5 + cfgd v0.3.5 is produced by a template:
  - `anodize-0.2.5-linux-amd64.tar.gz` = `{{ ProjectName }}-{{ Version }}-{{ Os }}-{{ Arch }}.tar.gz`
  - `anodize-0.2.5-checksums.txt` = `{{ ProjectName }}-{{ Version }}-checksums.txt`
  - cfgd crates use `{{ RawVersion }}`, `{{ Tag }}`, Pro `{{ .Artifacts }}` vars in docker_manifests and release names.
- **Dogfood (cfgd v0.3.5)**: cfgd uses `{{ ProjectName }}`, `{{ Version }}`, `{{ RawVersion }}`, `{{ Tag }}`, `{{ Os }}`, `{{ Arch }}`, `{{ Signature }}`, `{{ Artifact }}`, `{{ Env.GPG_FINGERPRINT }}`, `{{ ReleaseURL }}` across its config (all rendered at https://github.com/tj-smith47/cfgd/actions/runs/24442230191 success).

## Caveats / known gaps

None — Tera template surface is stable and covered. Recent fix `94d9417` "support Tera-native tag_template in tag matching, remove last TODO" tied up the last edge case.
