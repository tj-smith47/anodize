# Audit Wave Status — 2026-04-v0.x

Updated by the audit teams as they run. `/audit-wave` router reads this to pick the next incomplete wave.

## Wave A — anodize parity (CLI)

- [x] A1 — `goreleaser-inventory-mapper` refreshed inventory with `ecosystem_relevance` + `disposition` columns AND emitted the completion statement block (initial pass; A1-rev applied after A5 countersign)
- [x] A2 — `parity-auditor-build-archive` findings written (3 BLOCKER, 3 WARN, 2 SUGGEST)
- [x] A3 — `parity-auditor-publishers` findings written (0 BLOCKER, 7 WARN, 6 SUGGEST)
- [x] A4 — `parity-auditor-announcers` findings written (4 BLOCKER, 3 WARN, 8 INFO)
- [x] A5 — `pro-features-skeptic` all qualifying Pro features audited; `pro-features-audit.md` written (11 BLOCKER, 8 WARN/SUGGEST, 12 confirmed-working, 2 deferred to HANDOFF)
- [x] A6 — `rust-safety-scanner` findings written to `safety.md` (1 BLOCKER, 4 WARN, 6 SUGGEST). Bloat countersign no-op (zero candidates).
- [x] A7 — `dedup` skill run complete, findings in `dedup.md` (7 BLOCKER, 7 SUGGEST)
- [x] A8 — `pro-features-skeptic` Pro bloat countersign no-op (zero Pro `disposition=remove` candidates in `bloat.md`)
- [x] A9 — Inventory completion statement read; result is `Completion achieved: **no**`. Per audit-wave-a procedure the lead does NOT bless full completion. Remediation backlog enumerated below as unchecked items.
- [x] A10 — Lead consolidated all BLOCKER+WARN+SUGGEST findings into `anodize/.claude/known-bugs.md` (per global rule #2 — every finding tracked). Anodize-action findings consolidated into `anodize-action/.claude/known-bugs.md`. Bloat candidates: 0 (so no human-decision rows added).

## Implementation backlog (NOT audit items — do not re-trigger Wave A)

These are implementation TODOs derived from A5 + A1-rev. They are tracked in `anodize/.claude/known-bugs.md` (Active section, A1-rev subsection) and are the canonical work items. The router treats Wave A as complete (A1-A10 ticked above); these unchecked lines are intentionally OUT of the Wave A items list so `/audit-wave` advances to Wave B. Re-running `/audit-wave-a` after these are fixed will reverify and flip the inventory to `completion=yes`.

- 11 Rust-appropriate inventory rows flipped to `partial`/`missing` after A5 countersign; full list in `known-bugs.md` (A1-rev subsection). Summary: 5 `if` fields on installer configs (DMG/MSI/PKG/NSIS/AppBundle), `nfpm.if`, `nfpm.templated_contents`+`templated_scripts`, archive hooks `before`/`after` serde alias + silent-skip fix, release header/footer URL `headers`+auth+template-render, `MetadataConfig.full_description`+`commit_author`+wiring of existing fields to publishers, MSI `goamd64`+`hooks`, NSIS `goamd64`, CLI `--prepare`.

## Wave A — anodize-action parity (tracked in `/opt/repos/anodize-action/.claude/audits/2026-04-v0.x/wave-status.md`)

A8–A10 live there; all 3 ticked.

## Wave C — dogfooding evidence

- [x] C1 — `evidence-collector` wrote 29 evidence files + `evidence-INDEX.md` to `.claude/audits/2026-04-v0.x/` (19 ✅ tested / 9 ⚠ partial / 1 ❌ untested at evidence-file granularity)
- [x] C2 — `feature-matrix-builder` produced `docs/site/content/dogfooding/_index.md` (5,663 words; 174 ✅ / 46 ⚠ / 13 ❌ at row granularity). `zola check` passed (92 pages, 0 orphan).
- [x] C3 — `anodize/README.md` links to `https://tj-smith47.github.io/anodize/dogfooding/` under the "Written by Claude" line (README.md:9). Top-nav entry added in `docs/site/templates/base.html`.

## Notes

Wave B (cfgd audit) status lives in `/opt/repos/cfgd/.claude/audits/2026-04-v0.x/wave-status.md`.
