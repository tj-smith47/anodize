---
feature: sboms[] (syft) + source archive + source.templated_files
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# SBOMs + Source archive

## Status: ✅ tested

Covers: `sboms[]` (cmd/args/env/artifacts/ids/disable/documents) with `${artifact}`/`${document}`/`${artifactID}` templates; `source archive` (format/name_template/files/enabled); `source.templated_files` (Pro).

## Evidence

- **Unit tests**: `crates/stage-sbom/src/` (subprocess syft invocation, document naming), `crates/stage-source/src/lib.rs` (source tarball generation, templated files).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag (live SBOM + source proof)**: anodize v0.2.5 ships `anodize-0.2.5.cdx.json` (CycloneDX SBOM, 106484 bytes) and `anodize-0.2.5-source.tar.gz`. https://github.com/tj-smith47/anodize/releases/tag/v0.2.5
- **anodize config**: `/opt/repos/anodize/.anodize.yaml:473` `source:` + `:484` `sbom:` blocks.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:497` `source.enabled: true`, `format: tar.gz`, `name_template`, `files` glob; `:508` `sbom.enabled: true`, `format: cyclonedx`. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success).

## Caveats / known gaps

None — SBOM + source archive shipped live on 7 anodize releases and 4 cfgd releases.
