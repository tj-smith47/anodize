# Dedup sweep — anodize crates/ (2026-04-16)

Scope: `/opt/repos/anodize/crates/` (28 crates). Phase 1 discovery run across
hash/checksum, URL encoding, template rendering (Tera), id/name artifact filtering,
commit-message rendering, retry/backoff, extra-file resolution, human-size formatting,
and project-name inference.

Severity key:
- **BLOCKER** — copies can diverge in meaningful (bug-producing) ways. Evidence of
  existing divergence is preferred but not required; if the copies are >5 lines and
  independently evolvable, assume divergence is just a matter of time.
- **SUGGEST** — duplication is mechanical/small, low divergence risk, but collapsing
  still reduces code surface.

---

## 1. BLOCKER — Artifact id+name filter duplicated across 9+ packaging stages

**Shape:** identical (copy-paste; 8–12 lines each)

**Locations:**
- `crates/stage-nsis/src/lib.rs:131-146` — NSIS
- `crates/stage-dmg/src/lib.rs:200-215` — DMG
- `crates/stage-msi/src/lib.rs:298-313` — MSI
- `crates/stage-pkg/src/lib.rs:151-166` — PKG
- `crates/stage-flatpak/src/lib.rs:241-256` — Flatpak
- `crates/stage-appbundle/src/lib.rs:270-285` — AppBundle
- `crates/stage-blob/src/lib.rs:518-535` — Blob (same logic, inline in filter closure)
- `crates/stage-sign/src/lib.rs:502-518` — Sign
- `crates/stage-sign/src/lib.rs:1100-1115` — Sign (second copy in same file)
- `crates/stage-upx/src/lib.rs:42-53` — UPX (via `should_compress`)
- `crates/stage-publish/src/util.rs:1158-1178` — `filter_by_ids` (already a helper — but **only checks `"id"`, not `"id" || "name"`**, so publishers and packagers diverge on semantics)

**Why BLOCKER:** a real divergence already exists. `filter_by_ids` in
stage-publish checks only `metadata["id"]`; every packaging-stage copy checks
`metadata["id"] || metadata["name"]`. GoReleaser accepts both. This means an
artifact named via `name_template` (setting `"name"` metadata but not `"id"`)
is matched by NSIS/DMG/MSI/flatpak but silently dropped by publisher
`filter_by_ids`. Any future change to the matching rule (e.g. adding a third
metadata key, or changing the fallback) will need to touch 10 sites and will
miss at least one.

**Suggested consolidation:** Add a canonical helper to `anodize-core`
(probably `core::artifact::matches_id_filter(artifact, ids) -> bool`):

```rust
pub fn matches_id_filter(artifact: &Artifact, ids: &[String]) -> bool {
    if ids.is_empty() { return true; }
    artifact.metadata.get("id").map(|v| ids.contains(v)).unwrap_or(false)
        || artifact.metadata.get("name").map(|v| ids.contains(v)).unwrap_or(false)
}
```

Then replace all 10+ sites and fix `stage-publish::util::filter_by_ids` to
delegate (making it match GoReleaser semantics). Target crate: **core**.

---

## 2. BLOCKER — SHA-256 file hashing duplicated outside stage-checksum

**Shape:** near-identical (same 8 KiB streaming loop; differs only in error
messages and return format `{:x}` vs lowercase hex)

**Locations:**
- `crates/stage-checksum/src/lib.rs:24-45` — canonical `hash_file_with<D>` + `sha256_file`
- `crates/stage-publish/src/artifactory.rs:31-46` — local `sha256_file` (10 lines verbatim; different error labels)
- `crates/stage-notarize/src/lib.rs:40-68` — inline hash loop inside `refresh_darwin_sha256`; logs warnings instead of returning

**Why BLOCKER:** three independent implementations of the same cryptographic
primitive. stage-checksum has the widest coverage (SHA-1/224/384/512, Blake2,
Blake3, SHA-3, MD5, CRC32); the other two only handle SHA-256 and will silently
drift if the hash-loop changes (e.g., buffer sizing tuned for large files,
memory-map fallback, or a bug fix in error handling). Security-adjacent code;
one canonical source is mandatory.

**Suggested consolidation:** Promote `stage-checksum::sha256_file` (and the
generic `hash_file_with<D>`) to `anodize-core` (e.g., `core::hashing`), then
have stage-checksum, stage-publish, stage-notarize all call through it.
Alternatively keep in stage-checksum and have the other two depend on it
directly. Target crate: **core** (preferred — stage-checksum can keep format
helpers; `stage-notarize` shouldn't depend on stage-checksum).

---

## 3. BLOCKER — Three separate percent-encoding implementations

**Shape:** semantic (all encode URL components; different AsciiSets / different
algorithms)

**Locations:**
- `crates/stage-release/src/lib.rs:23-39` — `percent_encode_path` using
  `percent_encoding::CONTROLS` + explicit AsciiSet (correct, RFC-3986 pchar)
- `crates/stage-announce/src/twitter.rs:103-114` — `percent_encode` hand-rolled
  (OAuth 1.0 reserved set: unreserved + `-._~`; everything else %-encoded)
- `crates/cli/src/commands/release/milestones.rs:269-282` — `url_encode` hand-rolled
  (identical algorithm to twitter.rs except `~` ordering)

**Why BLOCKER:** two of these hand-roll URL encoding. They are near-identical
(twitter.rs and milestones.rs differ only in byte comparison order), but neither
uses the `percent_encoding` crate already in scope. Twitter OAuth in particular
has strict encoding requirements — silent drift from the RFC-3986 pchar set is a
signing-failure waiting to happen. The divergence is already latent:
milestones.rs lists `-_.~` (order A), twitter.rs lists `-._~` (order B).

**Suggested consolidation:** Either (a) move `percent_encode_path` to
`anodize-core::util` and use it everywhere, or (b) standardize all three on the
`percent_encoding` crate directly with named AsciiSets for path vs form vs OAuth
contexts. Twitter OAuth should *not* use path-segment encoding (the reserved set
is different). Target: **core** for the generic helper; twitter.rs still needs
its OAuth-specific set but should use `percent_encoding` constants, not hand-roll.

---

## 4. BLOCKER — `ExtraFile` vs `ExtraFileSpec` — two types for the same concept

**Shape:** same-intent, different struct shapes

**Locations:**
- `crates/core/src/config.rs:1222-1246` — `ExtraFileSpec` (untagged enum: `Glob(String) | Detailed { glob, name_template }`)
- `crates/core/src/config.rs:3640-3646` — `ExtraFile` (flat struct: `{ glob, name }` with serde alias `name_template`)

Both are "a glob pattern plus optional output-name template." `ExtraFileSpec`
supports the shorthand string form (`"*.txt"`); `ExtraFile` does not.
`ExtraFileSpec` uses `name_template`; `ExtraFile` uses `name` with alias.

**Why BLOCKER:** user-facing config surface duplication. A user who learns
"extra files take a shorthand glob string" from checksum config will be
surprised when blob config rejects the same syntax. The two are used by
different stages but describe the identical domain concept. Resolver helpers
are also duplicated (see Finding #5).

**Suggested consolidation:** Pick one (preferably `ExtraFileSpec`, which is the
more flexible form and already the more common type), delete the other, migrate
`stage-blob` to use `ExtraFileSpec`. Target crate: **core** (consolidation is
in the config module itself).

---

## 5. BLOCKER — Duplicated `resolve_extra_files` glob-resolver

**Shape:** near-identical (both enumerate a glob, dedupe by PathBuf, handle
name_template)

**Locations:**
- `crates/stage-checksum/src/lib.rs:180-215` — `resolve_extra_files(specs: &[ExtraFileSpec])`
- `crates/stage-blob/src/lib.rs:445-487` — `resolve_extra_files(extra_files: &[ExtraFile], ctx, log)`
- `crates/stage-appbundle/src/lib.rs:85` — `copy_extra_files` (related; appbundle just copies rather than uploads)

**Why BLOCKER:** both implement the same algorithm (glob → filter files →
render name template → return). They diverge on:
- checksum dedupes across specs (HashSet); blob does not
- checksum sorts the output; blob does not
- checksum bails when `name_template` is set and glob matches >1; blob does not (silent bug risk)
- blob warns on empty matches; checksum does not

These divergences are all semantically load-bearing bugs waiting to surface.
Once Finding #4 collapses the type into one, this collapses too.

**Suggested consolidation:** After #4, one `resolve_extra_files` helper in
`anodize-core::util` taking `&[ExtraFileSpec]` + `&Context` + `&StageLogger`,
with the most-strict behavior (GoReleaser-matching: error on multi-match with
name_template, warn on zero matches, dedupe, sort). Target crate: **core**.

---

## 6. BLOCKER — Ad-hoc `tera::Tera::default()` rendering instead of `ctx.render_template`

**Shape:** same-intent (each callsite: create Tera → autoescape_on(vec![]) →
add_raw_template → build Context → render)

**Locations (non-template-engine code creating its own Tera instance):**
- `crates/stage-publish/src/homebrew.rs:302` — render formula template
- `crates/stage-publish/src/homebrew.rs:946` — render cask template
- `crates/stage-publish/src/homebrew.rs:1302` — `render_commit_msg`
- `crates/stage-publish/src/util.rs:1189` — `render_url_template`
- `crates/stage-publish/src/winget.rs:46` — `render_winget_commit_msg`
- `crates/stage-publish/src/nix.rs:302` — render nix derivation
- `crates/stage-publish/src/chocolatey.rs:146` — render nuspec
- `crates/stage-publish/src/chocolatey.rs:229,243` — render install scripts

(Legitimate uses in `core/src/template.rs:135` and `xtask/src/gen_docs.rs:16`
are excluded — those are the template-engine itself and a documentation tool.)

**Why BLOCKER:** the project already exposes `ctx.render_template` (core) and
`template::render(template, &TemplateVars)` (core/src/template.rs:1428) which
include the full GoReleaser preprocessing pipeline (dot-stripping, list
rewriting, Go block syntax, positional → named-arg, etc., per
`template_preprocess.rs`). Publishers bypassing that layer means **any Go-style
syntax in user config (`{{ .ProjectName }}`, `{{ if eq .Os "linux" }}`, etc.)
fails silently in publisher templates**. Per the
`feedback_use_tera.md` memory: user explicitly wants the tera crate path used
uniformly, not hand-rolled parallel instances. This is the exact anti-pattern
that memory is about.

**Suggested consolidation:** Add a shared helper, e.g.
`core::template::render_with_extra_vars(template, ctx, extra: &[(&str, &Value)]) -> Result<String>`
that (a) runs preprocessing and (b) lets callers inject publisher-specific
variables (`name`, `version`, `arch`, `os`, `PackageIdentifier`, etc.) on top
of the context's template_vars. Every publisher switches to it. Target crate:
**core**.

---

## 7. BLOCKER — Duplicated retry/backoff loops (exponential backoff, capped)

**Shape:** near-identical

**Locations:**
- `crates/stage-release/src/lib.rs:345-373` — canonical `retry_upload<F, Fut>`
  (10 attempts, 50ms→30s capped exponential, async, GoReleaser parity)
- `crates/stage-release/src/lib.rs:2165-2260` — **second copy** of the same loop
  inline inside GitHub upload path (separate constants, separate `INITIAL_RETRY_DELAY` /
  `MAX_RETRY_DELAY`, but identical algorithm)
- `crates/stage-publish/src/crates_io.rs:143-190` — retry loop with different
  constants (5s initial, cap at 60s, 3 attempts)
- `crates/stage-docker/src/lib.rs:825-990` — Docker retry loops (multiple
  copies inside build/push/manifest-push paths)
- `crates/stage-release/src/gitlab.rs:319-383` — conditional retry on 409
  (different pattern, arguably single-retry rather than exponential backoff —
  still a divergent path)

**Why BLOCKER:** #1 and #2 are inside the *same file* (stage-release). The
second copy doesn't even call the first. That is already a bug-waiting-to-happen:
a fix to `retry_upload` won't reach the GitHub inline copy. The docker retry
loops additionally have their own `resolve_retry_params` machinery. A
generalized `retry_with_backoff<F, Fut, Out>(params, op_name, f)` would serve
all of them.

**Suggested consolidation:** Add `core::retry::retry_with_backoff` taking a
`RetryParams { max_attempts, initial_delay, max_delay, should_retry: fn(&Err) -> bool }`.
Canonical-ize:
1. stage-release's inline GitHub retry → `retry_with_backoff`
2. stage-release's `retry_upload` → thin wrapper
3. crates_io.rs retry → `retry_with_backoff` with its own params
4. stage-docker's retry loops → `retry_with_backoff`

Target crate: **core** (new `core::retry` module).

---

## 8. SUGGEST — Two `format_size` byte-formatter implementations

**Shape:** near-identical

**Locations:**
- `crates/core/src/artifact.rs:426-441` — canonical (`B`/`KB`/`MB`/`GB`, space separator, `"4.2 MB"`)
- `crates/stage-upx/src/lib.rs:16-24` — local (`B`/`KB`/`MB` only — no GB!; no space, `"4.2MB"`)

**Why SUGGEST:** divergence on both the output format (space) and the
supported range (no GB in upx). Low-stakes (presentation-only) but inconsistent
CLI output. The upx one is strictly less capable.

**Suggested consolidation:** Delete `stage-upx::format_size`, import
`anodize_core::artifact::format_size`. Or move both to a new
`core::util::format_bytes` if the signature needs tweaking. Target crate:
**core**.

---

## 9. SUGGEST — Inline `tera::Tera::default()` render-commit-msg variants

**Shape:** near-copy

**Locations:**
- `crates/stage-publish/src/homebrew.rs:1268-1316` — `render_commit_msg`
- `crates/stage-publish/src/homebrew.rs:1278-1340` — `render_commit_msg_with_prev`
- `crates/stage-publish/src/winget.rs:41-59` — `render_winget_commit_msg`
- `crates/stage-publish/src/scoop.rs:445-458` — calls `homebrew::render_commit_msg` with custom default template for Scoop

**Why SUGGEST:** winget has its own render function only because it needs
`PackageIdentifier` in scope. Scoop *already* routes through
`homebrew::render_commit_msg` with a custom template string. Winget could do
the same if `render_commit_msg` accepted extra vars. Subsumed by Finding #6
once that helper lands.

**Suggested consolidation:** Collapse into Finding #6's
`render_with_extra_vars`; each publisher supplies its own default template
string and its own extra vars. Target crate: **stage-publish** (with core
helper from #6).

---

## 10. SUGGEST — Duplicated ad-hoc Tera rendering for per-publisher manifests

**Shape:** structural (each publisher's *manifest* rendering is its own template + Tera instance)

**Locations:** same as Finding #6 but scope narrowed to the non-commit-message
cases — homebrew formula/cask rendering, chocolatey nuspec + install scripts,
nix derivation, artifactory URL template.

**Why SUGGEST:** these are legitimately per-publisher (each manifest format is
different). However, each construct its own Tera instance, each duplicates
`autoescape_on(vec![])` / `add_raw_template` / `render`, and none of them runs
through the preprocessor. Same root cause as #6 but for larger templates.

**Suggested consolidation:** Same helper as #6, plus consider moving the
`NUSPEC_TEMPLATE`, `FORMULA_TEMPLATE`, `NIX_TEMPLATE` constants into a shared
`stage-publish::templates` module. Target crate: **stage-publish**.

---

## 11. SUGGEST — `is_disabled` helper reimplemented per stage

**Shape:** near-copy (each wraps `StringOrBool::is_disabled(|s| ctx.render_template(s))`)

**Locations:**
- `crates/stage-checksum/src/lib.rs:221-235` — with log side effect
- `crates/stage-blob/src/lib.rs:434-439` — pure, returns `Result<bool>`
- `crates/core/src/config.rs:5215-5217` — `StringOrBool::is_disabled(render)` — the canonical trait-like method

Plus many inline `d.is_disabled(|s| ctx.render_template(s))` calls scattered
across stages (docker, sign, flatpak, srpm, nsis, sbom, upx) — all calling the
`StringOrBool` method directly, bypassing both helpers.

**Why SUGGEST:** the project has three tiers of API for the same check:
- inline `.is_disabled(|s| ctx.render_template(s))` — most common
- `crate::is_disabled(&Option<StringOrBool>, &Context, ...)` — stage-blob & checksum
- none of them logs consistently

Mechanical duplication; low divergence risk because the core logic is in
`StringOrBool::is_disabled`. But the log-on-disable side effect varies
(checksum logs, blob doesn't), and the signature varies (`Result<bool>` vs
`bool`).

**Suggested consolidation:** Add a single canonical
`core::config::is_disabled_with_log(opt: &Option<StringOrBool>, ctx, log, label) -> Result<bool>`
and delete per-stage copies. Inline call sites can stay (they're one-liners),
but the "gated + log + handle error" pattern should have one home. Target
crate: **core**.

---

## 12. SUGGEST — `render_opt` / `render_optional` template-rendering helpers

**Shape:** identical (one-line wrappers around `ctx.render_template`)

**Locations:**
- `crates/stage-notarize/src/lib.rs:108-113` — `render_opt`
- `crates/stage-announce/src/lib.rs:58-63` — `render_optional`

**Why SUGGEST:** two 5-line functions, same body, different names. Low
divergence risk but trivially consolidatable.

**Suggested consolidation:** Add
`core::context::Context::render_template_opt(&self, Option<&str>) -> Result<Option<String>>`,
delete both wrappers. Target crate: **core**.

---

## 13. SUGGEST — Project-name inference (known case) — already deduped ✓

**Shape:** was duplicated, is now single-source.

**Locations:**
- `crates/cli/src/commands/helpers.rs:618-632` — `infer_project_name` (canonical)
- Callers: `cli/src/commands/build.rs:38`, `continue_cmd.rs:30`, `release/mod.rs:99`, `check.rs:34`

**Status:** Team-lead flagged this as a known duplication. Phase 1 confirmed
it is **already consolidated** into one function with four callers. No action
needed — noting here so it's not re-raised by future sweeps.

Leaving as an informational entry rather than a finding.

---

## 14. SUGGEST — `find_binary` / `which_exists` thin wrapper

**Shape:** wrapper

**Locations:**
- `crates/core/src/util.rs:112-146` — canonical `find_binary`
- `crates/stage-announce/src/email.rs:170-173` — `which_exists` (pure forward to `find_binary`)

**Why SUGGEST:** per the skill's wrapper-decision rule, a no-logic wrapper
that just renames should be deleted. `which_exists` adds zero logic.

**Suggested consolidation:** Delete `which_exists`, inline
`anodize_core::util::find_binary` at the call site. Target crate:
**stage-announce** (just delete the wrapper).

---

## Phase 2 summary

**Priority order (by divergence blast radius):**

1. **Finding #1** — id+name filter (10+ sites, already divergent with `filter_by_ids`) — user-facing matching bug.
2. **Finding #2** — SHA-256 hashing (3 copies, security-adjacent) — correctness.
3. **Finding #6** — ad-hoc Tera (8 sites, skips preprocessor) — user config behavior.
4. **Finding #7** — retry/backoff (2 copies in same file + 2 more across crates).
5. **Finding #3** — URL percent-encoding (3 copies, OAuth correctness).
6. **Finding #4 + #5** — ExtraFile config type + resolver (collapse together).
7. **Findings #8–#14** — mechanical cleanups.

**Target crates for new shared helpers:** almost all land in `anodize-core`
(that's where `util`, `template`, `artifact`, `config`, `context` already
live). New modules suggested: `core::hashing` (for #2), `core::retry`
(for #7). Finding #1 extends `core::artifact`. Finding #3 extends
`core::util` (or uses `percent_encoding` crate constants directly).

**No action needed:**
- `glob::Pattern::new` duplications in `stage-build`, `stage-upx`,
  `core::git` — each is a single-call usage of the glob crate, not
  reimplementation.
- `tera::Tera::default()` inside `core/src/template.rs` and
  `xtask/src/gen_docs.rs` — these *are* the template engine / a docs tool.
- Multiple `fs::create_dir_all` usages (133 across 38 files) — that's the std
  API being called in different file-layout contexts, not duplicated logic.
- `Command::new` usages (188 across 32 files) — same: direct std API calls for
  different external tools.
- Project-name inference (Finding #13) — already deduped.
