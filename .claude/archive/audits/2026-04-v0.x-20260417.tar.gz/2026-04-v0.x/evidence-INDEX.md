# Evidence file index

Cross-reference: inventory §2 feature group → evidence-*.md file.

| §2 section | Evidence file | Status |
|---|---|---|
| 2.1 Builds | `evidence-build.md` | ✅ tested |
| 2.2 Archives | `evidence-archive.md` | ✅ tested (⚠ hooks alias) |
| 2.3 Checksums | `evidence-checksum.md` | ✅ tested |
| 2.4 Release (SCM) | `evidence-release-scm.md` | ✅ tested (⚠ from_url partial) |
| 2.5 Changelog | `evidence-changelog.md` | ✅ tested (ai unused live) |
| 2.6 Signing | `evidence-sign.md` | ✅ tested |
| 2.7 Docker | `evidence-docker.md` | ✅ tested (cfgd 3 images) |
| 2.8 nFPM + srpm | `evidence-nfpm.md` | ✅ tested (⚠ if/templated partial) |
| 2.9 Homebrew + Cask | `evidence-homebrew.md` | ✅ tested |
| 2.10 Scoop/Chocolatey/Winget | `evidence-windows-publishers.md` | ✅ tested |
| 2.11 AUR/Krew/Nix | `evidence-aur-krew-nix.md` | ✅ tested (AUR no live) |
| 2.12 Publishers misc (custom/blob/artifactory/uploads/fury/cloudsmith/crates.io) | `evidence-publishers-misc.md` | 🟡 partial (blob/artifactory unexercised live) |
| 2.13 Announcers (13) | `evidence-announcers.md` | 🟡 partial (11/13 unexercised live) |
| 2.14 SBOM + source | `evidence-sbom-source.md` | ✅ tested |
| 2.14 snapcraft/flatpak/makeself | `evidence-snap-flatpak-makeself.md` | ✅ tested (flatpak no live) |
| 2.14 Pro installers (dmg/msi/pkg/nsis/app_bundles) | `evidence-installers-pro.md` | 🟡 partial (no live artifacts) |
| 2.14 notarize | `evidence-notarize.md` | 🟡 partial (xcrun untested) |
| 2.15 project/dist/metadata/env_files/variables/template_files/includes/snapshot/nightly | `evidence-metadata-project.md` + `evidence-env-tokens.md` | 🟡 partial (metadata Pro fields missing) |
| 2.15 before/after hooks + build hooks + tag hooks | `evidence-hooks.md` | ✅ tested |
| 2.15 Partial builds (split/merge) | `evidence-partial-builds.md` | 🟡 partial (--prepare missing) |
| 2.15 git/monorepo/includes/workspaces | `evidence-git-monorepo.md` | ✅ tested |
| 2.15 CLI commands | `evidence-cli-commands.md` | 🟡 partial (man missing) |
| 2.15 CLI flags | `evidence-cli-flags.md` | 🟡 partial (--prepare/--soft missing) |
| 2.16 Template helpers | `evidence-template-helpers.md` | ✅ tested |
| 2.17 artifacts.json/metadata.json/config.yaml/tokens | `evidence-artifacts-json.md` | ✅ tested |
| 2.17 continue-on-error | `evidence-missing-niche.md` | ❌ untested (not impl) |
| §3 Rust-additive (12 features) | `evidence-rust-additive.md` | ✅ tested |
| §5 man / --soft / continue_on_error | `evidence-missing-niche.md` | ❌ untested (not impl) |
| anodize-action (Rust-additive wrapper) | `evidence-anodize-action.md` | ✅ tested |

## Totals

- **Evidence files**: 29
- **Status ✅ tested**: 19
- **Status 🟡 partial**: 9
- **Status ❌ untested**: 1

## Canonical CI / release URLs (reuse across files)

- anodize CI latest success: https://github.com/tj-smith47/anodize/actions/runs/24441674093 (commit `128e003`, 2026-04-15)
- anodize release workflow v0.2.5: https://github.com/tj-smith47/anodize/actions/runs/24441952862 (splits ✅, merge job has validation issue but release published)
- anodize latest release: https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 (2026-04-15, 30+ assets)
- cfgd v0.3.5 (cfgd CLI): https://github.com/tj-smith47/cfgd/actions/runs/24442230191
- cfgd core-v0.3.5 (cfgd-core lib): https://github.com/tj-smith47/cfgd/actions/runs/24442229349
- cfgd operator-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442230834
- cfgd csi-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442232044
- anodize-action CI: https://github.com/tj-smith47/anodize-action/actions/runs/24409150253
