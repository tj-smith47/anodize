---
feature: scoop + chocolatey + winget
status: tested
ecosystem_relevance: strongly-suggested/niche
tier: OSS
---

# Scoop / Chocolatey / Winget

## Status: ✅ tested

Covers: `scoops[]` (incl `use: archive/msi/nsis`, `persist/pre_install/post_install/depends/shortcuts`, `repository.*`); `chocolateys[]` (package_source_url/title/authors/project_url/use/dependencies/api_key/source_repo/require_license_acceptance/license_url/release_notes/summary/description/tags/skip_publish/icon_url/copyright/project_source_url/docs_url/bug_tracker_url); `wingets[]` (publisher/publisher_url/publisher_support_url/privacy_url/package_identifier/package_name/use/product_code/url_template/path/homepage/description/license_url/copyright/copyright_url/release_notes/installation_notes/dependencies/tags/skip_upload/repository.*/commit_author.*).

## Evidence

- **Unit tests**: `crates/stage-publish/src/scoop.rs` (31 tests), `crates/stage-publish/src/chocolatey.rs` (21 tests), `crates/stage-publish/src/winget.rs` (24 tests). Include: manifest JSON shape (scoop), nupkg structure (chocolatey, native impl no choco CLI), yaml manifests (winget), repository PR flow.
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs::test_parse_publish_scoop_*` (L1693–L1750).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:315/321/331` configures scoop/chocolatey/winget blocks.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:185/191/202` configures scoop (`tj-smith47/scoop-bucket`), chocolatey (`project_repo tj-smith47/cfgd`), winget (`manifests_repo tj-smith47/winget-pkgs`, `package_identifier TJSmith.cfgd`). Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success) with `SCOOP_BUCKET_TOKEN`, `CHOCOLATEY_API_KEY`, `WINGET_PKGS_TOKEN` secrets — bucket/manifests pushed live.

## Caveats / known gaps

- Native nupkg path (no choco CLI dependency) wired recently — see commit `248c904` "native nupkg (no choco CLI), skip before hooks on tag-triggered CI".
