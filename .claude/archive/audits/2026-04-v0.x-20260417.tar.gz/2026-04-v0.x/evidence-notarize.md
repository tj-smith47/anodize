---
feature: notarize (macos anchore/quill + macos_native Pro)
status: partial
ecosystem_relevance: strongly-suggested
tier: OSS+Pro
---

# Notarize

## Status: 🟡 partial (cross-platform backend unit-tested; native `xcrun` path untested live)

Covers: `notarize.macos` (anchore/quill cross-platform backend) and `notarize.macos_native` (Pro: codesign/xcrun).

## Evidence

- **Unit tests**: `crates/stage-notarize/src/` — subprocess wiring, keychain-unlock flow, timeout handling.
- **Config**: `MacOSNativeSignNotarizeConfig` at `crates/core/src/config.rs:3742` (struct correct per docs).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs unit tests.

## Caveats / known gaps

- **No live release notarizes an anodize or cfgd macOS artifact.** Neither anodize v0.2.5 nor any cfgd release assets carry a notary ticket. macOS binaries ship unsigned via anodize `binary_signs` (cosign) rather than Apple-notarized.
- Native notarize requires Apple Developer ID cert in keychain on a macOS runner — flagged in `HANDOFF.md` D2 for live test.
- `CI workflow exercising notarize: none yet.`
