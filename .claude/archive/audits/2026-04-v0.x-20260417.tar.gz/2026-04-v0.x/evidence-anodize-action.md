---
feature: anodize-action (the GitHub Action wrapping anodize)
status: tested
ecosystem_relevance: strongly-suggested
tier: Rust-additive
---

# anodize-action (GitHub Action)

## Status: ✅ tested

Covers: `from-artifact`, `artifact-run-id`, `artifact-workflow`, `from-source`, `install-rust`, `install` (tool list: zig/cargo-zigbuild/upx/nfpm/makeself/snapcraft/rpmbuild/cosign), `args`, `gpg-private-key`, `docker-registry`, `docker-password`, `upload-dist`, `download-dist`, `resolve-workspace`, `install-only`.

## Evidence

- **CI workflow**: https://github.com/tj-smith47/anodize-action/actions/runs/24409150253 (success, "fix: preserve split-build subdirs between retries"). Prior runs `24326589929` (success, "fix: clean generated artifacts between retries to prevent collisions"), `24318333818` (success, "fix: consolidate artifacts, jq release-url, backoff, apt batching, retry").
- **Consumer proof — anodize's own release workflow** (`/opt/repos/anodize/.github/workflows/release.yml:51`): uses `tj-smith47/anodize-action@master` with `from-artifact: anodize-linux`, `install: zig,cargo-zigbuild,upx` (split jobs) and `install: nfpm,makeself,snapcraft,rpmbuild,cosign` (merge job). Run `24441952862` exercised all composite steps; split jobs `71408830745`/`71408830774`/`71408830783` all completed successfully.
- **Consumer proof — cfgd's release workflow** (`/opt/repos/cfgd/.github/workflows/release.yml:35/83/117`): uses the action for `resolve-workspace`, `release --split`, `release --merge`, with `install: zig,cargo-zigbuild,upx` + `install: nfpm,makeself,snapcraft,rpmbuild,cosign`, `download-dist`, `docker-registry: ghcr.io`, `docker-password`, `upload-dist: true`. All 4 tag runs on 2026-04-15 succeeded:
  - `core-v0.3.5`: https://github.com/tj-smith47/cfgd/actions/runs/24442229349
  - `v0.3.5`: https://github.com/tj-smith47/cfgd/actions/runs/24442230191
  - `operator-v0.3.5`: https://github.com/tj-smith47/cfgd/actions/runs/24442230834
  - `csi-v0.3.5`: https://github.com/tj-smith47/cfgd/actions/runs/24442232044

## Caveats / known gaps

- action lives in separate repo `/opt/repos/anodize-action/`; retry logic and artifact preservation are actively iterated (see recent commits `0378f0e`, `ac3cf53`, `c566ed8`).
