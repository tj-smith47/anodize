---
feature: signing (generic signs[], binary_signs[], docker_signs[], cosign/gpg, ids/if/artifacts/stdin/env/output)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Signing stage (signs / binary_signs / docker_signs)

## Status: ✅ tested

Covers: `signs[]` (gpg + cosign), `signs[].cmd`, `signs[].signature`, `signs[].args` templated, `signs[].artifacts` (none/all/checksum/source/package/installer/diskimage/archive/sbom/binary), `signs[].ids`, `signs[].if` (Pro), `signs[].stdin`/`stdin_file`, `signs[].certificate` (cosign/rekor), `signs[].env`, `signs[].output`, `docker_signs[]`, `binary_signs[]`.

## Evidence

- **Unit tests**: `crates/stage-sign/src/` — subprocess dispatch, artifact-scope filter, env/stdin passthrough; `BinarySignStage` (added 2026-04-16) has inline tests at `crates/stage-sign/src/lib.rs` (binary-only loop for build-time signing).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_multi_sign_dry_run` (L1892).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs sign unit tests + `test_e2e_multi_sign_dry_run`.
- **Release tag (live GPG + cosign proof)**: anodize v0.2.5 release assets at https://github.com/tj-smith47/anodize/releases/tag/v0.2.5 include `anodize-0.2.5-checksums.txt.sig` (GPG detached sig on checksums), `anodize.exe_windows_amd64.sig` / `anodize.exe_windows_arm64.sig` / `anodize_darwin_amd64.sig` / `anodize_darwin_arm64.sig` / `anodize_linux_amd64.sig` / `anodize_linux_arm64.sig` (cosign binary sigs — 6 binary artifacts signed).
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:460` uses `signs:` (gpg on checksums), `binary_signs:` (cosign on binaries), `docker_signs:` (cosign on manifests).
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:450` uses `signs` (gpg on checksum + source), `binary_signs` (cosign on binary), `docker_signs` (cosign on manifests). Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success) with `COSIGN_KEY`/`COSIGN_PASSWORD`/`GPG_PRIVATE_KEY` secrets.

## Caveats / known gaps

- macOS keychain-based signing (Pro `macos_sign`) is only partially testable — the cross-platform `notary` backend (anchore/quill) is used in CI, but the native `xcrun`/`codesign` path (Pro `macos_sign_notarize`) requires Apple Developer cert in keychain. Flagged in `HANDOFF.md` D2 for live test.
