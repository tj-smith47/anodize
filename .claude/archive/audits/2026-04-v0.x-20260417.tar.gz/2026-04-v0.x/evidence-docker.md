---
feature: docker (v1 dockers[], v2 docker_v2, manifests, digest, dockerhub)
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Docker (v1 + v2 + manifests + digest + dockerhub)

## Status: ✅ tested

Covers: `dockers[]` (v1 legacy), `docker_v2[]`, `docker.image_templates`, `dockerfile`, `templated_dockerfile` (Pro), `extra_files`, `templated_extra_files` (Pro), `use` (docker/buildx/podman), `build_flag_templates`, `skip_build` (Pro), `skip_push`, `push_flags`, `retry`, `docker_v2.platforms` (multi-arch), `docker_v2.sbom` (inline), `docker_v2.labels`/`annotations`, `docker_v2.build_args`, `docker_manifests[]`, `dockerdigest`, `dockerhub` (Pro description sync).

## Evidence

- **Unit tests**: `crates/stage-docker/src/` — dockerfile rendering, build-flag templating, manifest construction, digest-extraction post-push, retry/backoff, dockerhub description-sync client.
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Integration test**: `crates/cli/tests/integration.rs::test_e2e_docker_staging_dry_run` (L2464).
- **Dogfood (cfgd v0.3.5 — multi-image, multi-arch, SBOM inline)**: `/opt/repos/cfgd/.anodize.yaml:232` configures `docker_v2` for 3 images (`cfgd-agent`, `cfgd-operator`, `cfgd-csi`) on `linux/amd64,linux/arm64` platforms with `sbom: true`, `annotations`, `build_args`, plus `docker_manifests` for each. Release runs:
  - cfgd v0.3.5 (agent): https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success)
  - cfgd operator-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442230834 (success) — operator image pushed to `ghcr.io/tj-smith47/cfgd-operator`
  - cfgd csi-v0.3.5: https://github.com/tj-smith47/cfgd/actions/runs/24442232044 (success) — csi image pushed to `ghcr.io/tj-smith47/cfgd-csi`
- **Docker digest proof**: cfgd config at L261 sets `docker_digest.name_template` — digest file written per release.

## Caveats / known gaps

- anodize does not ship its own Docker image (no `docker_v2` block in `/opt/repos/anodize/.anodize.yaml` per grep); dogfood comes entirely from cfgd's 3-image setup.
- `dockerhub` description-sync (Pro) implemented in `crates/stage-publish/src/dockerhub.rs` with 14 unit tests but no live release exercises it — cfgd/anodize use `ghcr.io`, not Docker Hub.
- Podman/buildx path-selection exercised only by unit tests — CI uses docker daemon.
