# Wave A — Live-test handoff

Items that auditors flagged as needing a real release run to validate end-to-end. Per audit-wave-a procedure: hooks deny live-release gestures; surface the handoff and exit. User runs these manually.

## D1 — Partial split/merge end-to-end (Pro)

The on-disk `context.json` format, artifact survival across workers, and merge-idempotency can only be exercised by a real multi-job CI run.

### Setup
```bash
/wt release-test-d1
cd <new worktree>
# Define a config with multiple builds + multiple ids that triggers the split path
```

### Run
```bash
# Job A (one CI runner / shell)
anodize release --split --id=binary-a --snapshot

# Job B (separate runner / shell — different working dir)
anodize release --split --id=binary-b --snapshot

# Merge job
anodize release --merge --snapshot
```

### Look for
- `dist/context-binary-a.json` and `dist/context-binary-b.json` exist after each split job
- Both have non-empty `artifacts:` arrays
- `--merge` consumes both into a single `dist/context.json` with combined artifact set
- No "duplicate artifact" errors; no missing artifacts after merge
- If runner A is killed mid-write of `context-binary-a.json`, merge should fail with an actionable message naming the truncated file (currently it fails with a generic JSON parse error — see W5 in `pro-features-audit.md`)

### Rollback
```bash
rm -rf dist/
git clean -fdx
cd /opt/repos/anodize
git worktree remove <worktree path>
```

## D2 — Native macOS notarize (Pro)

The `xcrun notarytool` + keychain path requires a signed Apple Developer account and a macOS runner. Struct shape is correct (`MacOSNativeSignNotarizeConfig` at `crates/core/src/config.rs:3742`) but runtime errors (keychain unlock failure, notarization timeout, Apple's transient 503s) can only be observed live.

### Setup
- macOS 14+ runner with Xcode 15+ installed
- Apple Developer ID Application certificate in keychain (via `security import`)
- App-specific password stored in keychain via `xcrun notarytool store-credentials`

### Run
```bash
/wt release-test-d2-mac
cd <worktree>
# Build for darwin/arm64 + darwin/amd64
# Configure macos_sign + macos_notarize in .anodize.yaml
anodize release --snapshot
```

### Look for
- `xcrun notarytool submit` log line with non-empty submission UUID
- `xcrun stapler staple` succeeds on the .app bundle / .dmg
- `spctl --assess --verbose` on the resulting artifact returns "accepted"
- Keychain prompt does NOT appear if keychain is correctly unlocked beforehand (anodize should not pop a UI dialog in CI)
- Timeout behavior: if Apple's API hangs, anodize should respect `notarize.timeout_minutes` rather than hanging the whole release

### Rollback
- Delete the worktree; revoke the test cert in keychain if it was created for the test
- No published artifacts to revoke (snapshot mode)

## After running

If the live tests reveal additional bugs, append them to `/opt/repos/anodize/.claude/known-bugs.md` Active section and re-open Wave A status entry as needed.
