---
feature: partial builds (--split/--merge/--prepare, context.json, ANODIZE_SPLIT_TARGET)
status: partial
ecosystem_relevance: strongly-suggested
tier: Pro
---

# Partial builds — `--split` / `--merge`

## Status: 🟡 partial (live-proven for `--split`/`--merge`; `--prepare` missing; edge cases need live validation)

Covers: `partial.by` (goos/goarch/target), `--split` flag, `--merge` flag, `--id` (Pro crate filter), `--prepare` (Pro, multi-stage), `ANODIZE_SPLIT_TARGET` env (Rust-native replacement for GGOOS/GGOARCH), `context.json` serialization across workers.

## Evidence

- **Unit tests**: `crates/cli/src/commands/release/split.rs` (split context write/read), `crates/core/src/partial.rs` (partitioning), `crates/cli/src/commands/release/mod.rs` (merge logic).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_workspace_*` covers the non-split path; split/merge is exercised live rather than unit-tested end-to-end.
- **CI workflow — split succeeds**: https://github.com/tj-smith47/anodize/actions/runs/24441952862 — the three `Build (ubuntu-latest/macos-latest/windows-latest)` split jobs **all succeeded** (each ran `anodize release --split --clean`) for v0.2.5 tag on 2026-04-15. Artifacts `dist-Linux`, `dist-macOS`, `dist-Windows` uploaded.
- **Release tag (live multi-OS split proof)**: v0.2.5 (2026-04-15) assets include binaries from all 3 runners — proves split wrote per-OS `context.json`, merge consumed them, and the release shipped successfully. Note: the `Publish Release` merge job is listed as `failure` but the release was published (suggests post-publish validation failed, not the merge itself — see HANDOFF.md D1 for exact edge cases).
- **Dogfood (cfgd v0.3.5 — full workspace + split+merge across 3 OS)**: `/opt/repos/cfgd/.github/workflows/release.yml:82–90` invokes `anodize release --split --clean --crate cfgd` per runner, then `release --merge --crate cfgd` on the publish job. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success, 2026-04-15) — split + merge completed end-to-end for cfgd agent binary.
- **`partial.by: goos` configured**: `/opt/repos/cfgd/.anodize.yaml:527` sets `partial.by: goos` in production.

## Caveats / known gaps

- `--prepare` CLI flag ❌ **missing** from `crates/cli/src/` — known-bugs.md A1-rev line 51. Blocks Pro multi-stage `prepare → publish → announce` flow.
- Split+merge env poisoning bugs (recent `fbb83bb9` "macOS HOME leaked into Linux docker builds") suggest subtle edge cases; HANDOFF.md D1 calls for a deliberate runner-kill-mid-write test to validate merge error messages.
- anodize's own v0.2.x release workflow merge job shows `failure` in the `gh run list` output while releases publish successfully — indicates a post-merge validation edge case that needs investigation but does NOT block the published artifact set.
