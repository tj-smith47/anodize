---
feature: dist/artifacts.json + dist/metadata.json + dist/config.yaml + tokens (GITHUB/GITLAB/GITEA/GORELEASER_FORCE_TOKEN)
status: tested
ecosystem_relevance: required
tier: OSS
---

# Pipeline outputs (artifacts.json / metadata.json / config.yaml) + auth tokens

## Status: ✅ tested

Covers: `dist/artifacts.json` (full artifact manifest), `dist/metadata.json` (release metadata), `dist/config.yaml` (effective config), `GITHUB_TOKEN`/`GITLAB_TOKEN`/`GITEA_TOKEN`, `GORELEASER_FORCE_TOKEN` (`ForceTokenKind` enum), announcer provider secret env vars.

## Evidence

- **Unit tests**: `crates/core/src/artifact.rs`, `crates/core/src/config.rs` (effective-config emit), `crates/core/src/token.rs` (token kind resolution).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_build_command_matches_goreleaser_pipeline_outputs` (L3617) — asserts `dist/config.yaml`, `dist/metadata.json`, `dist/artifacts.json` all exist with expected content after `anodize build`.
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Release tag proof**: anodize v0.2.5 ships `artifacts.json` (11652 bytes, asset id RA_kwDORxhcIs4Xp2mD) and `metadata.json` (128 bytes, asset id RA_kwDORxhcIs4Xp2mB) as release assets. https://github.com/tj-smith47/anodize/releases/tag/v0.2.5
- **Dogfood (cfgd v0.3.5)**: release.yml uses `GITHUB_TOKEN: ${{ secrets.GH_PAT }}` across all anodize-action steps. Live run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success) — GH_PAT consumed for release + tap PR pushes.

## Caveats / known gaps

- GitLab/Gitea tokens wired but not exercised live (no GitLab/Gitea project in dogfood).
- `GORELEASER_FORCE_TOKEN` enum resolver covered by unit tests; no live release overrides token kind via env.
