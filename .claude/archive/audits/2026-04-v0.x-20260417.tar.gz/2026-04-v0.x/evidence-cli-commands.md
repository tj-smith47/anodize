---
feature: CLI commands (release/build/check/healthcheck/init/completion/jsonschema/changelog/continue/publish/announce/tag/targets/resolve-tag)
status: partial
ecosystem_relevance: required/strongly-suggested/niche
tier: OSS+Pro+Rust-additive
---

# CLI commands

## Status: 🟡 partial (all implemented commands tested; `man pages` missing)

Covers: `release`, `build`, `check`, `healthcheck`, `init`, `completion`, `jsonschema`, `changelog preview` (Pro), `continue` (Pro), `publish` (Pro), `announce` (Pro), `tag` (Rust-additive), `targets --json` (Rust-additive), `resolve-tag` (Rust-additive). Missing: `man pages` (❌), `--soft` check flag (❌).

## Evidence

- **Unit tests**: `crates/cli/src/commands/init.rs`, `completion.rs`, `check.rs`, `jsonschema.rs`, `tag.rs`, `healthcheck.rs`, `publisher.rs`, `targets.rs`, `release/split.rs`, `release/mod.rs`, `resolve_tag.rs`, `build.rs`, `timeout.rs`, `helpers.rs` — every command has inline tests.
- **Integration tests (comprehensive)**: `crates/cli/tests/integration.rs` — `test_check_valid_config` (L10), `test_check_invalid_config` (L38), `test_init_generates_config` (L53), `test_help_output` (L89), `test_version_output` (L113), `test_check_with_config_flag_*` (L125–L192), `test_completion_bash_produces_output` (L334), `test_completion_zsh_produces_output` (L354), `test_healthcheck_succeeds` (L366), `test_e2e_healthcheck_detects_tools` (L3053), `test_e2e_snapshot_release_produces_artifacts` (L632), `test_e2e_build_command_matches_goreleaser_pipeline_outputs` (L3617), `test_e2e_init_generates_parseable_yaml` (L887), `test_e2e_toml_config_check` (L3506), `test_e2e_init_yaml_structural_round_trip` (L2835), `test_e2e_check_comprehensive_config` (L788).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs the full integration suite (~120 tests).
- **Live CLI proof**:
  - `release`: every anodize v0.1.x–v0.2.5 release + all cfgd v0.3.x releases ran `anodize release`.
  - `tag`: anodize CI's auto-tag step (ci.yml L104) runs `anodize tag` on master → produced v0.1.1–v0.2.5 tags automatically.
  - `resolve-tag`: cfgd's `/opt/repos/cfgd/.github/workflows/release.yml:36` uses `resolve-workspace: 'true'` → maps tag to crate at run https://github.com/tj-smith47/cfgd/actions/runs/24442229349.
  - `targets --json`: consumed by `anodize-action` as matrix input — see CI at https://github.com/tj-smith47/anodize-action/actions/runs/24409150253 (success).
  - `continue` (Pro): composite `publish` and `announce` subcommands are wired via `anodize release --merge` in cfgd release workflow.

## Caveats / known gaps

- `man` subcommand ❌ **missing** — `goreleaser man` uses clap_mangen; not implemented. Niche per spec §5.
- `--soft` flag on check ❌ **missing** — Pro; anodize check is strict by default.
- `changelog preview` (Pro) implemented at `crates/cli/src/commands/changelog.rs` but not exercised in CI (dry-run-only command; unit-tested).
