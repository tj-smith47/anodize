# Parity audit — announcers (2026-04-16)

Auditor: `parity-auditor-announcers` (Wave A4).
Scope: `crates/stage-announce/src/*.rs` vs `goreleaser/internal/pipe/{discord,slack,webhook,telegram,teams,mattermost,smtp,reddit,twitter,mastodon,bluesky,linkedin,opencollective}/`.
Filter per inventory (specs/goreleaser-complete-feature-inventory.md lines 329-342):
- **strongly-suggested**: discord, slack, webhook → full BLOCKER/WARN reporting.
- **niche**: telegram, teams, mattermost, smtp, reddit, twitter, mastodon, bluesky, linkedin, opencollective → reported at INFO unless a real functional bug.
- **rust-additive (skipped)**: discourse — anodize has it, goreleaser does not; not a parity gap.

All anodize announcer stages are **implemented and wired**: `lib.rs` iterates every provider under `announce.*`, calls `is_enabled`, renders templates through Tera, dispatches via `dispatch()` which honours `--dry-run`. Config structs (core/src/config.rs:4446-4753) expose every GoReleaser field plus a few Rust-additive ones (`bluesky.pds_url`, typed `slack.blocks`/`slack.attachments`).

Severity key:
- **BLOCKER** — produces wrong output at runtime, or will when users hit the code path.
- **WARN** — behavioural divergence users can feel (default drift, lenient error handling, ordering).
- **INFO** — intentional/improved divergence, reported for traceability only.

---

## 1. BLOCKER — `send_mastodon` sends `client_id` / `client_secret` as form fields on `POST /api/v1/statuses`

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/mastodon.rs:17-23` (form fields) + `crates/stage-announce/src/lib.rs:628-640` (env-var requirement) |
| GoReleaser | `internal/pipe/mastodon/mastodon.go:47-59` |

**Evidence:** goreleaser constructs a `go-mastodon` client with `ClientID`/`ClientSecret`/`AccessToken` (mastodon.go:47-52) and calls `client.PostStatus(&Toot{Status: msg})`. The `go-mastodon` client uses **Bearer auth only** (`Authorization: Bearer <access_token>`) for posting statuses; the client_id/client_secret are there for the OAuth token-exchange flow, not sent on every status POST.

Anodize instead appends `client_id` / `client_secret` directly to the form body of `POST /api/v1/statuses`:

```rust
// mastodon.rs:17-23
let mut form = vec![("status", message.to_string())];
if !client_id.is_empty() { form.push(("client_id", client_id.to_string())); }
if !client_secret.is_empty() { form.push(("client_secret", client_secret.to_string())); }
```

Mastodon's `POST /api/v1/statuses` endpoint does not define `client_id`/`client_secret` params. Behaviour depends on the instance: Mastodon ignores unknown form fields silently, but stricter ActivityPub servers (Pleroma, Akkoma) may reject the request or log a warning. At best this is dead weight shipping secrets in the post body; at worst it breaks posting on stricter servers.

**Fix direction:** remove the `client_id`/`client_secret` form fields; drop the corresponding env-var *requirement* in `lib.rs:628-640` (treat those vars as optional; validate only MASTODON_ACCESS_TOKEN). Document that `client_id`/`client_secret` are only needed when users run the OAuth token-exchange flow themselves.

---

## 2. BLOCKER — `email` SMTP path hard-codes STARTTLS (port 465 / implicit TLS broken)

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/email.rs:57` (`SmtpTransport::starttls_relay`) |
| GoReleaser | `internal/pipe/smtp/smtp.go:81-85` (`gomail.NewDialer`) |

**Evidence:** GoReleaser's `gomail.NewDialer(host, port, user, pass)` auto-selects: implicit TLS (`SMTPS`) on port 465, STARTTLS otherwise. Anodize always calls `SmtpTransport::starttls_relay(host)`, which issues `EHLO` then `STARTTLS`. On port 465 the server expects TLS from the first byte, so anodize's SMTP handshake fails before the client sends STARTTLS.

**Fix direction:** when `port == 465` use `SmtpTransport::relay(host)` (implicit TLS) rather than `starttls_relay`. Keep STARTTLS as the default for other ports.

---

## 3. BLOCKER — `email.port` defaults to `587` but GoReleaser errors when unset

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/lib.rs:825` (`smtp_port.unwrap_or(587)`) |
| GoReleaser | `internal/pipe/smtp/smtp.go:98` (`errNoPort`), smtp.go:118-120 |

**Evidence:** goreleaser requires `smtp.port` (config) OR `$SMTP_PORT` (env) to be set, surfacing `errNoPort` when both are zero (smtp.go:98,118-120). Anodize silently picks 587 when both are absent.

Impact: a user misconfiguring port (typo, omitted field) gets unexpected STARTTLS-on-587 behaviour instead of a crisp config error. Default-parity section of the iron laws: "matches exactly OR is explicitly better" — 587 is a reasonable *default*, but hiding a missing-config error isn't. GoReleaser's loud error is the better DX for release tooling where misdelivered announcements matter.

**Fix direction:** surface `announce.email: missing port (set announce.email.port or $SMTP_PORT)` when both are absent, matching goreleaser. Alternatively accept the default but log a WARN about assuming 587.

---

## 4. BLOCKER — `webhook` Authorization header ordering overwrites user-supplied header

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/lib.rs:324-341` |
| GoReleaser | `internal/pipe/webhook/webhook.go:104-115` |

**Evidence:** GoReleaser sets Authorization from env FIRST (webhook.go:104-110) using `req.Header.Add` (**appends**, does not replace), THEN loops over user-supplied `ctx.Config.Announce.Webhook.Headers` with another `req.Header.Add` (webhook.go:112-115). `Add` preserves multiple values; in Go's `http.Header` the transport sends them as one `Authorization: a, b` header. Net: user-header appends to env-header.

Anodize instead builds a `HashMap<String,String>`. The order is:
1. render user headers (lib.rs:324-328) — inserts user `Authorization` if present.
2. env var `BASIC_AUTH_HEADER_VALUE` / `BEARER_TOKEN_HEADER_VALUE` **overwrites** the HashMap entry (lib.rs:333-341).

So env wins over config in anodize; in goreleaser, both are sent (env first, config appended). A user who sets `announce.webhook.headers.Authorization` in their config *expects* it to take effect; anodize silently throws it away when the env var is set.

**Fix direction:** either (a) reverse the order so user config overwrites env (closer to goreleaser's "user wins when conflict" intent — goreleaser sends both but most HTTP intermediaries treat the second as authoritative), or (b) drop the HashMap and use a `Vec<(String,String)>` that preserves both, mirroring goreleaser's `Add` semantics.

Recommendation: option (a). Sending two `Authorization` headers is a recipe for 400s from strict gateways; the "user config wins" rule is crisper DX.

---

## 5. WARN — `linkedin::send_linkedin` writes to stderr instead of the project logger

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/linkedin.rs:44` (`eprintln!`) |
| GoReleaser | `internal/pipe/linkedin/linkedin.go:56` (`log.Infof`) |

**Evidence:** goreleaser logs the share URL via `caarlos0/log`; every other anodize announcer uses `ctx.logger("announce")`. linkedin.rs bypasses that: the success-message "post available at …" lands on stderr regardless of whether tracing is configured for JSON output, quiet mode, etc. Breaks log-format consistency, which matters because users script against announce logs.

**Fix direction:** plumb a logger into `send_linkedin` (new param, or return the activity URL so `lib.rs` logs it via `dispatch`), then use `tracing::info!` / the existing `logger("announce")` pattern.

---

## 6. WARN — `webhook` User-Agent default is `anodize/1.0` (versus goreleaser's static `goreleaser`)

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/lib.rs:344-346` |
| GoReleaser | `internal/pipe/webhook/webhook.go:24,102` |

**Evidence:** anodize uses `anodize/1.0` — a frozen "1.0" string that does not track the crate version. Branding divergence is fine (see §13), but the hard-coded `1.0` will mislead webhook receivers parsing User-Agent for telemetry. Branding *should* match the binary's real version.

**Fix direction:** replace the literal with `concat!("anodize/", env!("CARGO_PKG_VERSION"))` or pull from `anodize_core`'s version surface, same pattern the release-notes pipe and github API calls already use.

---

## 7. WARN — `email.insecure_skip_verify` not wired when STARTTLS fallback engages

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/email.rs:57-68` |
| GoReleaser | `internal/pipe/smtp/smtp.go:85` |

**Evidence:** anodize builds the transport with `starttls_relay(host)` (STARTTLS required) and then, IFF `insecure_skip_verify` is true, rebuilds TLS params and re-assigns. If `insecure_skip_verify` is `false` (default) but the SMTP server presents an invalid cert, the STARTTLS handshake fails — matching goreleaser. If `true`, anodize correctly relaxes verification. Parity OK for the STARTTLS path but §2 breaks the port-465 implicit-TLS path before `insecure_skip_verify` can apply; fix §2 first, then re-verify this flag still flows through for port-465 implicit TLS.

---

## 8. INFO — Intentional: Teams uses AdaptiveCard vs GoReleaser's legacy MessageCard

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/teams.rs:22-102` |
| GoReleaser | `internal/pipe/teams/teams.go:66-80` (uses `messagecard.NewMessageCard`) |

**Evidence:** Microsoft's MessageCard format (the one GoReleaser emits via `go-teams-notify`) is [officially retired for new webhooks](https://learn.microsoft.com/en-us/outlook/actionable-messages/message-card-reference); AdaptiveCards is the supported path. Anodize chose correctly. Already called out as "intentional divergence" in the feature inventory (line 332). Leave as-is; anodize is ahead of goreleaser here.

---

## 9. INFO — Intentional: Twitter uses v2 API (`api.x.com/2/tweets`) vs GoReleaser's v1.1

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/twitter.rs:14` |
| GoReleaser | `internal/pipe/twitter/twitter.go:52` (`client.Statuses.Update` → v1.1 `statuses/update.json`) |

**Evidence:** Twitter v1.1 statuses endpoints were shut down in 2023. goreleaser's twitter pipe is **dead upstream** — any user with it enabled gets auth errors. Anodize correctly implements OAuth 1.0a against v2. Another "anodize fixes a goreleaser bug" scenario. Leave as-is.

---

## 10. INFO — Intentional: Mattermost attachment color avoids goreleaser's `Teams.Color` typo

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/lib.rs:506` (reads `cfg.color`), `mattermost.rs:55` |
| GoReleaser | `internal/pipe/mattermost/mattermost.go:48-50, 82` (reads `ctx.Config.Announce.Teams.Color`) |

**Evidence:** `mattermost.go` references `Announce.Teams.Color` four times where it clearly means `Announce.Mattermost.Color` (lines 48-50 default assignment, line 82 attachment color). goreleaser's Mattermost config has its own `Color` field that goes unread. Anodize correctly reads `cfg.color` from `MattermostAnnounce` (lib.rs:506). Another fix-a-goreleaser-bug; leave as-is, but add a fixture-level test so regression-chasing doesn't silently revert this.

---

## 11. INFO — Intentional: `post_json` is stricter than goreleaser's "ignore status" calls (mattermost, linkedin probe)

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/http.rs:16-21` (rejects non-2xx) |
| GoReleaser | `internal/pipe/mattermost/mattermost.go:102-108` (never inspects status), `internal/pipe/linkedin/client.go:73,110` (checks only 403) |

**Evidence:** anodize's shared `post_json` helper bails on any non-2xx, surfacing "webhook returned 500 foo" while goreleaser's Mattermost pipe swallows the error silently and its LinkedIn pipe branches only on 403. Strictness is the right DX default — a dropped announcement should be loud.

---

## 12. INFO — Intentional: Bluesky `pds_url` (Rust-additive) for self-hosted PDS

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/bluesky.rs:8-17` + `core/src/config.rs:4454-4457` |
| GoReleaser | `internal/pipe/bluesky/bluesky.go:31` (hard-coded `https://bsky.social`) |

Rust-additive; AT Protocol supports self-hosted PDS servers and anodize lets users target them. Not a gap.

---

## 13. INFO — Intentional branding drift (Discord author, Slack username, Mattermost username, Webhook UA, Bluesky UA)

| Provider | Anodize default | GoReleaser default |
|----------|-----------------|---------------------|
| Discord  | `anodize`       | `GoReleaser` |
| Slack    | `anodize`       | `GoReleaser` |
| Mattermost | `anodize`     | `GoReleaser` |
| Webhook UA | `anodize/1.0` (see §6) | `goreleaser` |
| Bluesky UA | `anodize/1.0` | `goreleaser/v2` |

Acceptable: this is the same product-name swap as README headers. See §6 for a separate issue about the frozen `/1.0` version string.

---

## 14. INFO — Intentional: Discord icon_url default omitted

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/lib.rs:195,466-470` |
| GoReleaser | `internal/pipe/discord/discord.go:21,44`, `internal/pipe/teams/teams.go:15,39-41` |

GoReleaser defaults both Discord and Teams `icon_url` to `https://goreleaser.com/static/avatar.png`. Anodize leaves `icon_url` unset (shipping a 404 is worse than no icon). Fine.

---

## 15. INFO — Mattermost attachment emits fewer fields than goreleaser's struct (cosmetic)

| | File:Line |
|-|-|
| Anodize | `crates/stage-announce/src/mattermost.rs:53-60` |
| GoReleaser | `internal/pipe/mattermost/mattermost.go:127-146` |

GoReleaser's `mattermostAttachment` struct has no `omitempty` tags, so `fallback`, `pretext`, `author_name`, `author_link`, `author_icon`, `title_link`, `fields`, `footer`, `footer_icon` always serialise as empty strings/arrays. Anodize omits these. Mattermost accepts both. Cosmetic only; no fix needed.

---

## Config-field parity matrix (one-line per provider)

| Provider | goreleaser struct fields | anodize `*Announce` struct fields | Wired in lib.rs? | Behavioural gap? |
|----------|-------------------------:|----------------------------------:|-----------------:|-----------------:|
| discord | enabled, message_template, author, color, icon_url | +webhook_url (anodize-additive) | ✅ (:148-207) | INFO only |
| slack | enabled, message_template, channel, username, icon_emoji, icon_url, blocks, attachments | +webhook_url; typed blocks/attachments | ✅ (:259-298) | none |
| webhook | enabled, endpoint_url, message_template, content_type, headers, skip_tls_verify, expected_status_codes | same | ✅ (:303-373) | §4, §6 |
| telegram | enabled, chat_id, message_template, parse_mode, message_thread_id | +bot_token config option (anodize-additive) | ✅ (:378-445) | none |
| teams | enabled, webhook_url, message_template, title_template, color, icon_url | same | ✅ (:450-484) | see §8 |
| mattermost | enabled, channel, username, icon_emoji, icon_url, color, message_template, title_template | +webhook_url | ✅ (:489-528) | see §10 |
| smtp/email | enabled, host, port, username, from, to[], subject_template, body_template, insecure_skip_verify | alias body_template→message_template | ✅ (:764-848) | §2, §3, §7 |
| reddit | enabled, application_id, username, sub, url_template, title_template | same | ✅ (:533-571) | none |
| twitter | enabled, message_template | same | ✅ (:576-608) | see §9 |
| mastodon | enabled, server, message_template | same | ✅ (:613-655) | §1 |
| bluesky | enabled, username, message_template | +pds_url | ✅ (:660-695) | see §12 |
| linkedin | enabled, message_template | same | ✅ (:700-718) | §5 |
| opencollective | enabled, slug, title_template, message_template | same | ✅ (:723-759) | see §11 |

Discourse (Rust-additive, anodize-only) intentionally omitted from parity comparison.

---

## Bloat candidates

None. All 13 audited announcer crates appear as `disposition=—` (kept) in the inventory. No `disposition=remove` candidates to add to `bloat.md`.

---

## Summary

| Classification | Count |
|----------------|-------|
| BLOCKER        | 4     |
| WARN           | 3     |
| INFO           | 8     |

- BLOCKERs (§1, §2, §3, §4) → consolidate into `known-bugs.md` during A10.
- WARNs (§5, §6, §7) → consolidate as well; all are deterministic divergences.
- INFOs (§8-§15) → reference only; no action.

Auth parity, env-var name parity, default-message-template parity, and skip/enabled-template parity all hold across the full set. Every config field listed in the goreleaser source has a wired anodize counterpart.
