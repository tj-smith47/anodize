---
feature: before/after hooks + build hooks + tag hooks
status: tested
ecosystem_relevance: required
tier: OSS+Rust-additive
---

# Hooks (before/after/build/tag)

## Status: ✅ tested

Covers: `before` + `after` global hooks (`HooksConfig`), `build.hooks.pre/post` (per-build), `tag_pre_hooks`/`tag_post_hooks` (Rust-additive tag-subcommand hooks with templated vars).

## Evidence

- **Unit tests**: `crates/core/src/hooks.rs` (hook execution + env), `crates/cli/src/commands/tag.rs` (tag hooks with templated vars — inline tests).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_before_hooks_execute` (L3368), `test_e2e_before_hooks_dry_run` (L3437).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **anodize config**: `/opt/repos/anodize/.anodize.yaml:63` `before:`, `:69` `after:`, plus tag hooks.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:95` `before:` hooks, `:101` `after:` hooks. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success) — hooks ran on tag-triggered CI (recent commit `248c904` "skip before hooks on tag-triggered CI" documents the gated behavior).

## Caveats / known gaps

- `archives[].hooks.before/after` (Pro) ⚠ partial — field-name mismatch (anodize uses `pre`/`post`, docs use `before`/`after`). Silent skip. Known-bugs.md A1-rev line 32.
