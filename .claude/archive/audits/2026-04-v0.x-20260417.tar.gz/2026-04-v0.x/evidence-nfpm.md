---
feature: nFPM (deb/rpm/apk/archlinux/ipk/termux.deb) + srpm
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# nFPM Linux packaging + SRPM

## Status: ✅ tested

Covers: `nfpms[]`, `id/ids/package_name/file_name_template`, `vendor/homepage/maintainer/description/license`, formats `deb`, `rpm`, `apk`, `termux.deb`, `archlinux`, `ipk`, `umask/bindir/libdirs`, `epoch/prerelease/version_metadata/release/section/priority`, `meta/changelog/goamd64/mtime`, `dependencies/provides/recommends/suggests/conflicts/replaces`, `contents[]` with `file_info`, `scripts` (preinstall/postinstall/preremove/postremove), `rpm.*/deb.*/apk.*/archlinux.*/ipk.*` blocks, `overrides`, ConventionalFileName (per-packager v2.44 closure), passphrase env priority, srpm via rpmbuild subprocess.

## Evidence

- **Unit tests**: `crates/stage-nfpm/src/` — packager dispatch, ConventionalFileName (per-format logic in `filename.rs` added 2026-04-16), passphrase env priority (`NFPM_[ID]_[FORMAT]_PASSPHRASE` > `NFPM_[ID]_PASSPHRASE` > `NFPM_PASSPHRASE`), scripts/contents/file_info wiring.
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs` — `test_parse_nfpm_*` (~12 tests, L1297–L1586).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs the `task package` job that invokes nfpm dry-run.
- **Release tag (live nfpm + srpm proof)**: anodize v0.2.5 ships `anodize_0.2.5_linux_amd64.deb`, `anodize_0.2.5_linux_arm64.deb`, `anodize_0.2.5_linux_amd64.rpm`, `anodize_0.2.5_linux_arm64.rpm`, `anodize_0.2.5_linux_amd64.apk`, `anodize_0.2.5_linux_arm64.apk`, `anodize-0.2.5-1.src.rpm` (srpm). Filenames follow nfpm v2.44 conventional format.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:263` configures `nfpm` for `deb,rpm,apk` with `bindir: /usr/bin`, `file_name_template: "{{ ProjectName }}_{{ RawVersion }}_{{ Os }}_{{ Arch }}"`, contents/LICENSE/README mapping. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success, 2026-04-15).

## Caveats / known gaps

- `nfpm.if` (Pro templated conditional) — ❌ **missing** from `NfpmConfig`. Tracked in `.claude/known-bugs.md` A1-rev line 28.
- `nfpm.templated_contents`/`templated_scripts` (Pro) — ❌ **missing**. Silent serde drop. Tracked in known-bugs.md A1-rev line 30.
