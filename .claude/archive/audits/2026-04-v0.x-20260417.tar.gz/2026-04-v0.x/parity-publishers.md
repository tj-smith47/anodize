# Parity audit — Publishers slice (Wave A, task #3)

> Generated: 2026-04-16. Auditor: `parity-auditor-publishers`.
> Scope: publisher-tier rows from `goreleaser-complete-feature-inventory.md` sections 2.4, 2.7, 2.8, 2.9, 2.10, 2.11, 2.12 + blob. UPX is build-slice (2.1) and handled by A2. Pro-only macOS/Windows installers (dmg/msi/pkg/nsis/app_bundles) are handled by A5 (pro-features-skeptic) and not re-audited here.
> Filter rule: audit `required` + `strongly-suggested`; `niche` informational (listed, not verdicted); `not-applicable` skipped (Go-runtime-only like `ko`).
> Exclusion sources honoured: `.claude/known-bugs.md` (Active + Design notes + Intentional divergences + Inventory pre-seeds), `.claude/plans/2026-04-15-parity-audit-continuation.md` (Tier 1-4 items), prior session Resolved entries from 2026-04-15 and 2026-04-16.

## How to read findings

| Column | Meaning |
|---|---|
| Verdict | PARITY / BLOCKER / WARN / SUGGEST / TRACKED / INTENTIONAL |
| Dimension | Config / Behavior / Wiring / Error / Auth / Default |
| Ref | `internal/pipe/<pipe>/<file>.go` in `/opt/repos/goreleaser` |
| Ours | `crates/<crate>/src/<file>.rs` in `/opt/repos/anodize` |
| Note | Durable one-line justification |

- **PARITY** — behavior matches; no action.
- **BLOCKER** — wrong output, lost data, broken auth, crash. Must be fixed before release.
- **WARN** — degraded UX, missing observability, subtle misbehavior under edge conditions.
- **SUGGEST** — enhancement / rust-additive opportunity / better default.
- **TRACKED** — already in `.claude/known-bugs.md` Active or continuation plan; row cites the anchor.
- **INTENTIONAL** — documented divergence from GoReleaser; cites rationale row in `known-bugs.md`.

Every finding cites BOTH codebases (or notes "no anodize counterpart"). No grep-only findings. Line numbers omitted per repo rule (feedback_no_line_numbers_in_plans); file and identifier are sufficient.

---

## Executive summary

| Area | BLOCKER | WARN | SUGGEST | TRACKED | PARITY confirmed | Niche informational |
|---|---:|---:|---:|---:|---:|---:|
| Release (SCM: GitHub/GitLab/Gitea) | 0 | 1 | 2 | 3 | 10+ | — |
| Docker v1 + v2 + manifests + digest | 0 | 2 | 1 | 3 | 10+ | dockerhub |
| nfpm (deb/rpm) | 0 | 0 | 1 | 3 | 10+ | apk/archlinux/ipk/termux/srpm |
| Homebrew formula + cask | 0 | 2 | 1 | 0 | 10+ | casks.hooks/service/zap |
| Scoop | 0 | 0 | 1 | 0 | 5+ | — |
| Winget | 0 | 1 | 0 | 0 | 7+ | — |
| AUR | 0 | 1 | 0 | 2 | 5+ | aur_sources |
| Nix | 0 | 0 | 0 | 0 | 6+ | — |
| Custom publishers (publishers[]) | 0 | 0 | 0 | 1 | 5+ | — |
| Blob (s3/gs/azblob) | 0 | 0 | 0 | 0 | 10+ | — |
| **Totals** | **0** | **7** | **6** | **12** | **~80** | multiple |

All findings are enumerated in the batch tables below. BLOCKER count = 0; no publisher sub-area produces wrong output at the current state. WARN findings are either (a) silent-vs-hard-error divergences or (b) missing deprecation notices; SUGGEST items are rust-additive enhancement opportunities. TRACKED items are verified against the continuation plan anchor — anodize should NOT re-discover them.

No bloat candidates surfaced in this slice — every audited publisher row traces directly to a live config surface consumed by at least one packager/broadcaster path. A note to that effect is recorded in `bloat.md`.

---

## Batch 1 — Release (SCM: GitHub / GitLab / Gitea + body + milestone)

**Reference:** `internal/pipe/release/{release.go,body.go,scm.go}`, `internal/pipe/milestone/milestone.go`
**Ours:** `crates/stage-release/src/{lib.rs,gitlab.rs,gitea.rs}`, `crates/cli/src/commands/release/milestones.rs`

Release pipe produces SCM (GitHub/GitLab/Gitea) releases from archives, packages, signatures, checksums, and metadata. Anodize implements the full GoReleaser v2 surface including draft/replace/mode/make-latest/header/footer/skip-upload/extra-files/templated-extra-files/include-meta/discussion-category/target-commitish.

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| WARN | Behavior | `release/release.go` `doPublish` / `ReleaseUploadableTypes` at `internal/artifact/artifact.go` | `stage-release/src/lib.rs` `upload_kinds` hardcoded in `run` | Anodize hardcodes its own 20-kind upload list instead of calling `anodize_core::artifact::release_uploadable_kinds()`. Includes `UniversalBinary`, `Snap`, `DiskImage`, `Installer`, `MacOsPackage`, `Header`, `CArchive`, `CShared` — GoReleaser explicitly excludes the first four (via `isUploadable()` -> `UniversalBinary`, `Snapcraft`, `Metadata`). Over-uploads on GitHub. Fix: reference the canonical helper + document Pro-kind inclusions. |
| SUGGEST | Behavior | `release/body.go` `bodyTemplateText` (trailing `\n`) | `stage-release/src/lib.rs` `build_release_body` (`parts.join("\n")`) | GoReleaser's body template leaves a trailing newline after the footer; anodize's `parts.join` omits it. Cosmetic but surfaces in byte-for-byte body comparison. |
| SUGGEST | Behavior | `release/release.go` upload retry (`retry.Attempts(10)`, `retry.Delay(50ms)`, exponential) | `stage-release/src/lib.rs` GitHub retry loop (`MAX_UPLOAD_ATTEMPTS=10`, `INITIAL_RETRY_DELAY=50ms`, `MAX_RETRY_DELAY=30s`) | GoReleaser uses uncapped exponential (via retry-go default); anodize caps at 30s. Anodize's cap is arguably better (prevents 40-min waits). Rust-additive candidate: document the divergence. |
| TRACKED | Auth | `client/gitlab/gitlab.go` `checkUseJobToken` | `stage-release/src/gitlab.rs` `resolve_use_job_token` | GitLab JOB-TOKEN safety gate. Listed as Tier 1 #1 in `2026-04-15-parity-audit-continuation.md` — verified wired in `resolve_use_job_token`; the continuation-plan anchor remains the authoritative tracker. |
| TRACKED | Behavior | `release/release.go:160-167` `IncludeMeta` semantics | `stage-release/src/lib.rs` (`include_meta` pushes `Metadata` kind conditionally) | Tier 1 #2 claim ("always uploads Metadata") is **outdated** — current code only appends `ArtifactKind::Metadata` to `upload_kinds` when `include_meta=true`. Close the Tier 1 #2 entry as resolved. |
| TRACKED | Behavior | `internal/pipe/milestone/milestone.go` | `cli/src/commands/release/milestones.rs` `resolve_provider` | Tier 1 #4 — mixed-provider fallback. Authoritative anchor in continuation plan; no new finding. |
| PARITY | Default | `release/release.go` `NameTemplate="{{.Tag}}"` | `stage-release/src/lib.rs` default via `name_template` fallback | Default name template matches. |
| PARITY | Default | `release/release.go` `Prerelease=="auto"` branch checks `Semver.Prerelease` | `stage-release/src/lib.rs` `PrereleaseConfig::Auto` | Auto-prerelease detection matches. |
| PARITY | Behavior | `release/release.go` draft-preserve in PATCH path | `stage-release/src/lib.rs` PATCH update-existing branch | `patch_body["draft"] = existing.draft` matches GoReleaser behavior of preserving existing draft state when updating. |
| PARITY | Behavior | `release/scm.go` `setupGitLab`/`setupGitea` warnings for `replace_existing_draft`/`use_existing_draft` | `stage-release/src/lib.rs` matching `log.warn(...)` lines for GitLab + Gitea | GitLab+Gitea draft warnings emit identical messaging. |
| PARITY | Behavior | `release/release.go` `skipUpload` templated bool accepts "auto" (via client) | `stage-release/src/lib.rs` `skip_upload` template rendering with "auto" → `ctx.is_snapshot()` | Behavior matches: `"auto"` returns `is_snapshot`; `"true"`/`"1"` returns true. |
| PARITY | Behavior | `release/release.go` extra_files UploadableFile add | `stage-release/src/lib.rs` `collect_extra_files` | Invalid glob + zero-match globs are hard errors in both. |
| PARITY | Behavior | `release/release.go` PublishRelease (un-draft) patch after upload | `stage-release/src/lib.rs` "draft-then-publish" branch | Un-draft PATCH after all uploads matches; adds `make_latest` and `discussion_category_name` atomically. |
| PARITY | Auth | `release/release.go` token resolution via `client.New(ctx)` | `stage-release/src/lib.rs` `token` resolution via `ctx.token_type` switch | Token/URL env var priority matches (GITHUB_TOKEN/GITLAB_TOKEN/GITEA_TOKEN + `github_urls.api` overrides). |
| PARITY | Config | `pkg/config/config.go` `ReleaseHeader`/`ReleaseFooter` (Pro `from_url`/`from_file`) | `core/src/config.rs` `ContentSource` enum | Pro content-source indirection wired. |

### Niche (informational; not audited per filter rule)
- `release.discussion_category_name`, `release.use_existing_draft` (v2.5+) — inventory rows marked `niche`.
- `release.templated_extra_files` (Pro, niche).
- `github_urls.skip_tls_verify` — known-bugs pre-seed confirms parity at `stage-release/src/lib.rs` `build_octocrab_client_insecure`; do not re-audit.

---

## Batch 2 — Docker (v1 + v2 + manifests + digest)

**Reference:** `internal/pipe/docker/{docker.go,manifest.go}`, `internal/pipe/docker/v2/docker.go`, `internal/pipe/dockerdigest/digest.go`
**Ours:** `crates/stage-docker/src/lib.rs`

Docker v1 is phased-out in GoReleaser in favor of v2; both are still supported. Anodize implements both paths plus `docker_manifests` and combined `dockerdigest`.

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| WARN | Behavior | `docker/docker.go` v1 filter `ByTypes(Binary, LinuxPackage, CArchive, CShared)` in `Run` | `stage-docker/src/lib.rs` `stage_binaries` (v1 helper) reads `by_kind_and_crate(Binary, ...)` only | V1 path stages only `Binary` artifacts; `LinuxPackage`, `CArchive`, `CShared` not staged into the build context. A GoReleaser user migrating a v1 docker config with `ids: [foo-deb]` would find the `.deb` missing from the Dockerfile's COPY context. V2 path (`stage_artifacts_v2`) handles all four kinds correctly. V1 is deprecated upstream, but anodize still claims v1 parity. |
| WARN | Observability | `docker/docker.go` deprecation warning "dockers being phased out" emitted on every run with `dockers[]` | `stage-docker/src/lib.rs` no equivalent warning | GoReleaser loudly warns users to migrate `dockers` → `dockers_v2` (link to deprecations page). Anodize silently accepts v1 config with no nudge. Missing UX signal; hurts user ability to anticipate the upstream deprecation. |
| SUGGEST | Error | `dockerdigest/digest.go` `tmpl.New(ctx).Apply` on `name_template` propagates template errors | `stage-docker/src/lib.rs` combined digest rendering uses `render_template(tmpl).ok()`, silently falls back to `"digests.txt"` | Template errors in `docker_digest.name_template` should bail, not be swallowed. The current `.ok()` masks typos that would produce a wrong filename. |
| TRACKED | Behavior | `docker/v2/docker.go` `isRetriableManifestCreate` | `stage-docker/src/lib.rs` `is_retriable_manifest_create` | Tier 2 #11 in continuation plan ("Docker V2 retry scope"). The narrow "manifest verification failed for digest" match matches GoReleaser. |
| TRACKED | Behavior | `docker/manifest.go` `docker manifest rm` error tolerance | `stage-docker/src/lib.rs` `docker manifest rm` invocation | Tier 2 #12 ("ignore all errors from manifest rm"). Continuation-plan anchor; no new finding. |
| TRACKED | Config | `pkg/config/config.go` `Docker.ID` uniqueness validation | `stage-docker/src/lib.rs` V1/V2 defaulting + ids validate | Tier 2 #10 (prior sessions claim fixed); continuation-plan anchor still in scope. No new finding. |
| PARITY | Default | `docker/docker.go` `Retry.{Attempts=10, Delay=10s, MaxDelay=5m}` | `stage-docker/src/lib.rs` `resolve_retry_params` | Retry defaults match exactly. |
| PARITY | Default | `docker/v2/docker.go` `Platforms=["linux/amd64","linux/arm64"]`, `Tags=["{{.Tag}}"]`, `SBOM="true"` | `stage-docker/src/lib.rs` v2 defaulting block in `run` | v2 platforms/tags/sbom defaults match. |
| PARITY | Behavior | `docker/v2/docker.go` `--attest=type=sbom` when SBOM templated-bool true | `stage-docker/src/lib.rs` `build_docker_command` appends `--attest=type=sbom` on same condition | SBOM attestation flag wired. |
| PARITY | Behavior | `docker/v2/docker.go` `--iidfile=id.txt` + digest read after build | `stage-docker/src/lib.rs` `--iidfile={staging}/id.txt` + digest read at `iidfile` path | IIDFILE digest extraction matches. |
| PARITY | Behavior | `docker/v2/docker.go` annotation `index:` prefix for multi-platform | `stage-docker/src/lib.rs` `build_docker_command` annotation loop prefixes `index:` when `multi_platform` | Annotation prefixing matches. |
| PARITY | Behavior | `docker/v2/docker.go` `tplMapFlags` sorts keys alphabetically before rendering | `stage-docker/src/lib.rs` `rendered_annotations.sort_by(...)` | Deterministic order preserved. |
| PARITY | Behavior | `docker/docker.go` v1 filter requires `len(artifacts.GroupByID()) == len(ids)` → `pipe.Skipf` | `stage-docker/src/lib.rs` v1 validation emits warn when count mismatches | V1 ids cardinality check covered (continuation-plan Tier 2 #10). |
| PARITY | Behavior | `docker/docker.go` `skip_push` template → "true"/"auto" | `stage-docker/src/lib.rs` `SkipPushConfig` template resolution | skip_push path matches. |
| PARITY | Behavior | `dockerdigest/digest.go` format `<hex>  <name>\n` (strip `sha256:` prefix) | `stage-docker/src/lib.rs` `digest_lines.push(format!("{}  {}", hex, name))` after `strip_prefix("sha256:")` | Combined digest format matches byte-for-byte. |

### Niche (informational; not audited per filter rule)
- `dockerhub` description-sync (Pro, niche) — `stage-publish/src/dockerhub.rs` exists.
- `docker.skip_build` (Pro, niche).
- `docker.templated_dockerfile` / `docker.templated_extra_files` (Pro, niche).

---

## Batch 3 — nfpm (deb + rpm core)

**Reference:** `internal/pipe/nfpm/nfpm.go`
**Ours:** `crates/stage-nfpm/src/{lib.rs,filename.rs}`

nfpm builds Linux packages (deb/rpm required; apk/archlinux/ipk/termux.deb niche). Shares artifact-gathering + override-merging + signature-passphrase resolution.

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| SUGGEST | Behavior | `nfpm/nfpm.go` `Deb.ArchVariant = artifacts[0].Goamd64` (unconditional) | `stage-nfpm/src/lib.rs` auto-derives only when `deb.arch_variant.is_none()` | GoReleaser always overrides `deb.arch_variant` from the artifact; anodize respects user override. Anodize behavior is ergonomically safer (explicit user config wins), but divergent. Document the divergence. |
| TRACKED | Default | `nfpm/nfpm.go` `defaultNameTemplate` + per-packager `ConventionalFileName` | `stage-nfpm/src/filename.rs` per-packager `conventional_filename` + fallback to `{pkg}_{ver}_{os}_{arch}{ext}` | Tier 3 #15. Current anodize implementation was landed 2026-04-16 (see resolved known-bugs for the `filename.rs` ledger entry). Authoritative anchor; no new finding. |
| TRACKED | Deprecation | `nfpm/nfpm.go` `deprecate.NoticeCustom("nfpms.maintainer", ...)` when empty | `cli/src/pipeline.rs::detect_deprecated_aliases` — emits "maintainer should always be set" | Deprecation detection wired; cross-referenced in continuation-plan Tier 3 #13 (broader sweep still outstanding). |
| TRACKED | Deprecation | `nfpm/nfpm.go` `deprecate.Notice("nfpms.builds")` when builds set | `cli/src/pipeline.rs::detect_deprecated_aliases` — emits "`nfpm[].builds` is deprecated, use `nfpm[].ids`" | Matches. |
| PARITY | Default | `nfpm/nfpm.go` `Bindir="/usr/bin"`, `Libdirs.Header="/usr/include"`, `Libdirs.CShared="/usr/lib"`, `Libdirs.CArchive="/usr/lib"`, `PackageName=ProjectName`, `ID="default"` | `core/src/config.rs` + `stage-nfpm/src/lib.rs` defaults block | All nfpm defaults match. |
| PARITY | Auth | `nfpm/nfpm.go` `getPassphraseFromEnv` priority: `NFPM_<ID>_<FORMAT>_PASSPHRASE` → `NFPM_<ID>_PASSPHRASE` → `NFPM_PASSPHRASE` | `stage-nfpm/src/lib.rs` passphrase resolver same priority order | Passphrase env priority matches. |
| PARITY | Behavior | `nfpm/nfpm.go` termux.deb arch translation (`386`→`i686`, `amd64`→`x86_64`, `arm64`→`aarch64`, `arm6`→`arm`) + bindir/libdir prefixing | `stage-nfpm/src/filename.rs` `arch_to_termux` + `lib.rs` termux prefix handling | Termux handling matches. |
| PARITY | Behavior | `nfpm/nfpm.go` `isSupportedArchlinuxArch` (all/amd64/arm64/386 + arm-v7) | `stage-nfpm/src/filename.rs` + `lib.rs` archlinux filter | Archlinux arch support matches. |
| PARITY | Behavior | `nfpm/nfpm.go` `mergeOverrides` via `mergo.Merge` | `stage-nfpm/src/lib.rs` override-merging in YAML generation | Per-format override merging matches semantically; anodize uses explicit field-by-field struct merge. |
| PARITY | Config | `nfpm/nfpm.go` rpm/deb/apk/archlinux/ipk signature+script sub-configs | `core/src/config.rs` `NfpmRpmConfig`/`NfpmDebConfig`/`NfpmApkConfig`/`NfpmArchlinuxConfig`/`NfpmIpkConfig` | Full config surface mapped. |
| PARITY | Behavior | `nfpm/nfpm.go` `Deb.Lintian` file generated + added to contents | `stage-nfpm/src/lib.rs` lintian content injection | Lintian override wired. |
| PARITY | Behavior | `nfpm/nfpm.go` `Meta==true` skips binary contents, produces metadata-only package | `stage-nfpm/src/lib.rs` meta-only path | Meta-package path wired. |

### Niche (informational; not audited per filter rule)
- `nfpm.formats: apk / archlinux / ipk / termux.deb` — niche in inventory.
- `nfpm.templated_contents` / `nfpm.templated_scripts` (Pro, niche).
- `srpm` — `stage-srpm` via rpmbuild subprocess (intentional divergence from nfpm Go library, per known-bugs Design notes).

---

## Batch 4 — Homebrew (formula + cask)

**Reference:** `internal/pipe/brew/brew.go`, `internal/pipe/cask/cask.go`
**Ours:** `crates/stage-publish/src/homebrew.rs`

Homebrew formula is `strongly-suggested` + required for macOS distribution; casks are `strongly-suggested` and serve GUI/signed-binary distribution. Anodize combines both into a single `stage-publish/src/homebrew.rs`.

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| WARN | Error | `brew/brew.go` `doRun` returns `ErrNoArchivesFound` when 0 archives match filters | `stage-publish/src/homebrew.rs` `publish_to_homebrew` proceeds to formula generation with empty archive list | Anodize silently writes a formula with no `url`/`sha256` lines when no archives match the goarm/goamd64/id filters. GoReleaser hard-fails with a diagnostic citing `goos`, `goarch`, `goamd64`, `goarm`, and `ids`. Produces an unusable formula instead of a clear error. |
| WARN | Observability | `brew/brew.go` `Default` emits "brews is being phased out in favor of homebrew_casks" warning | `stage-publish/src/homebrew.rs` + `cli/src/pipeline.rs` no equivalent | GoReleaser emits a deprecation notice once per run when `brews[]` is used; anodize accepts `brews` config without nudging users toward `homebrew_casks`. Missing UX signal for upstream migration path. |
| SUGGEST | Behavior | `brew/brew.go` filter excludes `ByFormats("gz")` on `UploadableArchive` | `stage-publish/src/homebrew.rs` archive collection does not filter gz-format archives | GoReleaser explicitly excludes single-file gzipped artifacts (format=`gz`, e.g. a raw gzipped binary, distinct from `tar.gz`). Anodize doesn't filter them, so a `formats: [gz]` archive config would slip into the formula with wrong extraction logic. Niche — rarely hit. |
| PARITY | Default | `brew/brew.go` `Name=ProjectName`, `Goarm=DefaultGOARM="6"`, `Goamd64="v1"`, `CommitMessageTemplate="Brew formula update for {{ .ProjectName }} version {{ .Tag }}"` | `stage-publish/src/homebrew.rs` `render_commit_msg("formula")` + defaulting | All defaults match (GoReleaser `{{ .ProjectName }}` → anodize `{{ ProjectName }}` via Tera; preprocessor normalizes the dot). |
| PARITY | Behavior | `brew/brew.go` `OnlyReplacingUnibins` filter | `stage-publish/src/homebrew.rs` `.filter(|a| a.only_replacing_unibins())` | Unibin-replacement filter wired. |
| PARITY | Behavior | `brew/brew.go` `ErrMultipleArchivesSameOS` when >1 archive for same `os+arch` | `stage-publish/src/homebrew.rs` duplicate-OS+arch bail in `archive_data` collection | Duplicate-per-OS-arch hard error matches. |
| PARITY | Behavior | `brew/brew.go` `SkipUpload="auto"` + prerelease → pipe.Skip | `stage-publish/src/homebrew.rs` `should_skip_upload` | Auto-skip on prerelease wired. |
| PARITY | Behavior | `brew/brew.go` goamd64/goarm filter per artifact | `stage-publish/src/homebrew.rs` amd64_variant/arm_variant filter via metadata | Per-architecture-variant filtering matches. |
| PARITY | Behavior | `brew/brew.go` install lines from `ExtraBinaries` when multiple | `stage-publish/src/homebrew.rs` auto-generates multi-`bin.install` from `extra_binaries()` when `install` unset | Install auto-generation covers multi-binary archives. |
| PARITY | Behavior | `brew/brew.go` writes to `dist/homebrew/<directory>/<name>.rb` | `stage-publish/src/homebrew.rs` writes `dist/homebrew/<directory>/<name>.rb` then clones to tap | Dist location matches; anodize additionally clones the tap repo and commits (GoReleaser's git-upload client handles commit separately). |
| PARITY | Config | `brew/brew.go` `Repository.Git.URL` + `PullRequest.Enabled` + `CommitAuthor.Signing` (v2.11+) | `core/src/config.rs` `RepositoryConfig` + full pull-request + commit-author-signing | Full repository config surface mapped. |
| PARITY | Behavior | `cask/cask.go` distinct cask generation with `binaries/app/manpages/completions` | `stage-publish/src/homebrew.rs` cask generator with same field set | Cask surface wired including `on_macos`/`on_linux` + `on_intel`/`on_arm` nesting. |
| PARITY | Behavior | `cask/cask.go` `generate_completions_from_executable` | `stage-publish/src/homebrew.rs` completions support | Wired. |

### Niche (informational; not audited per filter rule)
- `brews.repository.pull_request.check_boxes` (Pro, niche).
- `brews.app` (Pro, niche — DMG app integration).
- `homebrew_casks.hooks` (v2.13+, niche).
- `homebrew_casks.service`, `homebrew_casks.zap`, `homebrew_casks.uninstall` (niche).

---

## Batch 5 — Scoop + Winget (Windows publish)

**Reference:** `internal/pipe/scoop/scoop.go`, `internal/pipe/winget/winget.go`
**Ours:** `crates/stage-publish/src/{scoop.rs,winget.rs}`

Both are Windows-only publish channels. Scoop is `strongly-suggested`; Winget is `strongly-suggested`. Chocolatey is `niche` (informational only per filter rule).

### Scoop

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| SUGGEST | Default | `scoop/scoop.go` `CommitMessageTemplate="Scoop update for {{ .ProjectName }} version {{ .Tag }}"` | `stage-publish/src/scoop.rs` default `"Scoop update for {{ name }} version {{ version }}"` | Anodize uses `{{ name }}` and `{{ version }}` vars; GoReleaser uses `{{ .ProjectName }}` / `{{ .Tag }}`. Semantically equivalent in rendered output (anodize aliases `name` ↔ ProjectName, `version` ↔ Tag-stripped), but the default-template *string* differs, which confuses users doing literal text comparison. Align default-template string to the canonical GoReleaser form. |
| PARITY | Default | `scoop/scoop.go` `Name=ProjectName`, `Goamd64="v1"` | `stage-publish/src/scoop.rs` defaults | Match. |
| PARITY | Behavior | `scoop/scoop.go` `ErrIncorrectArchiveCount` on 0 archives OR >1 per platform | `stage-publish/src/scoop.rs` `arch_entries.is_empty()` bail + per-arch duplicate bail | Hard error parity for both zero-match and duplicate-per-arch cases. |
| PARITY | Behavior | `scoop/scoop.go` filter `ByGoos("windows")`, `UploadableArchive`, goarch in `[amd64+goamd64, arm64, 386]` | `stage-publish/src/scoop.rs` `target.contains("windows")` + amd64_variant check + arch mapping `amd64→64bit`, `386→32bit`, `arm64→arm64` | Windows+arch filter matches. |
| PARITY | Behavior | `scoop/scoop.go` writes `dist/scoop/<directory>/<name>.json` | `stage-publish/src/scoop.rs` generates manifest JSON and clones bucket repo | Manifest location + bucket-clone pattern matches. |
| PARITY | Behavior | `scoop/scoop.go` `OnlyReplacingUnibins` filter (via archive filter chain) | `stage-publish/src/scoop.rs` `.filter(|a| a.only_replacing_unibins())` | Unibin filter wired. |
| PARITY | Config | `pkg/config/config.go` `Scoop` fields: persist/pre_install/post_install/depends/shortcuts/skip_upload | `core/src/config.rs` `ScoopConfig` | All Scoop fields wired. |

### Winget

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| WARN | Error | `winget/winget.go` `errNoShortDescription` returned when `short_description` empty | `stage-publish/src/winget.rs` falls back `short_description` to `description` then to `crate_name` | GoReleaser enforces `short_description` as a required field. Anodize auto-generates from description/crate_name, which can produce a stub like `"mycrate"` that fails the Windows Package Community Repository's validation. Either surface the requirement as an error (strict parity) OR document the divergence explicitly — anodize's current lenient fallback is an undocumented behavior drift. |
| PARITY | Default | `winget/winget.go` `CommitMessageTemplate="New version: {{ .PackageIdentifier }} {{ .Version }}"`, `Name=ProjectName`, `Goamd64="v1"`, `PackageName=Name` | `stage-publish/src/winget.rs` `render_commit_msg` defaults | Match. |
| PARITY | Behavior | `winget/winget.go` `packageIdentifierValid` regex: `^[^\.\s\\/:\*\?"<>\|\x01-\x1f]{1,32}(\.[^\.\s\\/:\*\?"<>\|\x01-\x1f]{1,32}){1,7}$` | `stage-publish/src/winget.rs` `validate_package_identifier` | Same regex + same format error message. |
| PARITY | Behavior | `winget/winget.go` auto PackageIdentifier = `Publisher.Name` (spaces removed from Publisher) | `stage-publish/src/winget.rs` `format!("{}.{}", publisher_name.replace(' ', ""), name)` | Auto-ID matches. |
| PARITY | Behavior | `winget/winget.go` tabs in Description → 2-space (YAML compat) | `stage-publish/src/winget.rs` `description_tmpl.replace('\t', "  ")` | Description tab→space matches. GoReleaser does NOT apply this to short_description; anodize also applies it to short_description — harmless superset. |
| PARITY | Behavior | `winget/winget.go` zip-format filter for `UploadableArchive` + `UploadableBinary` | `stage-publish/src/winget.rs` `.zip` extension filter + `installer_type="portable"` for bare binaries | Zip-only archive filter matches; portable-binary path wired. |
| PARITY | Error | `winget/winget.go` `errMixedFormats` when both .exe and .zip found | `stage-publish/src/winget.rs` bail when `binary_count > 0 && zip_count > 0` | Mixed-format hard error matches. |
| PARITY | Error | `winget/winget.go` `errNoRepoName`, `errNoPublisher`, `errNoLicense` required-field guards | `stage-publish/src/winget.rs` matching required-field bails | Repo-name, publisher, license required checks wired. |
| PARITY | Behavior | `winget/winget.go` default `Path = "manifests/<first-letter-lowercase>/<publisher-path>/<version>"` | `stage-publish/src/winget.rs` same path derivation | Manifest path matches. |
| PARITY | Behavior | `winget/winget.go` 3-file emission (version.yaml, installer.yaml, locale.yaml) | `stage-publish/src/winget.rs` three `WingetVersion`/`WingetInstaller`/`WingetDefaultLocale` artifacts | Three-YAML emission wired. |

### Niche (informational; not audited per filter rule)
- All of `chocolatey` (niche in inventory): `stage-publish/src/chocolatey.rs` exists with full config surface. Skipped per filter rule.

---

## Batch 6 — AUR + Nix

**Reference:** `internal/pipe/aur/aur.go`, `internal/pipe/nix/{nix.go,licenses.go}`
**Ours:** `crates/stage-publish/src/{aur.rs,nix.rs}`

AUR is `strongly-suggested`; Nix is `strongly-suggested`. `aur_sources` and `krew` are niche.

### AUR

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| WARN | Error | `aur/aur.go` `doRun` returns `ErrNoArchivesFound` when 0 linux archives match | `stage-publish/src/aur.rs` when `linux_artifacts.is_empty()`, warns + emits placeholder URL `https://github.com/{crate}/releases/download/v{version}/{crate}-{version}-linux-amd64.tar.gz` + empty sha256 | Anodize writes a broken PKGBUILD (placeholder URL + empty sha256) rather than hard-failing. Downstream `makepkg` will fail with a confusing sha256 mismatch instead of a clear "no archives matched goos=linux" error. |
| TRACKED | Behavior | `aur/aur.go` URL-template variable substitution preserves `${pkgver}` literal | `stage-publish/src/aur.rs` URL rendering — Tier 1 #5 concern | Continuation-plan anchor (Tier 1 #5) tracks the shell-substitution semantics. No new finding here. |
| TRACKED | Config | `aur/aur.go` push target branch | `stage-publish/src/aur.rs` `commit_and_push_with_opts` hardcoded `"master"` | Tier 1 #6 anchor — AUR repos require master branch push. Verified wired per 2026-04-15 Resolved log. |
| PARITY | Default | `aur/aur.go` `Name=ProjectName+"-bin"` (if not already `-bin`), `Conflicts=[ProjectName]`, `Provides=[ProjectName]`, `Rel="1"`, `Goamd64="v1"`, `CommitMessageTemplate="Update to {{ .Tag }}"` | `stage-publish/src/aur.rs` defaulting block | All defaults match. |
| PARITY | Behavior | `aur/aur.go` filter `ByGoos("linux")`, `UploadableArchive`+`UploadableBinary`, goarch in `[amd64+goamd64, arm64, 386, arm+armv7]` | `stage-publish/src/aur.rs` `find_artifacts_by_os_with_variant("linux", ...)` + arch filter | Linux + arch filter matches. |
| PARITY | Behavior | `aur/aur.go` auto-generate `package` section when empty: `install -Dm755 "./<name>" "${pkgdir}/usr/bin/<bin>"` | `stage-publish/src/aur.rs` `install -Dm755 "$srcdir/<bin>" "$pkgdir/usr/bin/<bin>"` | Install line matches template. |
| PARITY | Behavior | `aur/aur.go` arch translation `arm64→aarch64`, `386→i686`, `arm→armv7h` | `stage-publish/src/aur.rs` `pkgbuild_arch` map | AUR arch mapping matches. |
| PARITY | Behavior | `aur/aur.go` writes `.SRCINFO` alongside PKGBUILD | `stage-publish/src/aur.rs` writes `.SRCINFO` via `generate_srcinfo` | SRCINFO generation wired. |
| PARITY | Config | `pkg/config/config.go` AUR fields: `maintainers`, `contributors`, `license`, `private_key`, `git_url`, `skip_upload`, `optdepends`, `backup`, `install`, `disable` | `core/src/config.rs` `AurConfig` | Full surface mapped. |

### Nix

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| PARITY | Default | `nix/nix.go` `Name=ProjectName`, `Goamd64="v1"`, `CommitMessageTemplate="{{ .ProjectName }}: {{ .PreviousTag }} -> {{ .Tag }}"` | `stage-publish/src/nix.rs` defaults via `render_commit_msg("nix")` | All defaults match. |
| PARITY | Behavior | `nix/licenses.go` `validLicenses` whitelist (~290 entries) | `stage-publish/src/nix.rs` `VALID_NIX_LICENSES` array (~292 entries) + `validate_nix_license` | License whitelist effectively synced (≤2 entries drift). Anodize's extra entries do not cause behavior regressions. |
| PARITY | Error | `nix/nix.go` `errInvalidLicense` on non-whitelist license | `stage-publish/src/nix.rs` `validate_nix_license` bails with valid-list | Error parity. |
| PARITY | Error | `nix/nix.go` `ErrMultipleArchivesSamePlatform` | `stage-publish/src/nix.rs` per-system duplicate detection | Multi-archive guard wired. |
| PARITY | Behavior | `nix/nix.go` default path `pkgs/<name>/default.nix` | `stage-publish/src/nix.rs` default path `pkgs/<name>/default.nix` | Path default matches. |
| PARITY | Behavior | `nix/nix.go` filter logic for `darwin`/`linux` cross-arch artifacts | `stage-publish/src/nix.rs` nix-system mapping | OS+arch→nix-system mapping wired. |
| PARITY | Behavior | `nix/nix.go` `formatter` invocation after write | `stage-publish/src/nix.rs` formatter subprocess call | Formatter wired. |
| PARITY | Behavior | `nix/nix.go` ELF-parser-based architecture detection for binaries | `stage-publish/src/nix.rs` custom ELF parser (`read_u16`/`read_u32`/`read_u64` helpers) | ELF parsing wired — see known-bugs Resolved entry 2026-04-16 for the `unwrap_or_else(|| panic!(...))` programmer-bug encoding. |

---

## Batch 7 — Custom publishers (publishers[]) + Blob

**Reference:** `internal/pipe/custompublishers/custompublishers.go`, `internal/exec/exec.go`, `internal/pipe/blob/{blob.go,upload.go}`
**Ours:** `crates/cli/src/commands/publisher.rs` (custom), `crates/stage-blob/src/lib.rs`

Custom publishers are `strongly-suggested`; blob is `strongly-suggested`. Both use the canonical release-uploadable kind set.

### Custom publishers

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| TRACKED | Behavior | `exec/exec.go` `filterArtifacts` curated 10-type default | `cli/src/commands/publisher.rs` `matches_publisher_filter` default set (9 kinds mapping to GoReleaser minus Python-runtime `PySdist`/`PyWheel`) | Tier 2 #8 in continuation plan; 2026-04-15 Resolved log confirms narrow list is in effect. Anodize default: Archive + UploadableFile + LinuxPackage + UploadableBinary + DockerImage + DockerManifest + DockerImageV2 + SourceArchive + Sbom. Matches GoReleaser minus Python kinds (not-applicable). Opt-ins for Checksum, Metadata, Signature+Certificate wired per `checksum`/`meta`/`signature` publisher flags. |
| PARITY | Behavior | `exec/exec.go` `passthroughEnvVars = [HOME, USER, USERPROFILE, TMPDIR, TMP, TEMP, PATH, SYSTEMROOT]` | `cli/src/commands/publisher.rs` env-passthrough set | Passthrough env list matches. |
| PARITY | Behavior | `exec/exec.go` `resolveCommand` templates `cmd`, `dir`, `env` per artifact | `cli/src/commands/publisher.rs` `build_publisher_command` + template-render `dir`/`env` | Per-artifact template rendering wired including `ArtifactPath`, `ArtifactName`, `ArtifactKind` vars. |
| PARITY | Behavior | `exec/exec.go` `shellwords.Parse(cmd)` | `cli/src/commands/publisher.rs` `shell_words::split` | Shell-word tokenization matches (both tools use `caarlos0/go-shellwords` semantics). |
| PARITY | Behavior | `exec/exec.go` `tmpl.New(ctx).Bool(publisher.Disable)` | `cli/src/commands/publisher.rs` `disable` template-bool resolution | Disable template wired. |
| PARITY | Behavior | `exec/exec.go` `extrafiles.Find` treats each extra-file as an `UploadableFile` artifact | `cli/src/commands/publisher.rs` extra-files integration | Extra-files wired. |
| PARITY | Error | `exec/exec.go` wraps non-zero exit with `gerrors.Wrap(..., WithOutput(...))` | `cli/src/commands/publisher.rs` captures stdout/stderr into error context | Error context attached. |

### Blob

| Verdict | Dimension | Ref | Ours | Note |
|---|---|---|---|---|
| PARITY | Behavior | `blob/upload.go` `artifactList` uses `ReleaseUploadableTypes()` + optional `Metadata` when `IncludeMeta` | `stage-blob/src/lib.rs` `collect_artifacts` uses `release_uploadable_kinds()` + optional `Metadata` | Canonical kind list used correctly — blob path is the "right" example of referencing the canonical helper (vs the stage-release WARN finding). |
| PARITY | Default | `blob/blob.go` `Directory="{{ .ProjectName }}/{{ .Tag }}"`, `ContentDisposition="attachment;filename={{.Filename}}"` with `"-"` sentinel to disable | `stage-blob/src/lib.rs` same defaults + `"-"` sentinel | Match. |
| PARITY | Error | `blob/blob.go` `Default` errors on empty bucket or provider | `stage-blob/src/lib.rs` bail on empty `provider`/`bucket` | Required-field errors match. |
| PARITY | Behavior | `blob/upload.go` `urlFor` — s3-specific query params: `endpoint`, `s3ForcePathStyle`, `region`, `disable_https` | `stage-blob/src/lib.rs` S3-bucket URL construction via `build_s3_store` | S3 URL query params wired. |
| PARITY | Behavior | `blob/upload.go` ACL validation against AWS SDK canned-ACL set (private/public-read/...) | `stage-blob/src/lib.rs` ACL passed via `x-amz-acl` header with validation in `build_s3_store` | ACL validation wired. |
| PARITY | Behavior | `blob/upload.go` `extraFilesOnly` skips artifact list | `stage-blob/src/lib.rs` `extra_files_only` early return | Extra-files-only path wired. |
| PARITY | Behavior | `blob/upload.go` per-artifact + per-extra-file semerrgroup | `stage-blob/src/lib.rs` Phase 2 `run_parallel_chunks` + intra-config per-file tokio semaphore | Two-tier parallelism. Known-bugs Resolved log 2026-04-16 covers the Phase 1 / Phase 2 split. |
| INTENTIONAL | Behavior | `blob/upload.go` `secrets.OpenKeeper(ctx, conf.KMSKey)` via gocloud.dev secrets | `stage-blob/src/lib.rs` KMS via aws/gcloud/az CLI shell-out | Documented intentional divergence (known-bugs Design notes: "Blob KMS via CLI shell-out not gocloud.dev"). Rust equivalent of gocloud.dev secrets doesn't exist; CLI shell-out is the pragmatic path. |
| PARITY | Behavior | `blob/upload.go` `content_disposition` template-renders `{{.Filename}}` with artifact name | `stage-blob/src/lib.rs` `disp_template` with `Filename` variable in template vars | Per-artifact content-disposition render wired. |

### Niche (informational; not audited per filter rule)
- `aur_sources` (niche) — `stage-publish/src/aur_source.rs` exists.
- `krew` (niche) — `stage-publish/src/krew.rs` exists. Continuation plan Tier 2 #7 notes "re-verify description/short_description required validation" — authoritative anchor.
- `artifactory` (niche) — `stage-publish/src/artifactory.rs`; `extra_files_only` / `extra_files` / `templated_extra_files` wired.
- `uploads[]` (niche generic HTTP) — `stage-publish/src/upload.rs`.
- `fury` / `cloudsmith` (Pro, niche) — wired as `PublisherConfig` / `stage-publish/src/cloudsmith.rs`.
- `crates.io publish` — rust-additive; `stage-publish/src/crates_io.rs`. No GoReleaser equivalent.
- `dockerhub` (Pro, niche, description sync) — `stage-publish/src/dockerhub.rs`.

---

## Summary of non-TRACKED actionable findings

These are the 13 new, non-tracked findings from this audit. TRACKED findings cite the continuation-plan anchor and are owned by that ledger — they don't appear here.

| ID | Verdict | Area | Summary |
|---|---|---|---|
| PUB-1 | WARN | Release | `stage-release/src/lib.rs` hardcodes 20-kind upload list instead of referencing `anodize_core::artifact::release_uploadable_kinds()`; over-uploads Snap + Pro types on GitHub. Fix: use the helper + document Pro-kind inclusions. |
| PUB-2 | WARN | Docker v1 | V1 `stage_binaries` only stages `Binary` artifacts; GoReleaser also stages `LinuxPackage`, `CArchive`, `CShared`. V1 is deprecated upstream but still supported. Add staging for the other 3 kinds in `stage_binaries`. |
| PUB-3 | WARN | Docker v1 | No "dockers being phased out" deprecation warning when `dockers[]` config is present. Add to `cli/src/pipeline.rs::detect_deprecated_aliases` (top-level, not per-crate). |
| PUB-4 | WARN | Homebrew | `publish_to_homebrew` writes formula with empty url/sha256 when no archives match filters; GoReleaser returns `ErrNoArchivesFound`. Add a pre-generate bail that cites goos/goarch/goamd64/goarm/ids. |
| PUB-5 | WARN | Homebrew | No "brews being phased out in favor of homebrew_casks" deprecation. Add to `cli/src/pipeline.rs::detect_deprecated_aliases`. |
| PUB-6 | WARN | Winget | `short_description` silently falls back to description then crate_name; GoReleaser errors (`errNoShortDescription`). Either match strict behavior or document the lenient fallback as intentional in known-bugs Design notes. |
| PUB-7 | WARN | AUR | Empty linux-archive set produces broken PKGBUILD (placeholder URL + empty sha256); GoReleaser returns `ErrNoArchivesFound`. Add hard-fail at `linux_artifacts.is_empty()` in `stage-publish/src/aur.rs`. |
| PUB-8 | SUGGEST | Release body | `build_release_body` omits trailing newline present in GoReleaser's `bodyTemplateText`; cosmetic but surfaces in byte-for-byte diff. |
| PUB-9 | SUGGEST | Release upload | `MAX_RETRY_DELAY=30s` cap is arguably better than GoReleaser's uncapped exponential; document as rust-additive divergence. |
| PUB-10 | SUGGEST | Docker digest | `docker_digest.name_template` render uses `.ok()` and silently falls back to `digests.txt`; propagate template errors instead. |
| PUB-11 | SUGGEST | nfpm | `deb.arch_variant` divergence — anodize respects user override, GoReleaser always forces from artifact. Document the divergence; anodize behavior is arguably correct. |
| PUB-12 | SUGGEST | Homebrew | `ByFormats("gz")` exclusion not applied in anodize archive filter. Niche (rare `formats: [gz]` configs). Add a format=gz filter for strict parity. |
| PUB-13 | SUGGEST | Scoop | Default commit-template string uses `{{ name }}` / `{{ version }}` vars; GoReleaser uses `{{ .ProjectName }}` / `{{ .Tag }}`. Semantically equivalent but diverges from the canonical form users copy from GoReleaser docs. Align the default-template string. |

## Tracked-elsewhere cross-reference

These are the publisher-area findings that are already tracked — they are NOT additional work for this audit, but are listed so A10 consolidation doesn't double-count:

| Tracked ID | Anchor | Location |
|---|---|---|
| Tier 1 #1 | GitLab JOB-TOKEN safety | `stage-release/src/gitlab.rs::resolve_use_job_token` |
| Tier 1 #2 | Release `include_meta` semantics — **anodize auditor asserts resolved**; recommend closing in continuation plan | `stage-release/src/lib.rs` `upload_kinds` conditional Metadata push |
| Tier 1 #4 | Milestone repo/provider resolution | `cli/src/commands/release/milestones.rs` |
| Tier 1 #5 | AUR URL `${pkgver}` shell substitution | `stage-publish/src/aur.rs` |
| Tier 1 #6 | AUR push branch pinned to master | `stage-publish/src/aur.rs::commit_and_push_with_opts` |
| Tier 2 #7 | Krew description/short_description required (re-verify) | `stage-publish/src/krew.rs` |
| Tier 2 #8 | Custom publisher default filter scope — **resolved 2026-04-15** | `cli/src/commands/publisher.rs::matches_publisher_filter` |
| Tier 2 #9 | SBOM dedup UniversalBinary + source darwin | `stage-sbom/src/lib.rs` (not publisher scope) |
| Tier 2 #10 | Docker ID uniqueness validation (re-verify) | `stage-docker/src/lib.rs` |
| Tier 2 #11 | Docker V2 retry scope — `is_retriable_manifest_create` already narrow | `stage-docker/src/lib.rs::is_retriable_manifest_create` |
| Tier 2 #12 | Docker `manifest rm` error tolerance | `stage-docker/src/lib.rs` |
| Tier 3 #14 | nfpm Deb `arch_variant` — wired via auto-derive | `stage-nfpm/src/lib.rs` + `core/src/config.rs` `NfpmDebConfig` |
| Tier 3 #15 | nfpm ConventionalFileName per-packager — **landed 2026-04-16** | `stage-nfpm/src/filename.rs` |

Tier 1 #2 and Tier 2 #8 are believed RESOLVED by this audit's code-reads; recommend the A10 consolidation pass move them into `known-bugs.md::Resolved`.

## Intentional divergences (confirmed, do-not-re-audit)

Publisher-area rows from known-bugs "Intentional parity divergences":

| Item | Anchor |
|---|---|
| Teams announcer uses AdaptiveCard not MessageCard | announce slice (out of this batch) |
| Blob KMS via CLI shell-out (not gocloud.dev) | `stage-blob/src/lib.rs` KMS handling |
| SRPM uses rpmbuild subprocess (not nfpm Go library) | `stage-srpm/src/lib.rs` |

## Bloat candidates

None surfaced in this publisher slice. Every audited publisher row traces directly to a live config surface consumed by at least one packager/broadcaster path. See `bloat.md` for the written confirmation.










