---
feature: homebrew (brews[]/homebrew_formulas[] + homebrew_casks[])
status: tested
ecosystem_relevance: required
tier: OSS+Pro
---

# Homebrew Formula + Cask

## Status: ✅ tested

Covers: `brews[]`/`homebrew_formulas[]`, `name`/`alternative_names` (Pro), `ids`/`goarm`/`goamd64`, `url_template`/`url_headers`/`download_strategy`/`custom_require`/`custom_block`, `homepage`/`description`/`license`/`caveats`, `install`/`extra_install`/`post_install`/`test`, `dependencies`, `conflicts`, `service`/`plist`, `commit_msg_template`/`directory`, `skip_upload`, `repository.*` (+ PR-based via `pull_request.*`, `check_boxes` Pro), `commit_author.*`, commit signing (v2.11+), `app` (DMG, Pro). `homebrew_casks[]` with `binaries`/`app`/`manpages`/`completions`/`generate_completions_from_executable`/`url.*`/`hooks` (v2.13+)/`service`/`zap`/`uninstall`.

## Evidence

- **Unit tests (~87 + 24)**: `crates/stage-publish/src/homebrew.rs` (87 tests: `fn test_*`), `crates/stage-publish/src/cask.rs` — formula rendering, cask shape, repository PR path, url_template, download_strategy fallback, service/plist blocks, commit signing, download/url headers.
- **Config parsing**: `crates/core/tests/config_parsing_tests.rs::test_parse_publish_homebrew_*` (L1601–L1669).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs the 87 formula + cask unit tests.
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:304` configures `homebrew` with tap `tj-smith47/homebrew-tap`, directory `Formula`, install + test blocks.
- **Dogfood (cfgd v0.3.5 — live tap update)**: `/opt/repos/cfgd/.anodize.yaml:174` configures `homebrew.tap.owner=tj-smith47`, `name=homebrew-tap`, `directory=Formula`, install `bin.install "cfgd"`, test `system "#{bin}/cfgd", "--version"`. Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success, 2026-04-15) with `HOMEBREW_TAP_TOKEN` secret — pushed to tap repo.

## Caveats / known gaps

- `homebrew.app` (Pro, DMG integration) implemented but no live dogfood — would require a `.dmg` artifact flowing into the formula.
- `homebrew_casks` — unit tests only, no live release cask-publish. cfgd installs via `homebrew` formula, not cask.
