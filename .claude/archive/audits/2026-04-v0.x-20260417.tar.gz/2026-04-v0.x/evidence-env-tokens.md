---
feature: env list, env_files, variables (custom), snapshot, auto-snapshot, install-sh rendering
status: tested
ecosystem_relevance: required/strongly-suggested
tier: OSS+Pro
---

# env / env_files / variables / snapshot

## Status: ✅ tested

Covers: global `env:` list (GoReleaser form), `env_files.github_token`/`gitlab_token`/`gitea_token` structured token files, custom `variables:` (.Var.* custom user values), `snapshot.name_template`, `--auto-snapshot`.

## Evidence

- **Unit tests**: `crates/core/src/config.rs` (env/env_files parsing), `crates/core/src/template.rs` (custom `.Var.*` rendering).
- **Integration tests**: `crates/cli/tests/integration.rs::test_e2e_auto_snapshot_dirty_repo` (L3322), `test_e2e_snapshot_version_in_artifacts` (L2587).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **Live proof**:
  - cfgd `/opt/repos/cfgd/.anodize.yaml:12` sets `env: [REGISTRY=ghcr.io, RELEASE_TYPE=stable]`; `:16` `variables: repo_url/description`. Rendered into docker_v2 tag templates, release footer, announce payloads — all verified live at https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success).
  - anodize `/opt/repos/anodize/.anodize.yaml:15` `env:` + `:19` `variables:`.

## Caveats / known gaps

- `env_files.github_token` file-path loader implemented but dogfood uses `secrets.GH_PAT` env var, not a token file — file-path code-path untested live.
