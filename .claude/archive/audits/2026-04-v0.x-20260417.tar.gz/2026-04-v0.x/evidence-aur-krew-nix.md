---
feature: aurs[] / aur_sources[] / krews[] / nix[]
status: tested
ecosystem_relevance: strongly-suggested/niche
tier: OSS
---

# AUR + Krew + Nix

## Status: ✅ tested

Covers: `aurs[]` (name/ids/homepage/description/maintainers/contributors/license/private_key/git_url/skip_upload/provides/conflicts/depends/optdepends/backup/package/install/commit_msg_template/goamd64/git_ssh_command/url_template/directory/disable), `aur_sources[]`, `krews[]` (ids/goarm/goamd64/url_template/commit_msg_template/homepage/description/short_description/caveats/skip_upload), `nix[]` (name/ids/goamd64/url_template/commit_msg_template/path/homepage/description/license/skip_upload/dependencies/install/extra_install/post_install/formatter, ELF architecture parsing).

## Evidence

- **Unit tests**: `crates/stage-publish/src/aur.rs` (12), `crates/stage-publish/src/aur_source.rs` (5), `crates/stage-publish/src/krew.rs` (10), `crates/stage-publish/src/nix.rs` (14). Includes Arch PKGBUILD rendering, krew YAML validator-compatibility, nix `.nix` derivation with ELF parsing.
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15).
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:339/347/356` configures aur/nix/krew.
- **Dogfood (cfgd v0.3.5)**: `/opt/repos/cfgd/.anodize.yaml:210` configures `nix` (`nix-pkgs` repo) and `/opt/repos/cfgd/.anodize.yaml:219` configures `krew` (`krew-index` repo). Release run https://github.com/tj-smith47/cfgd/actions/runs/24442230191 (success, 2026-04-15) — `NIX_PKGS_TOKEN` + `KREW_INDEX_TOKEN` secrets invoked, manifests pushed.
- **Krew fix evidence**: Recent fix commit `128e003` "krew default upstream + per-crate previous_tag prefix filter" ran successfully at CI `24441674093` — confirms krew path works under real cfgd-style tag prefixes.

## Caveats / known gaps

- `aurs` not used by cfgd (Arch is niche for this ecosystem); unit tests only. No live AUR package published by anodize or cfgd yet. Would need a live AUR account + SSH key.
- `aur_sources` (source-based AUR) implemented but not dogfooded.
