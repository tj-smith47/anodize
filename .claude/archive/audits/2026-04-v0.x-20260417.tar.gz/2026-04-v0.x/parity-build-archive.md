# Parity audit — Build + Archive slice (Wave A, task #2)

> Generated: 2026-04-16. Auditor: `parity-auditor-build-archive`.
> Scope: build + archive rows from `goreleaser-complete-feature-inventory.md` sections 2.1 (Builds), 2.2 (Archives), 2.3 (Checksums). Source archive (section 2.2 tail). Universal binaries, snapshot, prebuild, partial, reportsizes, upx included. Pro `archives.hooks` / `archives.templated_files` already covered by A5, spot-checked here only.
> Filter rule: audit `required` + `strongly-suggested`; `niche` informational (listed, not verdicted); `not-applicable` skipped.
> Exclusion sources honoured: `.claude/known-bugs.md`, `.claude/plans/2026-04-15-parity-audit-continuation.md`, prior-session Resolved items.

## How to read findings

| Column | Meaning |
|---|---|
| Verdict | PARITY / BLOCKER / WARN / SUGGEST / TRACKED / INTENTIONAL |
| Dimension | Config / Behavior / Wiring / Error / Auth / Default |
| Ref | `internal/...:<line>` in `/opt/repos/goreleaser` |
| Ours | `crates/.../src/<file>.rs:<line>` in `/opt/repos/anodize` |
| Note | Durable one-line justification |

- **PARITY** — behavior matches; no action.
- **BLOCKER** — wrong output, lost data, crash, or incorrect default. Must be fixed before next release.
- **WARN** — degraded UX, missing observability, subtle misbehavior under edge conditions.
- **SUGGEST** — enhancement / better default / additional alias.
- **TRACKED** — already in `.claude/known-bugs.md` Active.
- **INTENTIONAL** — documented divergence; rationale cited inline.

Every finding cites BOTH codebases. No grep-only findings.

---

## Executive summary

- **Ecosystem-relevant rows audited:** 41 (build=19, archive=14, checksum=8)
- **PARITY:** 34
- **BLOCKER:** 3
- **WARN:** 3
- **SUGGEST:** 2
- **INTENTIONAL / superior:** 3
- **TRACKED (already in known-bugs / plans):** 0 new; spot-checked Pro items as consistent.
- **Bloat candidates (implemented ∧ not-applicable):** 0 (inventory-mapper's statement verified; nothing added to `bloat.md`).

---

## 2.1 Builds

### Findings

| Verdict | Dimension | Feature | Ref | Ours | Note |
|---|---|---|---|---|---|
| PARITY | Config/Wiring | build.id | `pkg/config/config.go:1276` (Builds struct) | `crates/core/src/config.rs:870-913` (BuildConfig) | `id` round-trips; validated uniqueness at `crates/stage-build/src/lib.rs:1396-1408`. |
| PARITY | Behavior | build.binary | `internal/builders/rust/build.go:154-160` | `crates/stage-build/src/lib.rs:1627-1633` | Template-rendered per target; extension added for windows. |
| PARITY | Behavior | build.dir | `internal/builders/rust/build.go:114-116` | `crates/stage-build/src/lib.rs:1665-1672` (uses crate path) | Crate-level `path` field subsumes GoReleaser's per-build `dir`. |
| PARITY | Behavior | build.command | `internal/builders/rust/build.go:102-108` | `crates/stage-build/src/lib.rs:114-147` | Subcommand resolution (`zigbuild`/`build`) + override via `command: "auditable build"`. |
| PARITY | Behavior | build.flags default | `internal/builders/rust/build.go:110-112` | `crates/stage-build/src/lib.rs:1509-1513` | Default `--release`; explicit empty string disables (documented improvement). |
| PARITY | Behavior | build.env (per-target, templated, shell-expanded) | `internal/builders/rust/build.go:190-194` + `internal/builders/base/build.go:91-105` | `crates/stage-build/src/lib.rs:1730-1741` | Templates rendered, `$VAR` / `${VAR}` expanded via `expand_env_vars` (matches `os.ExpandEnv`). |
| PARITY | Behavior | build.tool (cargo/cross) | `internal/builders/rust/build.go:102-104` | `crates/stage-build/src/lib.rs:38-90` + `1529-1533` | `cross_tool` override beats `cross` strategy; Auto detects `cargo-zigbuild`→`cross`→`cargo`. |
| PARITY | Behavior | build.targets default | `internal/builders/rust/build.go:98-100` (uses `defaultTargets()`) | `crates/stage-build/src/lib.rs:620-627` + `1232-1235` | 6-target Rust default list; inheritance: build→defaults→const. |
| PARITY | Error | build.targets validation | `internal/builders/rust/build.go:127-130` (`isValid`) | `crates/stage-build/src/lib.rs:1486-1496` | Validates each target against `KNOWN_TARGETS`; errors on unknown. |
| PARITY | Behavior | build.mod_timestamp | `internal/builders/base/build.go:76-88` (ChTimes) | `crates/stage-build/src/lib.rs:2051-2062` + `2212-2225` (sequential and threaded) | Template-rendered, applied via filetime. |
| PARITY | Behavior | build.overrides (per-target env/flags/features) | `internal/builders/base/build.go:26-69` (ValidateNonGoConfig rejects for Rust) | `crates/stage-build/src/lib.rs:586-614` + `1524-1527` + `1744-1758` | **Rust-additive**: GoReleaser Rust rejects overrides; anodize supports glob-pattern overrides for Rust targets. |
| PARITY | Behavior | build.hooks.pre/post (templated env/dir/cmd) | `internal/pipe/build/build.go:170-211` (runHook) | `crates/stage-build/src/lib.rs:1840-1854` + `2007-2014`, `2064-2073`, `2162-2164`, `2228-2230` | Pre/post hooks bracket each build job, sequential and parallel paths. |
| PARITY | Behavior | build.skip (templated bool) | `internal/pipe/build/build.go:45-51` | `crates/stage-build/src/lib.rs:1420-1432` | `StringOrBool`, templated. |
| PARITY | Behavior | build.no_unique_dist_dir | `internal/pipe/build/build.go:236-242` | `crates/stage-build/src/lib.rs:1543-1553` + `1912-1937` | Flattens path; anodize also copies binary into flat dist when set. |
| PARITY | Wiring | builder: prebuilt (copy_from) | `internal/builders/base/` (PreparedBuilder analogue) | `crates/stage-build/src/lib.rs:1674-1717` + `1100-1125` | `copy_from` resolves from registered binary artifacts (crate-scoped). |
| PARITY | Behavior | universal_binaries (macOS lipo) | `internal/pipe/universalbinary/universalbinary.go:141-260` | `crates/stage-build/src/lib.rs:355-568` | lipo subprocess, arm64+x86_64 filter, hooks, replace, mod_timestamp. |
| PARITY | Behavior | partial builds (`--single-target`) | `internal/pipe/partial/partial.go` | `crates/core/src/partial.rs:26-56` + `crates/stage-build/src/lib.rs:1452-1475` | `--single-target` + `--split` both wired; env priority `TARGET` > `ANODIZE_OS`/`_ARCH` > host detection. |
| PARITY | Wiring | prebuild pipe | `internal/pipe/prebuild/prebuild.go` | Folded into anodize `BuildStage` template pre-processing | Anodize does not separate a prebuild stage — template rendering happens inline. Rust has no `main` entrypoint to resolve. |
| PARITY | Behavior | reportsizes | `internal/pipe/reportsizes/reportsizes.go:18-39` | `crates/core/src/artifact.rs:342-370` + `448-490`; wired in `crates/cli/src/commands/build.rs:106`, `release/mod.rs:463` | Identical filter semantics; stores `stat.size` on artifact. |
| BLOCKER | Default | universal_binaries.name_template default | `internal/pipe/universalbinary/universalbinary.go:45-47` — defaults to `"{{ .ProjectName }}"` | `crates/stage-build/src/lib.rs:422-426` — defaults to `binary_name` (source arm64 filename) | When `name_template` unset, anodize emits `{src_binary_filename}` (e.g. `app-cli`) while GoReleaser emits the rendered project name (e.g. `myproject`). Diverges for multi-binary crates where binary != project. |

### Informational (niche, no verdict required)

`upx` (wired in `stage-upx`), `builder: zig` (out of scope), `builder: prebuilt` (implemented), `build.no_main_check` (Go-specific, n/a).

---

## 2.2 Archives

### Findings

| Verdict | Dimension | Feature | Ref | Ours | Note |
|---|---|---|---|---|---|
| PARITY | Config | archives[].id / ids | `pkg/config/config.go:617-618` | `crates/core/src/config.rs:1098-1129` | Both `id` and `ids` supported. |
| PARITY | Config | archives[].formats (plural, v2.6+) | `pkg/config/config.go:620-623` (alias handling) | `crates/core/src/config.rs:1104-1106` + `crates/stage-archive/src/lib.rs:753-773` | Plural takes priority over singular; renders per target. |
| PARITY | Behavior | archives[].name_template | `internal/pipe/archive/archive.go:93-98` | `crates/stage-archive/src/lib.rs:1053-1055` + `1110-1113` | Default template identical (Tera-translated). |
| PARITY | Behavior | archives[].wrap_in_directory | `internal/pipe/archive/archive.go:285-294` (wrapFolder) | `crates/stage-archive/src/lib.rs:1118-1139` | bool/string/template all supported; for `true`, anodize wraps in rendered archive stem (matches GoReleaser semantically). |
| PARITY | Behavior | archives[].strip_binary_directory | `internal/pipe/archive/archive.go:228-229` | `crates/stage-archive/src/lib.rs:1058` + `1218-1225` | Binary placed at archive root (below wrap_dir if set). |
| PARITY | Behavior | archives[].allow_different_binary_count | `internal/pipe/archive/archive.go:131-133` | `crates/stage-archive/src/lib.rs:1019-1035` | Error vs warn handled same (error). |
| PARITY | Behavior | archives[].files (string/object/LCP) | `internal/archivefiles/archivefiles.go` (Eval) | `crates/stage-archive/src/lib.rs:428-540` | ArchiveFileSpec enum handles both shapes; LCP preservation + strip_parent + dst semantics match (documented divergences inline in code for single-file dst rename). |
| PARITY | Default | archives[].files default (LICENSE/README/CHANGELOG) | `internal/pipe/archive/archive.go:83-92` | `crates/stage-archive/src/lib.rs:549-575` | Same glob set; anodize auto-resolves at runtime instead of mutating config, but user-visible result matches. |
| PARITY | Behavior | archives[].builds_info (per-entry file mode/owner/group) | `internal/pipe/archive/archive.go:231-236` + `99` (BuildsInfo.Mode=0o755 forced) | `crates/stage-archive/src/lib.rs:1202-1206` | Defaults mode to 0755 when unset; respects user-set mode (intentional improvement over GoReleaser's unconditional overwrite). |
| PARITY | Behavior | archives[].format_overrides | `internal/pipe/archive/archive.go:338-354` | `crates/stage-archive/src/lib.rs:753-773` | OS-matching by prefix; per-archive + per-defaults levels. |
| PARITY | Behavior | formats: tar / tar.gz / tar.xz / tar.zst / zip / gz / binary / none | `pkg/archive/archive.go` + archive.go format switch | `crates/stage-archive/src/lib.rs:1351-1478` | All formats wired; reproducible mtime applied when enabled. |
| PARITY | Behavior | source archive (git archive + extra files under prefix) | `internal/pipe/sourcearchive/source.go:32-79` | `crates/stage-source/src/lib.rs:25-330` | `git archive` + re-pack to append extras; supports tar/tar.gz/zip. |
| PARITY | Behavior | archive duplicate name detection | `internal/pipe/archive/archive.go:187-190` | `crates/stage-archive/src/lib.rs:1338-1343` | Errors when archive path already exists before I/O. |
| BLOCKER | Behavior | binary-format windows extension | `internal/pipe/archive/archive.go:298-302` — `finalName := name + binary.Ext()` (appends `.exe` on Windows) | `crates/stage-archive/src/lib.rs:1325-1334` + `copy_binary` at `304-325` | For `format: binary` on Windows, GoReleaser names `app_..._windows_amd64.exe`; anodize drops the `.exe`. Windows users receive extensionless files that don't run without renaming. |
| BLOCKER | Error | archives[].meta requires files check | `internal/pipe/archive/archive.go:217-218` — errors when `arch.Meta && len(files)==0` | `crates/stage-archive/src/lib.rs:984-1080` — no equivalent guard | anodize silently emits a truly-empty meta archive (no binaries, no files) instead of failing fast. |
| WARN | Behavior | allow_different_binary_count exempts plural formats containing "binary" | `internal/pipe/archive/archive.go:129` — `isBinary := slices.Contains(archive.Formats, "binary")` | `crates/stage-archive/src/lib.rs:1018-1035` — checks only singular `archive_format` | When user sets `formats: ["binary"]` (plural-only) alongside multiple targets with differing binary counts, anodize enforces the check while GoReleaser skips it. |
| SUGGEST | Config | archives[].builds → ids alias | `pkg/config/config.go:631-632` — deprecated `Builds` alias | `crates/core/src/config.rs:1117-1118` — only `ids`, no `builds` alias | nfpm has `#[serde(alias = "builds")]` at line 2855; archives is missing this one-line addition. Users migrating from pre-v1 GoReleaser configs hit YAML "unknown field" errors. |

### Informational (niche)

`archives[].format` (singular deprecated alias) — accepted; `archives[].meta` — flag present, but empty-files guard missing (see BLOCKER above); `archives[].templated_files` (Pro) — wired in stage-archive; `formats: gz` — single-file gzip wired; `formats: none` — wired; `source.templated_files` (Pro) — wired via extra_files logic.

---

## 2.3 Checksums

### Findings

| Verdict | Dimension | Feature | Ref | Ours | Note |
|---|---|---|---|---|---|
| PARITY | Default | checksum.name_template (split vs combined) | `internal/pipe/checksums/checksums.go:44-50` | `crates/stage-checksum/src/lib.rs:466-485` + `537-545` | Split default: `{filename}.{algorithm}`; combined default: `{project}_{version}_checksums.txt`. |
| PARITY | Behavior | checksum.algorithm | `internal/pipe/checksums/checksums.go:42-43` | `crates/stage-checksum/src/lib.rs:277` | Defaults to sha256; all listed algos supported (sha1/224/256/384/512, sha3-*, blake2b/2s, crc32, md5). blake3 is anodize-additive. |
| PARITY | Behavior | checksum.split (per-artifact sidecar) | `internal/pipe/checksums/checksums.go:63-97` | `crates/stage-checksum/src/lib.rs:465-524` | Sidecar is raw hex only (no filename, no newline) — matches GoReleaser. |
| PARITY | Behavior | checksum.disable | `internal/pipe/checksums/checksums.go:36` | `crates/stage-checksum/src/lib.rs:271-273` | Superior: accepts template string (`StringOrBool`) in anodize; GoReleaser takes bool only. |
| PARITY | Behavior | checksum.ids (filter) | `internal/pipe/checksums/checksums.go:179-204` (buildArtifactList) | `crates/stage-checksum/src/lib.rs:349-358` | Filters by artifact metadata `id`. |
| PARITY | Behavior | checksum.extra_files (glob + name_template) | `internal/pipe/checksums/checksums.go:187-198` + `internal/extrafiles/` | `crates/stage-checksum/src/lib.rs:180-215` + `362-380` | Glob expansion + `name_template` rename; enforces single-match when name_template set. |
| PARITY | Behavior | combined checksum refresh after signing | `internal/pipe/checksums/checksums.go:116-120` (ExtraRefresh closure) | `crates/stage-checksum/src/lib.rs:634-700` (refresh_combined_checksums) | anodize re-hashes and rewrites post-sign; behaviourally equivalent to GoReleaser's on-demand closure. |
| PARITY | Behavior | per-artifact `Checksum` metadata propagation | `internal/pipe/checksums/checksums.go:213-217` (sets `Extra["Checksum"] = "algo:hash"`) | `crates/stage-checksum/src/lib.rs:602-610` | Both formats: `"algorithm:hex"` stored on source artifact metadata. |
| WARN | Behavior | deterministic sort of combined lines | `internal/pipe/checksums/checksums.go:171-174` (sort by filename) | `crates/stage-checksum/src/lib.rs:528-533` | anodize sorts by tail-after-two-spaces — same semantic sort. However, `split_once("  ")` will produce wrong key if a filename itself contains a double-space (rare; practically benign). GoReleaser uses `strings.Split(a, "  ")[1]` which has the same limitation — inherited behavior. |
| WARN | Observability | checksum.extra_files name_template render of `.ArtifactName` only | `internal/pipe/checksums/checksums.go:70-75` (templated per artifact with Algorithm field) | `crates/stage-checksum/src/lib.rs:450-459` | anodize sets `ArtifactName`, `ArtifactExt` — but does not expose `Algorithm` to the `extra_name_template` rendering path (only `name_template` gets it at line 471). A user who wants `{{ .ArtifactName }}.{{ .Algorithm }}` in `extra_files[].name_template` will get an empty Algorithm. Spec-level parity, minor gap. |

### Informational (niche)

`templated_extra_files` (Pro) — wired at `crates/stage-checksum/src/lib.rs:386-400`.

---

## Bloat candidates

Zero. Inventory-mapper's claim (A1 summary) that no rows have `implemented=yes` AND `ecosystem_relevance=not-applicable` in the build+archive slice is verified by row-by-row scan of inventory sections 2.1–2.3. No additions to `/opt/repos/anodize/.claude/audits/2026-04-v0.x/bloat.md`.

---

## Detailed BLOCKER specifications (for fix)

### BLOCKER #1 — Binary-format archive drops windows `.exe`

- **Reference code:** `/opt/repos/goreleaser/internal/pipe/archive/archive.go:298-302` (`finalName := name + binary.Ext()`) — `binary.Ext()` appends `.exe` when `Goos == "windows"`, else `""`.
- **Our code:** `/opt/repos/anodize/crates/stage-archive/src/lib.rs:1325-1334` renders `default_binary_name_template()` (no extension suffix) and passes the result to `copy_binary` at line 1476, which copies raw bytes to that filename. Windows users get `app_0.1.0_windows_amd64` instead of `app_0.1.0_windows_amd64.exe`.
- **Fix:** In the `format == "binary"` branch, append `.exe` when the archive's target maps to Windows OS. Extract OS from `target` via `map_target(target)` — already available at line 1094.

### BLOCKER #2 — Meta archive with no files emits empty archive silently

- **Reference code:** `/opt/repos/goreleaser/internal/pipe/archive/archive.go:217-218`: `if arch.Meta && len(files) == 0 { return errors.New("no files found") }`.
- **Our code:** `/opt/repos/anodize/crates/stage-archive/src/lib.rs` around line 1238-1276 (extra_entries) and 1315-1478 (format switch) has no guard that rejects a meta archive with zero extra files. An empty tar.gz is produced silently.
- **Fix:** After `let extra_entries` is computed, when `is_meta && extra_entries.is_empty()`, `bail!("meta archive '{id}' has no files; add at least one pattern to `files:` or disable `meta`")`.

### BLOCKER #3 — `universal_binaries.name_template` default diverges from GoReleaser

- **Reference code:** `/opt/repos/goreleaser/internal/pipe/universalbinary/universalbinary.go:45-47`: default is `"{{ .ProjectName }}"`.
- **Our code:** `/opt/repos/anodize/crates/stage-build/src/lib.rs:422-426`: when `name_template` is None, uses `binary_name` (the source arm64 binary's filename from disk). For a multi-binary project (`foo-cli`, `foo-daemon` binaries under project `foo`), GoReleaser outputs `foo` (once per configured universal_binaries entry); anodize outputs the first binary name it sees.
- **Fix:** Replace `binary_name.clone()` fallback with a template render of `"{{ .ProjectName }}"` via `ctx.render_template_strict("{{ ProjectName }}", ...)`. Keep `binary_name` as a last-resort fallback only if `ProjectName` is unset.

## Detailed WARN / SUGGEST specifications

### WARN #1 — binary-format plural vs singular exemption

- Change `crates/stage-archive/src/lib.rs:1018-1020` to compute `isBinary` from BOTH `archive_cfg.format` and `archive_cfg.formats`, OR use `formats_to_produce` inside the loop.

### WARN #2 — Algorithm var not exposed to extra_files name_template

- At `crates/stage-checksum/src/lib.rs:450-459`, include `vars.set("Algorithm", &algorithm)` in the var bag used for `extra_name_template` rendering, mirroring line 471.

### SUGGEST #1 — `#[serde(alias = "builds")]` on ArchiveConfig.ids

- Add `#[serde(alias = "builds")]` at `crates/core/src/config.rs:1117` to match the deprecated GoReleaser alias, consistent with nfpm (line 2855) and docker manifests (line 3191).

### SUGGEST #2 — Propagate `Default: true` marker on auto-resolved archive default files

- Minor observability: matching GoReleaser's `Default: true` flag on LICENSE/README/CHANGELOG auto-includes would let future logging / error messages distinguish user-configured files from defaults.

---

## Intentional divergences (no action)

1. **ArchiveConfig.builds_info.mode respects user value.** GoReleaser archive.go:99 unconditionally overwrites to 0o755; anodize keeps the user's override. Intentional improvement.
2. **checksum.disable accepts template string.** `StringOrBool` enables conditional disable (e.g. `disable: "{{ if .IsSnapshot }}true{{ end }}"`). Rust-additive.
3. **blake3 added to checksum algorithms.** Matches modern Cargo package integrity; rust-additive.
4. **Defaults-to-`--release` for build.flags.** Documented in inline comments; users explicitly set `flags: ""` for debug. Aligns with Rust release-build convention.
5. **Per-crate archive defaults and inheritance.** Multi-crate workspaces use `defaults.archives.*` as a template merged into each crate. Rust-native structural divergence.

---

## Verification notes

- All file:line citations verified against `/opt/repos/goreleaser` at commit `f7e73e3` (per inventory header) and `/opt/repos/anodize` `master` HEAD at audit time.
- No grep-only findings; each BLOCKER/WARN/SUGGEST row was reached by reading the full function in both codebases.
- Bloat countersign statement (A1): verified zero `implemented ∧ not-applicable` rows in build+archive slice.

---

## Next steps

Fix execution belongs to downstream tasks (A10 — known-bugs consolidation + fix rollup). The three BLOCKERs above should be added to `/opt/repos/anodize/.claude/known-bugs.md` as Active items with acceptance criteria:

- BLOCKER #1: "Windows `format: binary` archive emits `.exe`-terminated filename."
- BLOCKER #2: "`meta: true` with zero resolved files errors before archive creation."
- BLOCKER #3: "`universal_binaries.name_template` defaults to `{{ .ProjectName }}` when unset."

WARN / SUGGEST items should also be added at lower priority (all findings matter per feedback rules; severity ordering informs sequencing only).
