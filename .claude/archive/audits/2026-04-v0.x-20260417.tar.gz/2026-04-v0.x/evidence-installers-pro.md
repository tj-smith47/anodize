---
feature: dmgs[] + msis[] + pkgs[] + nsis[] + app_bundles[]
status: partial
ecosystem_relevance: strongly-suggested
tier: Pro
---

# Pro installers (DMG / MSI / PKG / NSIS / .app bundles)

## Status: 🟡 partial (structs present + unit tests; live-release untested and `if`-field gaps block full parity)

Covers: `dmgs[]` (macOS disk image via `hdiutil`), `msis[]` (Windows via Wix/wixl), `pkgs[]` (macOS .pkg), `nsis[]` (Windows installer), `app_bundles[]` (macOS .app).

## Evidence

- **Unit tests**: `crates/stage-dmg/src/`, `crates/stage-msi/src/lib.rs`, `crates/stage-pkg/src/lib.rs`, `crates/stage-nsis/src/`, `crates/stage-appbundle/src/lib.rs` — each has inline tests for subprocess invocation, config shape, filename generation.
- **Integration test (staging only)**: Implicit via `test_e2e_full_dry_run_all_stages` (integration.rs L2668).
- **CI workflow**: ci.yml run https://github.com/tj-smith47/anodize/actions/runs/24441674093 (success, 2026-04-15) runs the unit tests.
- **anodize config proof**: `/opt/repos/anodize/.anodize.yaml:408` `app_bundles:`, `:412` `dmgs:`, `:415` `pkgs:`, `:418` `msis:`, `:421` `nsis:`.

## Caveats / known gaps

- **No live release produces `.dmg`, `.msi`, `.pkg`, `.nsis.exe`, or `.app` artifacts yet.** anodize v0.2.5 asset listing has NO `*.dmg`, `*.msi`, `*.pkg`, `*.exe` installer, or `.app` bundle. Only snapcraft/makeself Linux/macOS install paths are shipped. `Release tag artifact proof: none.`
- Pro `if` conditional missing on all five: `dmgs[].if`, `msis[].if`, `pkgs[].if`, `nsis[].if`, `app_bundles[].if` — known-bugs.md A1-rev lines 41–49.
- `msis[].goamd64`, `msis[].hooks.before/after`, `nsis[].goamd64` also absent.
- These would need a macOS/Windows runner with the respective native toolchains (hdiutil, wixl, pkgbuild, makensis) to produce live evidence. Flagged in `HANDOFF.md` for live release.
